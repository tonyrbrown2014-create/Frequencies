window.FREQ_SECTOR={
 "key": "body",
 "title": "Body",
 "glyph": "◐",
 "blurb": "Shame, the physical self, the fear of being looked at. The frequency that treats the body as a problem to be managed — and the frequency that lets it be a home.",
 "philTitle": "Body · The Fear Frequency & The Reversal",
 "philText": "The body is not the problem. The frequency that watches, judges, and disowns the body is the problem. This sector is not about fitness or appearance — it is about the quiet separateness that many people carry towards their own physical self: the sense of being slightly outside the body they live in, always monitoring rather than inhabiting. It is about the moment the body stops being a subject and becomes a home.",
 "modules": [
  {
   "id": "m01",
   "label": "1 · Living Slightly Outside Yourself",
   "items": [
    {
     "kind": "Teaching",
     "text": "There is a way of being in the body that most people do not think to describe, because they have lived in it for so long that it feels like the only way. It is the experience of standing slightly outside yourself. Watching the body rather than being in it. Aware of the body rather than inhabiting it."
    },
    {
     "kind": "Teaching",
     "text": "This is not a philosophical position. It is a felt sense. The person running the frequency looks at their body the way they might look at a piece of furniture in a room they are responsible for — present, monitored, evaluated, never fully their own."
    },
    {
     "kind": "Anecdote",
     "text": "A woman notices, at a dance class, that she is watching herself dance. Not in the mirror — in her mind. She can see her own arms moving from the outside. She has been doing this her whole life. She does not know what it would feel like to be inside the motion instead."
    },
    {
     "kind": "Teaching",
     "text": "The out-of-body frequency is one of the deepest of all the sectors in this course, because it was installed before the person could speak. It arrives in the first years of life, in the small thousand moments when the body was corrected, commented on, adjusted. The child learned that the body was a project — and that they were not quite inside it."
    },
    {
     "kind": "Teaching",
     "text": "The out-of-body frequency is not the same as embarrassment. Embarrassment is a moment. The out-of-body frequency is a settled orientation. The person has been at this distance for decades. They have never known anything else."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency in the way the person describes themselves. Not 'I am tired' but 'the body is tired'. Not 'I am happy' but 'this feels nice'. A small grammatical distance between the person and their physical life — that distance is the frequency, expressed in language."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal begins with one small noticing: at some point today, is there a moment when you are simply inside the body — walking, breathing, resting — without watching it happen? You do not need to create this moment. Only to notice if it arrived."
    }
   ]
  },
  {
   "id": "m02",
   "label": "2 · The Body You Learned to Watch",
   "items": [
    {
     "kind": "Teaching",
     "text": "Every body was looked at before it learned to look at itself. A parent's gaze, checking for a stain, a bump, an imperfection. A teacher's attention on the wrong posture. A relative's comment about weight or height that arrived without malice and was received as fact."
    },
    {
     "kind": "Teaching",
     "text": "The child learns, in these earliest moments, that the body is a thing that is being assessed. Not a place to be lived in — a subject to be evaluated. The watching begins not as self-criticism but as a reasonable response to a world that was, in fact, watching."
    },
    {
     "kind": "Anecdote",
     "text": "A man remembers being six and being told, at a family gathering, that he had his mother's legs. He does not remember who said it. He remembers that he looked at his legs afterwards, for years, the way you look at a gift you are not sure you wanted. He is fifty. He still notices his legs before he notices anything else about a photograph."
    },
    {
     "kind": "Teaching",
     "text": "The watched body often becomes a watched body for the rest of the person's life. Not because the original watching was cruel, but because the nervous system recorded it as important. The child learned that the body was under review. The adult continues the review without knowing it started elsewhere."
    },
    {
     "kind": "Teaching",
     "text": "This is one of the reasons the body frequency is so difficult to see. It feels personal — as if the person is simply being hard on themselves. In fact, it is often an internalisation of a specific gaze. The person is not being hard on themselves. They are still being looked at by someone whose gaze they absorbed."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the age of the original watching. If the person has felt slightly assessed about their body for as long as they can remember, the watching arrived early. If it arrived in adolescence, it often has a specific shape — an event, a comment, a comparison."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal begins with one question: whose eyes am I seeing myself through? You do not need an answer. The question itself has begun the shift."
    }
   ]
  },
  {
   "id": "m03",
   "label": "3 · The Mirror Is Not the Problem",
   "items": [
    {
     "kind": "Teaching",
     "text": "Most people running the body frequency believe the problem is what they see in the mirror. It is not. Two people can look at the same reflection and register completely different things. The mirror is neutral. The frequency is what is being seen."
    },
    {
     "kind": "Teaching",
     "text": "A woman who has run the body frequency for thirty years looks in the mirror and sees a flaw. Her sister, looking at the same woman, sees a person she has always admired. The difference is not in the body. The difference is in the broadcast each one is running."
    },
    {
     "kind": "Anecdote",
     "text": "A man loses twenty kilograms over a year. He had believed, sincerely, that the weight was the problem. When he reaches his target, he looks in the mirror — and finds that the frequency is still running, now pointing at something else. He had not actually believed he had a body problem. He had believed he was not allowed to be at peace in his body. The weight had been an alibi."
    },
    {
     "kind": "Teaching",
     "text": "This is the deepest piece of the body frequency. It has nothing to do with the body itself. It is the belief that the body is a site of wrongness — that there is something about the physical self that requires constant correction, no matter how the body changes."
    },
    {
     "kind": "Teaching",
     "text": "People who alter their bodies dramatically, expecting the frequency to resolve, are often surprised to find it reorganised around a new complaint. The body is genuinely different. The frequency has simply found a new focal point. The size of the body was never the issue."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency in the way the person narrates their body. Not 'I have wide hips' but 'I have always had wide hips' — a sentence that carries an inevitable history rather than an observation. The inevitability is the frequency."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is not to look at the body more kindly. It is to notice that the body was never the subject. The frequency has been pointing at something else the whole time."
    }
   ]
  },
  {
   "id": "m04",
   "label": "4 · When Shame Was the Only Clothes",
   "items": [
    {
     "kind": "Teaching",
     "text": "Some body frequencies are built on something deeper than watching. They are built on shame. Not the ordinary self-consciousness of adolescence — the deep, early, bodily shame that arrives in childhood and settles into the nervous system the way a season settles into a year."
    },
    {
     "kind": "Teaching",
     "text": "Bodily shame is not about the body. It is about the belief that the body itself is evidence of something wrong with the person. The body becomes a document of the self's unfitness. Every part of it carries the accusation."
    },
    {
     "kind": "Anecdote",
     "text": "A man has never let anyone see his back. Not a partner, not a doctor, not a swimming pool. He has carried this since he can remember. The back is ordinary. Nothing wrong with it. But he cannot find a memory where this was not true. The shame had arrived before memory, and had been running ever since."
    },
    {
     "kind": "Teaching",
     "text": "Bodily shame is often installed by moments the person has no conscious record of. A parent's reaction. An adult's comment. A doctor's silence. The child did not register a sentence — the child registered a bodily fact: that this body, this specific body, was a problem."
    },
    {
     "kind": "Teaching",
     "text": "Shame is also inherited. A parent who carries bodily shame transmits the frequency through their own discomfort with their own body. The child learns, without a word being said, that bodies are dangerous, shameful, or wrong. The transmission is silent and complete."
    },
    {
     "kind": "Teaching",
     "text": "The shame is not the person's. It arrived before they could choose. The body was never the problem. The shame was always about something else — about a world that had decided certain bodies were wrong, and had passed that decision down to a child who had no way to refuse it."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal, in this module, is not to feel proud of the body. It is to begin to see the shame as a thing that was given, not a thing that was deserved."
    }
   ]
  },
  {
   "id": "m05",
   "label": "5 · The Body in the Room With Others",
   "items": [
    {
     "kind": "Teaching",
     "text": "The body frequency is easiest to notice in the presence of others. Alone, the person may forget the body entirely. In a room, with other bodies present, the frequency reasserts itself: how to sit, how to hold, how to be photographed, where to place the arms, whether the stomach is being held in."
    },
    {
     "kind": "Teaching",
     "text": "This is the body as a public performance. The person is not simply living in the body — they are managing how the body is being received. The management is constant, quiet, and exhausting."
    },
    {
     "kind": "Anecdote",
     "text": "A woman notices, at a dinner with friends, that she has not touched her hair once. She is aware of the hair, aware of the arms, aware of the angle of her neck for the entire meal. She has not been listening to the conversation. She has been managing the body's presentation. She has done this her whole adult life, and this is the first evening she has noticed."
    },
    {
     "kind": "Teaching",
     "text": "The body frequency makes the body a kind of project that is never quite finished. Even in safe rooms, even with close friends, the person continues to manage the way the body is being received. The management does not end when the audience is trusted. It ends when the frequency is finally seen."
    },
    {
     "kind": "Teaching",
     "text": "People running the frequency often experience a particular tiredness at the end of social days. Not because the socialising was demanding — because the body management was continuous, and it is genuinely exhausting to hold a body in the shape you believe it should be, all evening, for years."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency in the way you sit when someone you want to impress enters the room. The body adjusts before you have decided to adjust it. The adjustment is the frequency, arriving before the person has had a chance to choose."
    },
    {
     "kind": "Teaching",
     "text": "The body frequency is also gendered, raced, classed — some bodies are under more visible watching than others, and the frequency arrives reinforced by a world that is genuinely looking. The management is not irrational. It is often correct. The cost is still the cost."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is not to stop managing the body entirely — that is not always safe. It is to notice the managing, and to let the body be slightly unheld for one hour, in a room that allows it."
    }
   ]
  },
  {
   "id": "m06",
   "label": "6 · The Parts You Have Never Looked At",
   "items": [
    {
     "kind": "Teaching",
     "text": "Almost everyone running the body frequency has one or two parts of the body they have quietly stopped looking at. The stomach, the upper arms, the back of the thighs, a scar, the neck. These parts have become essentially invisible to the person, even though they are not invisible to anyone else."
    },
    {
     "kind": "Teaching",
     "text": "The invisibility is not accidental. It is the frequency's method. If the part is not looked at, it cannot be criticised. But the part is not forgotten — it is simply removed from the map of the self. The person's internal image of their body has a hole where that part should be."
    },
    {
     "kind": "Anecdote",
     "text": "A woman is asked, in a bodywork session, to describe her own body from memory. She gives a complete description — except for the arms. She has forgotten to include them. The bodyworker asks her to look at them. She does, and is surprised by what she sees. They are ordinary arms. She has simply not looked at them in decades."
    },
    {
     "kind": "Teaching",
     "text": "The un-looked-at parts are not necessarily the ones the person dislikes most. Often they are the parts the person has the most complicated relationship to — parts that carry memories, or comparisons, or particular failures. Looking at them would require being with something the person has spent years avoiding."
    },
    {
     "kind": "Teaching",
     "text": "The un-looked-at parts are also, often, the parts that hold the most physical tension. The neck that is never allowed to relax. The stomach that is always held. The jaw that is always slightly clenched. The frequency expresses itself in these parts, and the parts hold the frequency."
    },
    {
     "kind": "Teaching",
     "text": "The person's own image of their body is a document of the frequency. The parts included, the parts omitted, the parts magnified, the parts reduced. To see the frequency clearly, the person has to look at their own internal map."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is small and quiet. Look at one of the un-looked-at parts today, in a private moment, without criticism. Just look at it, as a piece of the body, the way you might look at the back of your own hand."
    }
   ]
  },
  {
   "id": "m07",
   "label": "7 · Moving Without Watching",
   "items": [
    {
     "kind": "Teaching",
     "text": "Watch a small child run. There is no division between the child and the running. The child is not watching themselves run. The child is running. The body is doing what it does, and the child is inside the motion, completely."
    },
    {
     "kind": "Teaching",
     "text": "Adults running the body frequency almost never move this way. Even in exercise, in dance, in walking, there is a slight self-observation. The person is checking the body while moving. The watching and the moving happen at the same time, and the watching always takes a small piece of the movement."
    },
    {
     "kind": "Anecdote",
     "text": "A woman takes up swimming in her fifties. She is slow, ungainly, and self-conscious for the first months. And then, one morning, in the middle of a length, she notices something: she has stopped watching herself swim. She is just swimming. She cries in the lane. She has not been inside her own motion since she was a child."
    },
    {
     "kind": "Teaching",
     "text": "The body frequency, once seen, often loosens first in movement. Movement is where the division between watcher and watched becomes most visible — and, sometimes, where it becomes easiest to leave behind, because the body's motion can carry the person past the watcher for a moment."
    },
    {
     "kind": "Teaching",
     "text": "This is one of the reasons many people find release in physical activity. Not because the activity is inherently therapeutic, but because the body, when it is genuinely moving, cannot be watched in the same way. The watching requires stillness on the inside. Movement dissolves the stillness."
    },
    {
     "kind": "Teaching",
     "text": "The person who can move without watching has already begun to leave the body frequency behind. Not completely. Not permanently. But the doorway is there, and the doorway is the body itself."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is one walk today, or one stretch, or one dance, in which the person is not the watcher. If the watching returns, do not fight it. Just notice. The noticing is the beginning of the movement being theirs again."
    }
   ]
  },
  {
   "id": "m08",
   "label": "8 · The Body You Were Born Into",
   "items": [
    {
     "kind": "Teaching",
     "text": "Underneath the frequency there is a simpler fact: the person is a body. Not a person who has a body. A body that is also, somehow, a person. The distinction is philosophical, but the felt difference is real. Some people feel they have a body. Others feel they are one. The frequency determines which."
    },
    {
     "kind": "Teaching",
     "text": "The body the person was born into is not a problem to be solved. It is a life to be lived. It has a particular shape, a particular pace, a particular set of capabilities and limits. None of it is a verdict. All of it is a fact. The frequency turns facts into verdicts."
    },
    {
     "kind": "Anecdote",
     "text": "A man has spent decades disliking his height. He is shorter than average, and the dislike has been one of the constant small griefs of his life. In his forties, at his father's funeral, an elderly relative tells him that he stands exactly as his grandfather stood. He had not known this. He had spent his whole life thinking of his height as an accident. It is a lineage. Something in him settles."
    },
    {
     "kind": "Teaching",
     "text": "The body the person was born into carries the lineage — the shoulders of a grandmother, the hands of an uncle, the posture of someone long gone. The frequency often erases this. The person sees only the flaw, not the inheritance. But the inheritance is there, in every gesture and every angle."
    },
    {
     "kind": "Teaching",
     "text": "This is not a call to love everything about the body. It is a call to see that the body is not a problem that was assigned to the person. It is a life that was given to them. The frequency has been treating the gift as an obstacle."
    },
    {
     "kind": "Teaching",
     "text": "The reversal, in this module, is not about the body changing. It is about the body being seen as what it actually is — the physical shape of a life that has been in motion since before the person arrived, and will continue past them, through whomever they touch."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to look at one feature of your own body and ask, quietly: where did this come from? Not to like it. Just to see that it arrived from somewhere, and that it is not an accident."
    }
   ]
  },
  {
   "id": "m09",
   "label": "9 · The Body That Was Never the Problem",
   "items": [
    {
     "kind": "Teaching",
     "text": "There comes a moment in the loosening of the body frequency when the person begins to see, clearly, that the body was never the problem. The frequency had been pointing at the body the whole time, but the frequency was about something else. It usually takes decades to see this."
    },
    {
     "kind": "Teaching",
     "text": "The person who has run the frequency for a long time often finds this realisation difficult to accept. The body has been the focus of so much attention, so much work, so much hope. To discover that the body was never the issue is almost a disappointment — as if a long campaign has turned out to be aimed at the wrong target."
    },
    {
     "kind": "Anecdote",
     "text": "A woman reaches forty-five and looks in the mirror one morning and notices, without drama, that she is fine. She has spent thirty years disliking this body, and this morning she simply does not. Nothing has changed. The body is the same as it was yesterday. The frequency has, for this morning, stepped back — and the woman is briefly able to see what everyone else has seen the whole time."
    },
    {
     "kind": "Teaching",
     "text": "The realisation does not arrive once and stay. It arrives, and then the frequency returns, and then it arrives again. This is not a failure. It is how frequencies loosen. Not in a single moment, but in a series of small returns to a clearer view."
    },
    {
     "kind": "Teaching",
     "text": "Many people who have loosened the body frequency describe the same thing: a sense of quiet surprise. They had expected release to feel like victory, or relief. It felt like noticing. One morning the mirror looked ordinary. That was all. That was the whole thing."
    },
    {
     "kind": "Teaching",
     "text": "The frequency's central lie is that the body is a problem requiring continuous attention. The loosening of the frequency is not the solving of the problem — it is the discovery that the problem was never located in the body at all."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one moment today when the body was just the body. Not judged, not managed, not watched. Just present. That moment is the shape of what is possible."
    }
   ]
  },
  {
   "id": "m10",
   "label": "10 · When the Body Finally Rests",
   "items": [
    {
     "kind": "Teaching",
     "text": "The body frequency keeps the body in a state of low alertness most of the time. Even in rest, even in sleep, the body is subtly held. The shoulders are slightly raised. The jaw is slightly locked. The stomach is slightly braced. The body has not been allowed to fully rest in decades."
    },
    {
     "kind": "Teaching",
     "text": "When the frequency loosens, something unusual happens. The body rests. Not just sleeps — rests. The held parts release. The breath deepens without prompting. The muscles that had been quietly working all day, all year, all life, finally stop."
    },
    {
     "kind": "Anecdote",
     "text": "A man in his fifties is lying on the sofa, doing nothing, and notices that his shoulders have dropped. Not lifted — dropped. He had not known they had been holding anything. He lies there for a while, feeling the shoulders rest on the sofa. He is fifty-three and this is the first time he can remember his shoulders being completely held by something other than himself."
    },
    {
     "kind": "Teaching",
     "text": "The body's deep rest is one of the clearest signs that the frequency is loosening. The person does not have to do anything. They simply notice that the body, without instruction, has stopped holding."
    },
    {
     "kind": "Teaching",
     "text": "This rest often arrives at unusual moments — in the car, on the sofa, in the middle of a workday. The body has been waiting for years for a moment when the frequency was not running hard enough to keep it held, and it takes the moment."
    },
    {
     "kind": "Teaching",
     "text": "The body's rest is cumulative. A few moments of true rest in a day begin to change the body's baseline. Not overnight. Not dramatically. But the nervous system records the rest and begins to allow more of it."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to lie down, once, without purpose, and see if the body will drop into itself. If it will not, notice that too. The noticing is the beginning of the body learning that rest is safe."
    }
   ]
  },
  {
   "id": "m11",
   "label": "11 · Recognising the Watch",
   "items": [
    {
     "kind": "Teaching",
     "text": "The body frequency has a signature. A small check in the mirror that is not about appearance but about reassurance. A brief tension when the body is seen. A slight rearrangement of clothing. A quick mental scan of how the body feels in a given moment. That is the frequency in miniature, and it happens dozens of times an hour."
    },
    {
     "kind": "Teaching",
     "text": "Learn the signature. Learn to notice the check before it has completed itself. The noticing is the whole of the practice. The body frequency cannot run a person for their whole life once it has been seen."
    },
    {
     "kind": "Anecdote",
     "text": "A woman begins to notice that she checks her own reflection in shop windows. Not to look at herself — to check that the body is presenting correctly. She has done this her whole adult life. She walks past a hundred reflective surfaces a day, and she checks at each one. She had never known this was unusual until she noticed it was happening."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is loudest in the moments of being seen. Walking into a room. Being photographed. Speaking in front of others. Being looked at, romantically. Those are the moments the frequency runs fastest, because those are the moments the body is most exposed."
    },
    {
     "kind": "Teaching",
     "text": "You will also recognise the frequency in the moments of rest. The person who cannot quite lie down. The person who has to keep the body doing something. The frequency fills stillness with management, because stillness is where the watch is loudest."
    },
    {
     "kind": "Teaching",
     "text": "The body frequency is not defeated by an argument. It is loosened by noticing. The person who can see the watch as a watch — as something that arrived from outside and is running in the present — has already begun to slip out from under it."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one check today. Not to stop it. Not to fight it. Just to see the moment the watch arrived."
    }
   ]
  },
  {
   "id": "m12",
   "label": "12 · Recalibrating",
   "items": [
    {
     "kind": "Teaching",
     "text": "The recalibration of the body frequency is not the achievement of body positivity. It is not the cultivation of self-love, or the ceasing of all criticism, or the arrival at a state of perfect acceptance. It is something much simpler and much larger: the slow, patient practice of being inside the body rather than watching it."
    },
    {
     "kind": "Teaching",
     "text": "The frequency does not disappear. It has been running since before memory. It will return in the presence of mirrors, cameras, and particular people. What changes is that the person can see it running. That seeing is the whole shift."
    },
    {
     "kind": "Anecdote",
     "text": "Two women reach their sixties in the same body, at the same weight, with the same history of disliking it. One has spent the whole of her adult life watching the body. The other, in her thirties, began the slow work of noticing the watch. Thirty years later the first is exhausted by the body she has been carrying. The second is not especially different in shape. She is simply, at last, inside her own life."
    },
    {
     "kind": "Teaching",
     "text": "You will know the frequency is shifting when the mirror stops being a verdict. When the body is simply the body. When movement does not require watching. When the person can be looked at without the small internal rearrangement that used to arrive automatically."
    },
    {
     "kind": "Teaching",
     "text": "The body frequency is one of the deepest in this course, because the body is not a subject to be discussed — it is the place from which all the other sectors are lived. The person who can finally be inside their own body is not just less self-critical. They are capable of more presence, more pleasure, more contact, more physical life."
    },
    {
     "kind": "Teaching",
     "text": "You were not born outside your own body. The distance was created. It was created by people who, themselves, had been taught to stand outside theirs. The distance is a chain that has been passed down, and it can be stopped — not with a decision, but with a lifetime of gentle returns to the body that has been waiting for you all along."
    },
    {
     "kind": "Recalibration",
     "text": "The same body. The same mirror. Two different frequencies. You have just read an entire sector about the space between them. That space is the whole of this course — and, in the body, it is the space where you finally come back to being the person who lives in the skin you are in."
    }
   ]
  }
 ]
};
