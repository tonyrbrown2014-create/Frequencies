window.FREQ_SECTOR={
 "key": "time",
 "title": "Time",
 "glyph": "◔",
 "blurb": "\"Too late.\" \"Not enough.\" The frequency of the clock running out — and the frequency of time as something to move through rather than race against.",
 "philTitle": "Time · The Fear Frequency & The Reversal",
 "philText": "Time is not the problem. The frequency that watches the clock is the problem. This sector is not about productivity or mortality — it is about the specific texture of a life that is being run under time pressure: the sense that there is always somewhere else to be, that everything is either too early or too late, and that the present moment is a waiting room. It is about the moment time stops being a weight and becomes a place.",
 "modules": [
  {
   "id": "m01",
   "label": "1 · The Clock Inside",
   "items": [
    {
     "kind": "Teaching",
     "text": "Somewhere in most adult lives there is a quiet clock that has been running since childhood. Not the clock on the wall — an internal one. A sense of how much time has passed, how much is left, whether the person is on schedule, behind, ahead, or simply late for something they cannot quite name."
    },
    {
     "kind": "Teaching",
     "text": "The clock is not a fact. It is a frequency. It runs whether or not the person is actually late for anything. It runs on a Sunday afternoon. It runs on holiday. It runs in the middle of the night. It is the frequency of a person who believes, quietly and continuously, that they are running out of something."
    },
    {
     "kind": "Anecdote",
     "text": "A woman realises, on holiday, that she has been checking the time for the entire week. Not to be anywhere. Just checking. She has looked at her watch, her phone, the clock in the villa — dozens of times a day, with nothing to be on time for. She is on holiday. The clock is still running."
    },
    {
     "kind": "Teaching",
     "text": "The clock inside is not about time management. A person with excellent time management and no time frequency can move through an unhurried day. A person with no time management and a strong time frequency can be frantic on an empty afternoon. The clock is not the calendar. The clock is the broadcast."
    },
    {
     "kind": "Teaching",
     "text": "Most people running the frequency do not notice it, because the frequency presents itself as reality. It feels as if time really is short, really is running out, really does need to be checked. The person does not experience themselves as anxious about time. They experience themselves as sensible about time."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the clock by its consistency. If the sensation of not having enough time arrives whether or not there is anything to do, the clock is running. If the sensation is proportionate to actual demands, it is not the frequency — it is simply an accurate reading."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal begins with a small noticing: how often today did you check the time without a reason? You do not need to stop the checking. You only need to see that the checking is not being driven by your schedule."
    }
   ]
  },
  {
   "id": "m02",
   "label": "2 · Where the Hurry Was Taught",
   "items": [
    {
     "kind": "Teaching",
     "text": "The time frequency is almost always installed early, by a household that was itself running on urgency. Not necessarily an unhappy household — often a very loving one. But a household where things needed to happen, or where things had already been waiting too long, or where someone was always slightly behind."
    },
    {
     "kind": "Teaching",
     "text": "The child does not learn to hurry by being told to hurry. The child learns to hurry by being inside a nervous system that was already hurried. The child's own body calibrates to the pace of the adults around them, and the pace becomes the child's baseline."
    },
    {
     "kind": "Anecdote",
     "text": "A man remembers his mother, at the school gate, always slightly rushing even when there was no reason to rush. He is fifty. He still walks slightly faster than everyone else. He has never once been late for anything important. The hurry was not about being late. The hurry was the household's frequency, passed into him through the way his mother held herself at the school gate."
    },
    {
     "kind": "Teaching",
     "text": "Some time frequencies are installed by the opposite: a household so slow that the child learned to hurry in self-defence. Or a household where things took longer than they should, and the child grew up understanding time as something that had to be pushed against."
    },
    {
     "kind": "Teaching",
     "text": "In both cases the frequency is not the person's. The child was not naturally hurried or naturally slow. The child calibrated to a specific home's specific rhythm, and has been running that rhythm ever since, in houses and countries the original household never knew."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the pace of your own walking, eating, breathing — when you are alone, in an ordinary day, with nothing to be on time for. If the pace is slightly faster than the situation calls for, the frequency is running."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is not to slow down by force. It is to notice that the pace you are running at is not currently required by anything. The noticing will naturally adjust the pace by a small amount."
    }
   ]
  },
  {
   "id": "m03",
   "label": "3 · The Waiting Room",
   "items": [
    {
     "kind": "Teaching",
     "text": "People running the time frequency experience the present moment as a waiting room. The day is not being lived — it is being waited through, on the way to something else. The real life is scheduled to begin shortly. The current hour is a placeholder."
    },
    {
     "kind": "Teaching",
     "text": "This is one of the most costly consequences of the frequency. The person is always almost there. The dinner is almost finished so the evening can begin. The week is almost over so the weekend can begin. The year is almost done so the next one can begin. Almost there is the frequency's permanent address."
    },
    {
     "kind": "Anecdote",
     "text": "A woman describes her life as a series of countdowns. She did not realise until she said it out loud. She has spent forty years counting down — to Fridays, to holidays, to the end of difficult things, to better moments that were always slightly in the future. She is not sure she has ever fully been inside a Tuesday."
    },
    {
     "kind": "Teaching",
     "text": "The waiting room is created by the frequency, but it is also the frequency's most efficient method of running the person's life. If the person is always waiting, then nothing in the present moment can disappoint them — because nothing in the present moment really counts. The frequency protects itself by making everything preliminary."
    },
    {
     "kind": "Teaching",
     "text": "This is why long-term time pressures are so difficult to break. The person does not need a specific deadline. The person needs the *shape* of a deadline — anything to keep the present moment as a waiting room rather than a life."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the waiting room in the language you use about your own life. If you describe your current month as 'nearly over', your current job as 'for now', your current town as 'in the meantime', you are living in a waiting room the frequency built."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to spend one hour today not waiting for it to finish. Not to enjoy it — just to be in it. The frequency will protest. Let it. One hour, fully given to itself, is a great deal of time."
    }
   ]
  },
  {
   "id": "m04",
   "label": "4 · What Runs Underneath the Busyness",
   "items": [
    {
     "kind": "Teaching",
     "text": "Many people running the time frequency are genuinely busy. Their calendars are full. Their days are dense. It is easy to conclude that the frequency is simply a correct response to an overloaded life. It is not. Busy people without the frequency are tired at the end of a busy day. Busy people with the frequency are tired underneath the tiredness — a deeper fatigue that no weekend resolves."
    },
    {
     "kind": "Teaching",
     "text": "Underneath the busyness there is often something the person is not letting themselves feel. A grief. A confusion. A fear. A question about their own life that has been waiting for an answer. The busyness is not the cause of the time frequency — the busyness is the frequency's strategy."
    },
    {
     "kind": "Anecdote",
     "text": "A man retires and, within a month, is frantic with a schedule of hobbies, repairs, and visits. He had assumed, while working, that retirement would be slow. It is not. The frequency that was hidden behind the job has simply found new material to move through."
    },
    {
     "kind": "Teaching",
     "text": "This is why holidays so often fail to help. The frequency does not need the calendar. The frequency needs the person's attention, and there is always something for the attention to attend to. Remove the job, and the frequency discovers the house, the garden, the children, the news."
    },
    {
     "kind": "Teaching",
     "text": "The time frequency is often a way of not being alone with the self. When there is nothing to do, there is only the person. The hurry is not just a reaction to time — it is a way of avoiding the space where a slower, truer self might appear."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise this by the shape of the resistance when you try to be truly idle. Not a resistance to *doing* — a resistance to being alone with yourself, in a room, without a task. If that resistance is strong, the frequency is holding something the person does not want to meet yet."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is not to force idleness. It is to notice what arrives when the busyness briefly stops. That arrival is the beginning."
    }
   ]
  },
  {
   "id": "m05",
   "label": "5 · The Years That Disappeared",
   "items": [
    {
     "kind": "Teaching",
     "text": "One of the quiet shocks of midlife is the discovery that a decade has passed without the person quite knowing how. The frequency runs the days so efficiently that the years go by unobserved. The person looked away for a moment and returned to find themselves ten years older."
    },
    {
     "kind": "Teaching",
     "text": "This is not because the person was not paying attention. It is because the frequency was paying attention on their behalf — to schedules, to obligations, to what needed to be done next. The person's own attention was rarely asked for. The frequency managed time so well that time itself became invisible."
    },
    {
     "kind": "Anecdote",
     "text": "A woman realises, at a reunion, that she has not thought about a specific decade of her life in twenty years. Not because it was painful. Because it was busy. She cannot remember where she lived during one of those years. She has to look it up."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is not the same as a full life. A full life has texture, memory, and anchors. A frequency-driven life has only motion. The person was busy for a decade, but the decade has not been stored as a decade. It has been stored as a series of small completions."
    },
    {
     "kind": "Teaching",
     "text": "This is one of the deepest losses that the time frequency creates. Not time itself — the memory of time. The years were spent, but they were not lived. And living is what makes a year into a thing the person can remember."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the missing years by the density of your memories. Some periods of a life are vivid. Others are a blur of ordinary completion. The blur corresponds to the periods when the frequency was running hardest."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal begins not by trying to remember, but by starting to actually *live* one period now. A month with texture. A week with anchors. Not for the record — for the life that is currently being awaited."
    }
   ]
  },
  {
   "id": "m06",
   "label": "6 · The Time That Is Not the Clock",
   "items": [
    {
     "kind": "Teaching",
     "text": "All the sectors of this course are concerned with frequency — with the invisible signal that a person is broadcasting. Time is the frequency that most easily disguises itself as an external fact. The person believes they are responding to time. They are, in fact, generating it."
    },
    {
     "kind": "Teaching",
     "text": "The clock on the wall runs at the same rate for everyone. The *experience* of time does not. An hour with a person the frequency trusts can be long and full. An hour with the frequency running can be a blur. The clock measures duration. The frequency measures aliveness."
    },
    {
     "kind": "Anecdote",
     "text": "Two people are asked how their week was. One says it flew. The other says it dragged and flew at the same time. Both are accurate. One has been inside the week. The other has been watching the week from a small distance, at a slight hurry, without being quite present for it."
    },
    {
     "kind": "Teaching",
     "text": "This is the essential distinction in the whole sector. Clock time is a neutral measurement. Frequency time is the subjective texture a person brings to duration — and it is the frequency, not the duration, that determines whether a life feels long or short, full or empty, lived or spent."
    },
    {
     "kind": "Teaching",
     "text": "The frequency can make a decade feel like a year. It can also make a single afternoon feel like a small life. The difference is not the amount of time. The difference is whether the frequency allowed the person to be present."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the difference most clearly in the moments that felt long. A childhood summer. A day in a foreign city. A conversation with someone who was actually there. In every one of those, the frequency was, for that period, not running."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice that time is not the enemy. Time is the medium. The frequency has been treating the medium as an adversary, and the person has been living in the fight rather than in the medium."
    }
   ]
  },
  {
   "id": "m07",
   "label": "7 · The Person Time Does Not Press",
   "items": [
    {
     "kind": "Teaching",
     "text": "Once a person begins to see their own time frequency, they almost always begin to see it absent in someone else. A colleague who moves slowly and gets everything done. A friend who can sit in a long meal without glancing at a phone. A stranger who walks through a market as though the afternoon had no edges."
    },
    {
     "kind": "Teaching",
     "text": "These people are often disliked by the frequency. Not consciously — but the frequency finds them irritating, or lazy, or strangely unhurried in a way that produces unease. The frequency recognises them as a living alternative, and does not want to be near them."
    },
    {
     "kind": "Anecdote",
     "text": "A woman notices that she finds a particular colleague slightly irritating. He is good at his job, kind, and calm. She cannot work out what bothers her. Eventually, in a quiet moment, she realises: he does not hurry, and she does. His ease is not a judgment on her. But it feels like one."
    },
    {
     "kind": "Teaching",
     "text": "The person time does not press is not superior to the person time does press. They are simply running a different frequency. They may have their own problems — the calm person is often calm because something else in them has already given up on urgency, which can be its own cost."
    },
    {
     "kind": "Teaching",
     "text": "But they are useful. They are a living demonstration that the frequency is not required by the world. The world continues to function for people who do not hurry. The frequency has been telling the person otherwise for their whole life."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise your own progress by the change in how you experience these people. When they stop irritating you and start being simply interesting, the frequency has begun to loosen."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to observe one such person today — someone the frequency does not press — without judgement. Not to become them. Just to see that their way of moving through time is possible."
    }
   ]
  },
  {
   "id": "m08",
   "label": "8 · The Time You Are Actually In",
   "items": [
    {
     "kind": "Teaching",
     "text": "The time frequency keeps the person slightly ahead of themselves. Not dramatically — just enough to make the present moment feel slightly behind. The body is here. The attention is on the next thing. The gap between the two is the frequency."
    },
    {
     "kind": "Teaching",
     "text": "Closing the gap is not the achievement of mindfulness. It is not the elimination of planning or thought. It is the slow, patient return of attention to the time the person is actually in — the only time any person has ever actually been in."
    },
    {
     "kind": "Anecdote",
     "text": "A woman makes a cup of tea and, for the first time in years, actually watches the water boil. She had been boiling water for half a century, and she had never once seen it happen. She is not sure what has changed — nothing about her schedule has, exactly. But the boiling water is suddenly more interesting than she remembers."
    },
    {
     "kind": "Teaching",
     "text": "The time you are actually in is not a philosophy. It is a location. The person is always located here — in the middle of a specific Tuesday, in a specific body, in a specific room. The frequency is the only thing that persuades them otherwise."
    },
    {
     "kind": "Teaching",
     "text": "Being in the actual time does not slow the clock. It does not extend the day. What it does is change the texture of the day. The hour is no longer a waiting room. The hour is the hour — and, when the frequency steps back, the hour has a quality that the person has not felt since childhood."
    },
    {
     "kind": "Teaching",
     "text": "This is not a state that can be sustained. Nobody can be present for their whole life. But the duration of presence increases with practice, and the increase is one of the clearest signs of the frequency loosening."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to spend one full minute today in the time you are actually in. Not meditation. Not a technique. Just one minute, standing somewhere ordinary, knowing what time it actually is."
    }
   ]
  },
  {
   "id": "m09",
   "label": "9 · Making Peace With the Passing",
   "items": [
    {
     "kind": "Teaching",
     "text": "Underneath the time frequency, in most lives, there is a grief. A grief about time passing. The frequency is often a way of running from this grief — because if the person is always busy, always on the way somewhere, always slightly ahead of themselves, they do not have to feel the passing."
    },
    {
     "kind": "Teaching",
     "text": "But the passing is real. The years are finite. The people the person loves will not always be here. The body the person lives in will not always be this body. The frequency cannot change any of this. It can only distract from it."
    },
    {
     "kind": "Anecdote",
     "text": "A man in his late fifties begins, one evening, to feel the actual passing of time for the first time. Not as an idea — as a sensation. He sits on the sofa and feels the years behind him and the years ahead of him and the smallness of the present between them. It is not a bad feeling. It is the feeling of being a person inside time. He had never quite let himself have this feeling before."
    },
    {
     "kind": "Teaching",
     "text": "The grief about time is not the enemy of the time frequency. It is what the frequency has been protecting the person from. The frequency has been protecting them from the grief of being a temporal creature — from the fact that every life has an end and a shape and a middle that is already happening."
    },
    {
     "kind": "Teaching",
     "text": "Making peace with the passing is not resignation. It is not giving up. It is a specific, adult recognition: that the person is a limited creature in a limited life, and that the limitation is the very thing that makes the life matter. A life with infinite time would have no urgency of meaning."
    },
    {
     "kind": "Teaching",
     "text": "The frequency rushes the person because it is afraid of this recognition. The recognition, when it finally comes, is often a relief. It is a stranger relief than the person expected, but it is real."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is not to stop caring about time. It is to let the passing be felt — once, quietly, without running from it. The feeling is not what the frequency has been promising. It is not terror. It is something more like tenderness."
    }
   ]
  },
  {
   "id": "m10",
   "label": "10 · When There Is Enough",
   "items": [
    {
     "kind": "Teaching",
     "text": "The time frequency holds a belief that is rarely spoken: that there is not enough time. Not enough for what the person needs to do, not enough for what the person wants to do, not enough to be the person they intended to be. The belief is quiet but structural. Everything else is organised around it."
    },
    {
     "kind": "Teaching",
     "text": "But the belief is, in most cases, false. Not always. Some lives are genuinely under pressure — a terminal diagnosis, a crisis, a caregiving season. Those lives have a real time limit, and the frequency does not apply to them. Most lives do not have that limit. Most lives have the ordinary amount of time, which is generally more than the frequency allows them to feel."
    },
    {
     "kind": "Anecdote",
     "text": "A woman begins to write down, in a small notebook, everything she did in a week. Not for productivity — for accounting. At the end of the week she is genuinely surprised by how much time she had. She had been living as though each day were three-quarters full, and the notebook shows clearly that each day was, in fact, at most half full. The frequency had been quietly erasing the difference."
    },
    {
     "kind": "Teaching",
     "text": "The reversal is not the discovery that the person has free time. It is the discovery that the frequency has been misrepresenting the actual amount of time available. Most adults, on honest examination, have more time than they feel. They have been living with a small perpetual debt that was never really owed."
    },
    {
     "kind": "Teaching",
     "text": "This realisation does not immediately change the person's use of time. It changes the felt texture of time. There is slightly more air in the room. There is slightly less pressure in the day. The calendar is unchanged. The frequency is not."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the shift when the word *only* stops appearing in the person's thoughts about time. Only Tuesday. Only two hours. Only a weekend. The word was doing the frequency's work, and its absence is a sign that the frequency is loosening."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to look at the actual number of hours in the coming week, honestly, without the frequency's arithmetic. Then let the number be what it is."
    }
   ]
  },
  {
   "id": "m11",
   "label": "11 · Recognising the Rush",
   "items": [
    {
     "kind": "Teaching",
     "text": "The time frequency has a signature. A small internal pull toward the next thing, even while the current thing is still happening. A glance at the clock during a conversation that had no appointment attached to it. A sensation of relief when the current commitment ends, even if the next one is not more enjoyable."
    },
    {
     "kind": "Teaching",
     "text": "Learn to hear the signature. Not to fight it, not yet. Just to hear it. The person who can hear the rush has already stepped out of it, at least slightly, because the rush is no longer invisible."
    },
    {
     "kind": "Anecdote",
     "text": "A man begins to notice, over a month, that he has a specific feeling at the end of every conversation — a small, quiet sense that he should be somewhere else. He has it with his wife, with his friends, with his own children. He had never noticed it before. It had always been there. He had thought it was simply his personality."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is loudest in the moments the person is supposed to be present: a meal with family, an evening with a partner, a slow afternoon. Those are the moments the frequency most wants to move past. Their stillness is the frequency's problem."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is also visible in the way the person describes their future. Everything good is slightly ahead. Everything bad is slightly behind. The present is a middle space that the frequency is trying to leave. When the person cannot name what they are leaving toward, they are running the frequency."
    },
    {
     "kind": "Teaching",
     "text": "You will know the frequency is loosening when the person can finish an ordinary evening without the small sense of relief that the evening has ended. The evening ending was never the goal. The frequency had simply been telling them it was."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one moment today when the small pull toward the next thing arrived. Not to stop it. Just to see it, in its own small shape, before it moves the person past the current moment."
    }
   ]
  },
  {
   "id": "m12",
   "label": "12 · Recalibrating",
   "items": [
    {
     "kind": "Teaching",
     "text": "The recalibration of the time frequency is not the achievement of living entirely in the present. It is not the disappearance of urgency, or the loss of ambition, or the loosening of responsibility. It is much simpler and much larger: the slow, patient recognition that the person has more time than the frequency has been telling them, and that the time they have is theirs to actually be in."
    },
    {
     "kind": "Teaching",
     "text": "The frequency does not disappear. It has been running since childhood, and it will return during seasons of genuine pressure. It will also return, unexpectedly, on ordinary days, for no reason the person can name. What changes is that the person recognises the return. The recognition is the whole shift."
    },
    {
     "kind": "Anecdote",
     "text": "Two people arrive at sixty in similar circumstances. One is exhausted, still hurried, still slightly ahead of herself, still counting down the days between one thing and another. The other, arrived at the same age, can sit on a bench for an hour. Neither has more time than the other. One of them is inside her own life. The other is still, in some quiet way, waiting to begin it."
    },
    {
     "kind": "Teaching",
     "text": "You will know the frequency is shifting when a long meal feels long in the right way. When a slow afternoon stops making you uncomfortable. When the words *only* and *just* stop appearing in your thoughts about time. When you notice the actual season you are actually in."
    },
    {
     "kind": "Teaching",
     "text": "The time frequency is one of the deepest of all the sectors in this course, because it runs underneath all the others. Money runs on time pressure. Work runs on time pressure. Love is often organised around the time the person does or does not have. Loosening the time frequency changes the texture of every other sector."
    },
    {
     "kind": "Teaching",
     "text": "You were not born in a hurry. You were given the hurry, by a house that did not know it was passing one on, that received the hurry from a house that did not know either. The hurry is a chain. It is also a chain that can be slowed. Not with a decision — with a lifetime of small returns to the ordinary, actual, abundant time the person has always had."
    },
    {
     "kind": "Recalibration",
     "text": "The same day. The same clock. Two different frequencies. You have just read an entire sector about the space between them. That space is the whole of this course — and, in time, it is the space where a life stops being a wait and becomes a life."
    }
   ]
  }
 ]
};
