window.FREQ_SECTOR={
 "key": "trust",
 "title": "Trust",
 "glyph": "☽",
 "blurb": "The watching that never quite stops. The frequency that decides who is safe, who is not, and whether the person can ever be put down. And what shifts when trust stops being a risk.",
 "philTitle": "Trust · The Fear Frequency & The Reversal",
 "philText": "Trust is not the problem. The frequency that has decided, in advance, who is safe and who is not is the problem. This sector is not about being more open, or taking more risks, or learning to trust again. It is about the quiet assumption — installed early, usually for good reason — that the person must watch, always, and that putting the watch down would be a kind of surrender. It is about the moment the watch is not the only thing keeping the person safe.",
 "modules": [
  {
   "id": "m01",
   "label": "1 · The Watch That Never Stops",
   "items": [
    {
     "kind": "Teaching",
     "text": "There are people in the world who are always slightly watching. Not paranoid — watching. They notice the tone of a voice before the words. They notice a shift in a room. They notice the small lag before a reply. This is not a talent. It is a frequency. It is a watch that was installed early, and it has not stopped running since."
    },
    {
     "kind": "Teaching",
     "text": "The trust frequency is not the same as being careful. Careful is a choice the person makes in specific situations. The watch is constant. It runs whether the person is in danger or not, whether the person is with a stranger or a lifelong friend, whether the person is at a dinner party or alone in their own home. The watch does not have an off switch."
    },
    {
     "kind": "Anecdote",
     "text": "A woman is on holiday with her closest friend of thirty years. The sun is warm. The meal is good. There is nothing in the day to attend to. And yet, throughout the meal, some part of her is registering the friend's tone, the friend's expression, the friend's slight changes of mood. The friend is fine. The friend has been fine for thirty years. The watch is running anyway."
    },
    {
     "kind": "Teaching",
     "text": "The watch is often mistaken for intuition. It is not. Intuition is a signal that arrives when there is something to notice. The watch is a signal that arrives whether or not there is anything to notice. It is the frequency, filling the empty space with scanning."
    },
    {
     "kind": "Teaching",
     "text": "The person running the frequency often does not experience themselves as untrusting. They experience themselves as alert, attentive, aware. They may believe that everyone is doing this. They may believe that people who are more relaxed are simply less perceptive. The frequency has hidden itself inside a description of the person's character."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the watch by the shape of the person's tiredness. It is not the tiredness of an eventful day. It is the tiredness of having been on alert through an ordinary one. The person who was not in danger is tired in the way a person who was in danger would be, because the frequency has been treating the ordinary day as if it were not."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal begins with one small noticing: at some point today, when nothing was happening, was a part of you still watching? Not because there was anything to watch for. Just to notice the watching itself, in an ordinary moment."
    }
   ]
  },
  {
   "id": "m02",
   "label": "2 · Where the Watch Was First Kept",
   "items": [
    {
     "kind": "Teaching",
     "text": "The watch almost always has an origin. A moment, a season, a household in which the child learned that the surface of things could not be trusted. That the words and the tone did not match. That the mood of the room could change without warning. The child, unable to control the room, did the only thing available: they began to watch it."
    },
    {
     "kind": "Teaching",
     "text": "The watch is not irrational. In many cases it was the child's most reasonable strategy. In a household where peace was conditional, in a family where an adult's anger arrived without warning, in a culture where the person's safety depended on reading other people accurately — the watch was correct. It was not a distortion. It was a reading."
    },
    {
     "kind": "Anecdote",
     "text": "A man remembers, in his forties, a specific evening when he was nine. His father had come home in a mood that had not yet become clear. The man had spent the whole evening watching — the tone, the step, the face — to work out what was coming. Nothing came. His father was quiet, and then went to bed. The man had been on alert for six hours for nothing. He is still, forty years later, doing the same thing."
    },
    {
     "kind": "Teaching",
     "text": "The child who learns to watch does not stop watching when they leave the house. The watch follows them into adulthood, into friendships, into relationships, into work. It was installed for a specific room, and it has been running in every room since, because the frequency does not know the difference between the original room and every room after."
    },
    {
     "kind": "Teaching",
     "text": "This is important to name, because the frequency is often treated as a personal failing. The person believes they should be more relaxed, more open, more trusting. But the watch was not a failing. It was an adaptation to a specific reality. It simply has not been updated."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the origin by the shape of what the person is watching for. If the watch is for anger, the origin is a household where anger was the danger. If it is for withdrawal, the origin is a household where silence meant punishment. If it is for exclusion, the origin is a world that was, in fact, excluding."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to consider, once, what the watch was originally watching for. Not to blame the origin. Just to see that the watch had a reason, and the reason belonged to a specific room."
    }
   ]
  },
  {
   "id": "m03",
   "label": "3 · The Trust That Was Broken in a Specific Way",
   "items": [
    {
     "kind": "Teaching",
     "text": "The trust frequency is often installed by a specific betrayal rather than a general climate. A single event that reorganised what the person believed was possible. A friend who lied. A partner who left without warning. A parent who was not what they appeared to be. The child, or the young adult, learned that the surface could not be trusted, and the watch arrived."
    },
    {
     "kind": "Teaching",
     "text": "The specific betrayal is different from the general climate. It has a moment. It has a face. It has a before and an after. The person often remembers it precisely, and they often know that the watch was not running before. Something changed. The frequency has the date of the change."
    },
    {
     "kind": "Anecdote",
     "text": "A woman discovers, at twenty-two, that a close friend had been lying to her for years — not maliciously, but as a way of managing her own discomfort, about small things that added up to a much larger false picture. The woman forgives her. She remains friends with her. But from that year forward, she watches. Not this friend specifically. Everyone. She has not stopped watching in thirty years."
    },
    {
     "kind": "Teaching",
     "text": "The watch that follows a specific betrayal is often the most rigid, because the person has clear evidence that trust was misplaced. The evidence is not generic. It is specific and documented. The frequency is running on a real event, and the person cannot argue themselves out of it, because the person is right. The surface of things is sometimes different from what is beneath."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is not wrong. It is outdated. The betrayal happened in a specific situation with a specific person. The watch is now running in every situation with every person. The watch is a solution that is no longer solving the problem it was built for."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the specific betrayal by the shape of the person's references. They sometimes still mention it. They sometimes have a story, an anecdote, a shorthand. The story is not obsession. The story is the origin of the frequency, and the frequency keeps the story close because the story is its founding document."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice the specific betrayal as a specific event, not as a general fact about the world. The friend who lied was one friend. The partner who left was one partner. The frequency has taken the specific event and turned it into the shape of all events. The specific is still specific."
    }
   ]
  },
  {
   "id": "m04",
   "label": "4 · The Trust That Must Be Earned Before It Can Be Given",
   "items": [
    {
     "kind": "Teaching",
     "text": "Some people running the trust frequency are not untrusting. They are exacting. Trust, for them, is a status that must be earned, verified, and renewed. They will trust you eventually — after a long period of testing, after the small proofs have accumulated, after the person has shown themselves to be reliable under conditions the truster has not disclosed."
    },
    {
     "kind": "Teaching",
     "text": "This sounds reasonable. In fact it is a specific frequency. Most relationships, in most cultures, run on a default of basic trust — the assumption that a person is who they present themselves as, until evidence arrives. The exacting truster runs on the reverse default: distrust, until evidence of reliability arrives. The two are very different, and the person running the second often does not notice that the first is what other people are doing."
    },
    {
     "kind": "Anecdote",
     "text": "A man joins a new team at work. He is friendly, open, and treats his new colleagues as though they are already on his side. A colleague on the same team is also new. This second man is quiet, careful, slow to share. Six months later the first man has built real relationships, and the second is still slightly outside. Nothing was wrong with the second man. He was simply waiting for evidence that the frequency has decided does not count yet."
    },
    {
     "kind": "Teaching",
     "text": "The exacting truster often describes themselves as having high standards. They describe themselves as having been burned before. They describe themselves as sensible. All three are true from the inside. From the outside, the person is running a system that requires everyone to pass a test they have not been told about, and most people fail it by not knowing it existed."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is often exhausting for the person running it. The testing is continuous. Every interaction is scanned for evidence, and the evidence is never quite enough. The person is not aware of the cost, because the cost is spread across a lifetime of careful, slightly reserved, slightly not-quite-present engagement."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of the person's friendships. They have few, and the few are old. The old ones have passed the test. New friendships are hard to build, not because the person is unfriendly, but because the entry requirements are high and unspoken, and most people are not auditioning."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal, in this module, is not to trust everyone immediately. It is to notice the default. When you meet someone new, what is the initial setting? Trust until proven otherwise, or distrust until proven safe? The default is the frequency."
    }
   ]
  },
  {
   "id": "m05",
   "label": "5 · The Trust That Was Called Being Naive",
   "items": [
    {
     "kind": "Teaching",
     "text": "There is a version of the trust frequency in which the person was once open, and was taught, sometimes by a single remark, that their openness was foolishness. They trusted easily. Someone — a parent, a friend, a teacher, an early partner — pointed out that this made them naive. From that moment, the watch arrived, and the openness was placed under supervision."
    },
    {
     "kind": "Teaching",
     "text": "The accusation of naivety is often more effective than a betrayal, because it does not require the person to have been hurt. It only requires them to have been seen as vulnerable. The person learns that openness is a form of exposure. The frequency does not say the world is dangerous. It says the person is easy to hurt, and the person believes it."
    },
    {
     "kind": "Anecdote",
     "text": "A woman, in her early twenties, is told by a colleague that she is 'too trusting'. It is said lightly. Nothing happens. But something shifts. She begins, quietly, to hold back. She begins to test rather than to meet. The change is small. She does not notice it happening. She is fifty before she realises that the person she used to be — the open one — has not been seen for nearly three decades."
    },
    {
     "kind": "Teaching",
     "text": "The frequency in these cases is close to shame. The person is not afraid of being betrayed. They are afraid of being seen as someone who could be. The frequency is defending against a verdict that was never a verdict — a remark, a joke, a sideways comment — and the person has been holding the defence ever since."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise this frequency by the shape of the person's guard. It does not look like suspicion. It looks like caution. The person is friendly, warm, present. They simply do not go first. They wait to see how the other person is before they let themselves be that. The waiting is the frequency."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one moment this week where you waited to see how the other person was before you let yourself be. Not to go first. Just to see that you waited. The waiting was not a fact about the other person. It was a fact about an old remark."
    }
   ]
  },
  {
   "id": "m06",
   "label": "6 · The Trust That Only Works in One Direction",
   "items": [
    {
     "kind": "Teaching",
     "text": "One of the frequency's quieter versions is a trust that is asymmetrical. The person trusts outward — they trust their friends, their partner, their colleagues, their children. What they do not do is trust inward. They do not trust that their own perceptions, their own judgements, their own instincts are reliable."
    },
    {
     "kind": "Teaching",
     "text": "The frequency in these cases often appears as a strong outward warmth. The person is generous with trust. They give it easily. They are loyal, forgiving, slow to blame. And underneath all of it, they do not trust themselves. They check their own reactions against the reactions of others. They defer. They ask for confirmation on things they already know."
    },
    {
     "kind": "Anecdote",
     "text": "A woman is admired by her friends for her trust. She believes in people. She gives them the benefit of the doubt. She is, in every visible way, trusting. She is also unable to make a decision without asking three people first. She does not trust her own instinct. She has outsourced the trust to everyone except herself."
    },
    {
     "kind": "Teaching",
     "text": "The asymmetrical trust is often the result of a household in which the child's own perceptions were overruled. The child noticed something, and the noticing was corrected. The child felt something, and the feeling was denied. The child learned that the surface of the world was fine, but the surface of themselves was not to be relied on."
    },
    {
     "kind": "Teaching",
     "text": "This produces the strange phenomenon of a person who trusts everyone else and no one less than themselves. They are warm, generous, and quietly lost. They are always checking the map against someone else's, and they do not trust their own."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of the person's questions. They ask for confirmation. They ask what the other person thinks before they say what they think. They ask their partner what they want for dinner and mean it as a real question, because they do not know whether their own preference is reliable."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one moment this week where you checked your own perception against someone else's. Not to stop checking. Just to see the checking, and to know that the perception you were checking was probably right."
    }
   ]
  },
  {
   "id": "m07",
   "label": "7 · The Trust That Arrives as Vigilance",
   "items": [
    {
     "kind": "Teaching",
     "text": "For many people running the trust frequency, the watch is not experienced as fear. It is experienced as care. The person is watching out for the people they love. They are noticing the small signs. They are keeping track of the moods, the movements, the small shifts, so that nothing can go wrong without them knowing."
    },
    {
     "kind": "Teaching",
     "text": "This is one of the frequency's most complete disguises. The watch has been reframed as attentiveness. The person does not think of themselves as afraid. They think of themselves as devoted. The frequency has taken a defence and called it a virtue."
    },
    {
     "kind": "Anecdote",
     "text": "A man is, by every account, a loving husband. He notices when his wife is tired. He notices when she is worried. He notices the small things. He also, quietly, notices everything. The watch is running constantly. His wife has begun, over the years, to feel slightly watched, though she could not name it. He has not noticed that the attentiveness has become an investigation."
    },
    {
     "kind": "Teaching",
     "text": "The vigilance-as-care frequency is often the hardest to see, because it appears on the surface as love. The person is good. The person is thoughtful. The person is present. And underneath, the watch is running, and the watch is not love. The love is real. The watch is additional."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of the person's reactions to small absences. When the watched person is slightly late, slightly quiet, slightly elsewhere, the watcher experiences a small, disproportionate unease. The unease is the watch, responding to a gap in the data it has been collecting."
    },
    {
     "kind": "Teaching",
     "text": "The reversal is not to stop noticing the people you love. It is to notice the difference between noticing and watching. Noticing is present and open. Watching is present and braced. Both look the same from the outside. Only one can be rested."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one moment this week where your attention to someone you love had a small element of checking rather than attending. Not to withdraw the attention. To see the difference."
    }
   ]
  },
  {
   "id": "m08",
   "label": "8 · The Trust That Is Given to Some Rooms and Not to Others",
   "items": [
    {
     "kind": "Teaching",
     "text": "The trust frequency is rarely universal. Most people running it trust in some rooms and do not in others. They trust their siblings but not their colleagues. They trust their friends but not their parents. They trust the person at the café but not the person at the office. The frequency has a map, and the map is specific."
    },
    {
     "kind": "Teaching",
     "text": "The map is not random. It was drawn by the original experiences. The rooms where trust is easy are usually the rooms where the original betrayal did not happen. The rooms where trust is difficult are the rooms that resemble the original setting — the same tone of voice, the same kind of authority, the same kind of intimacy."
    },
    {
     "kind": "Anecdote",
     "text": "A woman trusts her friends completely. She trusts her colleagues. She trusts people in every context except one: anyone with a certain kind of authority. A manager with a particular tone. A doctor. A policeman. An older man with a certain kind of confidence. She has been trusting everyone except this specific type of person for forty years. She knows why. She knows who the original was. The frequency is still running."
    },
    {
     "kind": "Teaching",
     "text": "The map is often invisible to the person running it, because the map feels like common sense. They trust who they trust and do not trust who they do not trust, and the pattern feels like the world's shape. The frequency has hidden its map inside a story about the world."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of the person's exceptions. The rooms where trust is difficult are usually the rooms that most resemble the original. The resemblance is often specific — a tone, a posture, an age, a role. The frequency is not generalising. It is matching."
    },
    {
     "kind": "Teaching",
     "text": "The reversal is not to override the map. It is to see the map. Once seen, the map is no longer the world's shape. It is the frequency's shape, drawn from a specific history, being applied to a specific present."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice which rooms in your life are hard to trust in, and to see whether those rooms share a common feature. Not to fix it. Just to see the map, and to know it has edges."
    }
   ]
  },
  {
   "id": "m09",
   "label": "9 · The Trust That Cannot Be Put Down",
   "items": [
    {
     "kind": "Teaching",
     "text": "One of the frequency's deepest moves is to make trust feel like a decision that cannot be made without permission. The person, having been told for years that the watch is what keeps them safe, cannot put it down. Not because they are afraid, but because putting it down feels like a form of betrayal. Of themselves. Of the original lesson."
    },
    {
     "kind": "Teaching",
     "text": "The watch is often felt as a duty. The person is keeping themselves safe. They are keeping the people around them safe. The watch is a burden, but it is also a form of care, and abandoning it feels like abandoning something important."
    },
    {
     "kind": "Anecdote",
     "text": "A man, in therapy, is asked what would happen if he stopped watching. He does not answer for a long time. Then he says: I think I would be letting myself down. The therapist asks: letting yourself down for what? He cannot say. The watch has been running so long that the reason for it has been forgotten. Only the obligation remains."
    },
    {
     "kind": "Teaching",
     "text": "The watch is not usually abandoned by decision. It is loosened slowly, by small experiments. A moment of unguarded attention. A moment of being present without tracking. The person does not stop watching. They simply discover, over time, that the watching was not necessary for survival. It was necessary for a specific survival, in a specific room, and the room is no longer here."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of the person's experiments. When they try to relax the watch — even briefly — the watch returns with a quiet accusation. You are being careless. You are going to miss something. You will be hurt. The accusation is the frequency, defending its position."
    },
    {
     "kind": "Teaching",
     "text": "The loosening does not happen through victory over the watch. It happens through weariness. The person runs the watch for so long that, at some point, they simply cannot keep doing it. Not because they have argued with it. Because they are tired. And in the tiredness, the watch finally gets put down, for a while."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one moment this week where the watch felt like a duty rather than a fact. The duty was the frequency. The watch was not keeping anyone safe in that moment. The watch was keeping the original room open."
    }
   ]
  },
  {
   "id": "m10",
   "label": "10 · The Trust That Has Been Misunderstood",
   "items": [
    {
     "kind": "Teaching",
     "text": "The word trust is often misunderstood. It is treated as a binary — you either trust someone or you do not. The frequency uses this misunderstanding. It says: you cannot trust this person, so you must not. The person accepts the logic, because it sounds like good sense. But trust is not binary."
    },
    {
     "kind": "Teaching",
     "text": "There are many kinds of trust. Trust with small things. Trust with money. Trust with information. Trust with feelings. Trust with the person's time. Trust with the physical body. Trust with honesty. Trust with presence. The person who is running the frequency has often collapsed all of these into one, and is running a single verdict on everyone, in every context, in every dimension."
    },
    {
     "kind": "Anecdote",
     "text": "A man does not trust his brother. He says this often. He has said it for decades. When asked what specifically he does not trust about his brother, he mentions money. His brother is bad with money. That is the whole of it. The man does not trust his brother with money. He has been running that as a general verdict for twenty years. They are otherwise close."
    },
    {
     "kind": "Teaching",
     "text": "The frequency needs the collapse to do its work. If trust is specific, the frequency cannot issue a single verdict. It must instead have a dozen specific verdicts, and each can be checked and revised. The frequency prefers the collapse, because the collapse is simpler and more durable."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of the person's language. They use the word trust as a single thing. They say 'I do not trust him' without a follow-up. When pressed, they cannot say what specifically. The collapse is the frequency's sentence, and the frequency does not like to be asked to break it down."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one person you have collapsed. Not to trust them more broadly. Just to notice that the verdict was general, and to wonder whether there is a specific version hiding under it. The specific is usually smaller, and usually more manageable."
    }
   ]
  },
  {
   "id": "m11",
   "label": "11 · The Trust That Returns",
   "items": [
    {
     "kind": "Teaching",
     "text": "There comes a moment in the loosening of the trust frequency when the person realises, quietly, that they have been resting. Not trusting, in the sense of a decision. Resting, in the sense of a state. They have been in a room, or with a person, or in a specific afternoon, and the watch was not running. Not because they decided to stop it. Because, for a moment, it was not there."
    },
    {
     "kind": "Teaching",
     "text": "This is the reversal. It is not the arrival of a more trusting self. It is the ending of the watch's monopoly on the person's attention. The watch continues to return in some rooms. But the watch is no longer the default. Some rooms are now occupied differently."
    },
    {
     "kind": "Anecdote",
     "text": "A woman, in her fifties, notices one evening that she has spent the whole evening with her husband without once monitoring his tone. She has not been checking. She has been here. The realisation arrives after the evening, and is small, and is significant. She has been married for twenty years. This is the first evening she has been married for."
    },
    {
     "kind": "Teaching",
     "text": "The returning trust is not dramatic. It does not arrive with a decision, or a breakthrough, or a moment of revelation. It arrives in the ordinary way that a room becomes home — slowly, and without noticing, and then suddenly you notice."
    },
    {
     "kind": "Teaching",
     "text": "You will know the frequency is loosening when the person starts forgetting to watch. Not trying to forget. Just forgetting. The watch slips, for an hour, for an evening, for a weekend. The person does not feel restored. They feel like themselves, without knowing that they had not been."
    },
    {
     "kind": "Teaching",
     "text": "The trust that returns is not naive. The person is not suddenly trusting everyone. They simply have a room, or a person, or a specific kind of afternoon, in which the watch is not required. That room is the beginning of the whole thing. It is enough."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one moment this week where you were not watching. Not to plan another one. To see that the watch was absent, and that nothing bad happened in its absence."
    }
   ]
  },
  {
   "id": "m12",
   "label": "12 · Recalibrating",
   "items": [
    {
     "kind": "Teaching",
     "text": "The recalibration of the trust frequency is not the achievement of a person who trusts everyone. It is not the abandonment of good sense, or the cultivation of a general openness, or the arrival at a state of universal faith in humanity. It is the slow, patient practice of noticing when the watch is running, and letting it run when it is genuinely needed — and letting it not run when it is not."
    },
    {
     "kind": "Teaching",
     "text": "The trust frequency does not disappear. It has been installed early, usually for good reason, in a specific household or a specific moment. It will return in rooms that resemble the original, in the presence of people who trigger the original, in the moments when the person is tired or unwell or alone. What changes is that the person can see the watch running, and can choose whether to keep it running."
    },
    {
     "kind": "Anecdote",
     "text": "Two people with the same history, the same origin, the same watch installed in the same year. One spends the following decades running the watch in every room, in every relationship, at every meal. The other, in her thirties, begins the slow work of noticing where the watch runs and where it does not. Forty years later they are the same age, with similar lives, with the same original wound. One is still exhausted. The other has a handful of rooms where the watch is silent. Neither has more trust in the abstract. One has rooms."
    },
    {
     "kind": "Teaching",
     "text": "You will know the frequency is shifting when the person can tell the difference between a room that is being watched and a room that is not. When they can enter a room and know, within a few minutes, which mode they are in. The knowing itself is the change."
    },
    {
     "kind": "Teaching",
     "text": "The trust frequency is one of the deepest sectors in this course, because it is not really about trusting other people. It is about the person's relationship to their own safety — and the frequency that was installed to preserve it has been running long past its usefulness, keeping the person safe from a danger that no longer exists."
    },
    {
     "kind": "Teaching",
     "text": "You were not born with a watch. You were given one. The people who gave it to you were given one before that, by people who were given one before them, and the chain of watching is old. It does not have to be dropped. It only has to be seen. And once seen, it stops being the air you breathe, and becomes something you can put down in a room that does not need it."
    },
    {
     "kind": "Recalibration",
     "text": "The same person. The same room. Two different levels of watching. You have just read an entire sector about the space between them. That space is the whole of this course — and, in trust, it is the space where the person finally gets to rest."
    }
   ]
  }
 ]
};
