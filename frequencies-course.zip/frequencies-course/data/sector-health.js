window.FREQ_SECTOR={
 "key": "health",
 "title": "Health",
 "glyph": "◇",
 "blurb": "The body as betrayer, the fear of decay, the running commentary of symptom and dread. And the frequency that treats the body as a partner — with very different results.",
 "philTitle": "Health · The Fear Frequency & The Reversal",
 "philText": "The body is not the problem. The frequency that watches the body is the problem. This sector is not about illness — it is about the quiet vigil that many people keep over themselves: the constant scanning for signs, the fear that the body will betray, the belief that health must be guarded rather than lived. It is about the moment the body stops being a suspect and becomes a home.",
 "modules": [
  {
   "id": "m01",
   "label": "1 · The Body as a Watched Thing",
   "items": [
    {
     "kind": "Teaching",
     "text": "Somewhere in many lives a shift happens so quietly that it is never noticed. The body stops being the place you live, and becomes a place you watch. The attention turns from what you are doing to how the body is doing. From there, a certain kind of life begins."
    },
    {
     "kind": "Teaching",
     "text": "The watched body is not necessarily sick. Often it is perfectly well. But it is no longer trusted. Every sensation is a possible message, every tiredness a possible warning, every small ache the beginning of something. The watch has replaced the living."
    },
    {
     "kind": "Anecdote",
     "text": "A woman is healthy by every measure. Her bloods are fine, her scans are clear, her GP is reassuring. She has a headache on a Tuesday and cannot enjoy the rest of the week. Nothing is wrong. Something is wrong. She has been told the first sentence so many times that she no longer believes it."
    },
    {
     "kind": "Teaching",
     "text": "The watch is not a symptom. The watch is a frequency. It is the body's fear frequency, expressed as attention. And like every fear frequency, it does not stay inside its own domain. It leaks. Into sleep. Into work. Into the whole shape of a life."
    },
    {
     "kind": "Teaching",
     "text": "The watched body has a particular feel. Slightly tense. Slightly held. Slightly suspicious of itself. Rest becomes difficult because rest is a place where the watch is loudest — the silence where the scanning has nothing to distract it."
    },
    {
     "kind": "Recalibration",
     "text": "The first gesture is simple: notice one moment today when you were in the body rather than watching it. A moment of real tiredness. A moment of real hunger. A moment of real pleasure. You do not have to change the watch yet. You only have to notice that there are other places the body can be."
    }
   ]
  },
  {
   "id": "m02",
   "label": "2 · Where the Vigil Begins",
   "items": [
    {
     "kind": "Teaching",
     "text": "The vigil rarely begins with the person who is keeping it. It begins with someone else — a parent, a culture, a doctor, a first frightening experience — who taught the body that it was a thing to be watched. The child learns the watch before they learn anything else about health."
    },
    {
     "kind": "Teaching",
     "text": "A mother who was ill, a father who was worried, a house where a headache was treated as a possible tumour and a cough as a possible cancer — the child does not become ill. The child becomes vigilant. The body becomes a subject to be monitored rather than a life to be lived."
    },
    {
     "kind": "Anecdote",
     "text": "A man remembers being seven and hearing his mother, on the phone, use the word 'lump'. He was not ill. His mother was not ill. But something in his body learned, that afternoon, that lumps were a thing to check for. He is forty-three. He still checks."
    },
    {
     "kind": "Teaching",
     "text": "The vigil is a learned skill. It is passed from parent to child as faithfully as any other family inheritance. No one chooses it. It arrives in the earliest years, when the child has no defence against the frequencies of the adults in their life."
    },
    {
     "kind": "Teaching",
     "text": "This matters because it means the health frequency is not a personal failing. It is a transmission. The person watching their body is often running a watch their parent ran, whose parent ran, whose parent ran, all the way back to a moment when someone, long ago, was justifiably afraid."
    },
    {
     "kind": "Teaching",
     "text": "The vigil is not the same as care. Care acts. Vigil waits. The mother who teaches her child to check is not teaching care — she is teaching the child to stand at the door of themselves, waiting for something to arrive."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is not to blame the parent, or the culture, or the doctor. It is to see that the vigil was passed to you. Once you can see it as a transmission, you can begin the quiet work of not passing it on."
    }
   ]
  },
  {
   "id": "m03",
   "label": "3 · The Cost of Listening Too Closely",
   "items": [
    {
     "kind": "Teaching",
     "text": "Listening to the body is a good thing. Listening too closely is not. The difference is not in the volume, it is in the assumption. The caring listener trusts what they hear. The vigilant listener is waiting for the message that confirms the fear."
    },
    {
     "kind": "Teaching",
     "text": "The vigilant listener does not hear the body. They hear their own interpretation of the body. A twinge becomes the beginning of something. A skipped heartbeat becomes a warning. The body is quiet; the frequency is loud."
    },
    {
     "kind": "Anecdote",
     "text": "A woman has a small mole on her forearm. It has been there for twenty years. She has looked at it twice in that time. Then a friend is diagnosed with melanoma. The woman spends an hour a day for two years examining the mole. The mole does not change. Her life does."
    },
    {
     "kind": "Teaching",
     "text": "The body, when watched too closely, begins to cooperate with the fear. Tension creates tension. Held breath creates tightness. The muscles tighten because they are being watched. The watch can add its own discomforts to the ones it was meant to catch."
    },
    {
     "kind": "Teaching",
     "text": "One of the great ironies of the health frequency is that constant vigilance is itself wearing. Prolonged stress is known to affect sleep, digestion and general wellbeing, and the vigil is a form of stress. None of this means the worry caused an illness. It means the worry has a cost of its own."
    },
    {
     "kind": "Recalibration",
     "text": "Notice one small sensation today — a twinge, a flutter — and let it be nothing. Not because it is definitely nothing. Because you cannot know it is something. The habit of letting small things be small is the whole of the recalibration. Everything else is a variation on it."
    }
   ]
  },
  {
   "id": "m04",
   "label": "4 · The Doctor as Mirror",
   "items": [
    {
     "kind": "Teaching",
     "text": "The health frequency shows up most clearly in the doctor's surgery. The frequency of the patient is more visible there than anywhere else — because the doctor's presence sharpens the vigilance and the frequency shows itself in the first thirty seconds."
    },
    {
     "kind": "Teaching",
     "text": "A person who trusts the body walks into a consultation with curiosity. A person running the vigil walks in with evidence. They have been preparing the case for days. They know the timing, the sensation, the exact phrase that will secure the response they need."
    },
    {
     "kind": "Anecdote",
     "text": "Two people sit in a waiting room with the same chest tightness. One is there to find out. The other is there to be told it is nothing, and to be told it a second time, and a third, until the phrase finally reaches somewhere it can be believed. The doctor can feel the difference in the first sentence each one speaks."
    },
    {
     "kind": "Teaching",
     "text": "The doctor is not a mirror in the sense of reflecting back. The doctor is a mirror in the sense that the patient's frequency is fully visible in how the visit is conducted, what the patient reports, what the patient hears, and what they do afterwards."
    },
    {
     "kind": "Teaching",
     "text": "One of the quiet cruelties of the health frequency is that it can make a good doctor's reassurance useless. The reassurance arrives, and the frequency immediately explains it away. 'She didn't examine me for long enough.' 'He didn't order the test I was hoping for.' The reassurance is received and rejected in the same moment."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice whether you are visiting the doctor for information, or for absolution. The information is available either way. The absolution is not, because the frequency will always want one more confirmation."
    }
   ]
  },
  {
   "id": "m05",
   "label": "5 · When a Real Diagnosis Arrives",
   "items": [
    {
     "kind": "Teaching",
     "text": "This module is not a denial. Real illness exists. Real diagnoses arrive. When they do, the frequency does not disappear — it changes shape. It becomes louder, or quieter, or something in between, and how it is running at that moment shapes what the person then does."
    },
    {
     "kind": "Teaching",
     "text": "Two people receive the same diagnosis on the same day. One walks into the vigil with a clear question: what do I do next. The other walks in with a conclusion: this is the end. The medicine each one receives from the same doctor is the same. What they do with it is not."
    },
    {
     "kind": "Anecdote",
     "text": "A man is told he has a condition that will need managing for years. He believes, in that moment, that his life is over. He behaves accordingly. Three years later, the condition is stable and the life is not. He has not been undone by the illness. He has been undone by the frequency the diagnosis triggered."
    },
    {
     "kind": "Teaching",
     "text": "The frequency cannot prevent a diagnosis. It cannot cure a body. But it can shape the relationship between the person and the condition. And that relationship — quiet, invisible, unspoken — can matter alongside treatment — never as a replacement for it."
    },
    {
     "kind": "Teaching",
     "text": "The fear frequency, when it meets a real diagnosis, sometimes becomes the greatest obstacle to recovery. It stops the person taking the treatment that would help. It convinces them the treatment is futile. It persuades them that the body is beyond their participation."
    },
    {
     "kind": "Teaching",
     "text": "The person who has worked with the health frequency is not protected from illness. But they meet illness differently. They are able to hold the diagnosis without collapsing into it. They are able to be both ill and alive at the same time."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is not the absence of illness. It is the presence of a self alongside the illness, present enough to make choices, to ask good questions, to take the next small step. That self was there all along. The frequency had been keeping it quiet."
    }
   ]
  },
  {
   "id": "m06",
   "label": "6 · The Aging Frequency",
   "items": [
    {
     "kind": "Teaching",
     "text": "As the body ages, the health frequency discovers a new source of material. Every grey hair, every slower step, every forgotten word becomes evidence. The frequency had been watching for danger. Now it has found a reliable source of it — time itself."
    },
    {
     "kind": "Teaching",
     "text": "The aging frequency is often the loudest it has ever been, because the signs are now real. The body genuinely is changing. The frequency is no longer inventing evidence. It is simply interpreting it, and interpreting it in the direction it has always leaned."
    },
    {
     "kind": "Anecdote",
     "text": "Two women are the same age. One tells everyone she meets how old she is and what hurts today. The other has simply not thought about it in months. Neither is pretending. Both are ageing. But the frequency in which each is ageing produces two very different decades."
    },
    {
     "kind": "Teaching",
     "text": "The aging frequency treats the body as a diminishing asset. It counts what has been lost rather than what is still available. It tracks the decline and misses the presence. It is running a balance sheet the body never agreed to."
    },
    {
     "kind": "Teaching",
     "text": "Some cultures amplify the aging frequency. Others quieten it. Ageing brings real changes, but nothing says a sixty-year-old must feel diminished. Much of that feeling is learned from the surrounding world."
    },
    {
     "kind": "Teaching",
     "text": "The body that is not watched ages differently in one specific way: it ages without being narrated. The person does not recount their own decline. They simply move through the changes as they move through everything else. This is rarer than it sounds, and it is available."
    },
    {
     "kind": "Recalibration",
     "text": "Notice one thing the body can still do today that the frequency never mentions. Not because the body will always be able to do it. Because right now, it can. The frequency has been keeping the list of losses. Today, keep the other list."
    }
   ]
  },
  {
   "id": "m07",
   "label": "7 · The Body as a Suspect",
   "items": [
    {
     "kind": "Teaching",
     "text": "The health frequency holds a quiet belief: the body is not to be trusted. It is a mechanism that will fail, and the failure will be unexpected. The person running the frequency is not the body's inhabitant. They are the body's investigator, always gathering evidence."
    },
    {
     "kind": "Teaching",
     "text": "This belief is not about any actual illness. It is a default position — the frequency's starting assumption whenever the body is quiet or produces a sensation. It is what makes the frequency so persistent. It is not reacting to evidence. It is generating it."
    },
    {
     "kind": "Anecdote",
     "text": "A man goes for a routine scan. The scan is clear. He leaves the appointment relieved, and by the time he is home he has decided the scan missed something. He books another. He knows this is irrational. He cannot stop. The frequency has made the body into a suspect that no evidence will exonerate."
    },
    {
     "kind": "Teaching",
     "text": "The body, treated as a suspect, begins to behave like one. It becomes defensive, closed, held. The muscles tense in a way the frequency reads as a new symptom. The breath shortens in a way the frequency reads as a new warning. A feedback loop forms which the frequency calls evidence."
    },
    {
     "kind": "Teaching",
     "text": "The body is not a suspect. The body is a process — ongoing, alive, continuously regulating, always in motion. It is not silent and then alarming. It is signalling constantly, and most of the signals are not for you. The frequency listens only for the ones that might be."
    },
    {
     "kind": "Teaching",
     "text": "The reversal is not to trust the body blindly. It is to stop treating it as the defendant. You are not the prosecutor. There is no case. There is only a body doing what bodies do."
    },
    {
     "kind": "Recalibration",
     "text": "The next time you check something, ask yourself honestly: am I investigating, or am I living? Both are legitimate. Only one is sustainable."
    }
   ]
  },
  {
   "id": "m08",
   "label": "8 · What Rest Feels Like When the Watch Stops",
   "items": [
    {
     "kind": "Teaching",
     "text": "People running the health frequency often cannot rest. Not because they are too busy — because rest is where the watch gets loudest. In movement, the watch has distractions. In stillness, it has the floor."
    },
    {
     "kind": "Teaching",
     "text": "The vigil is quiet when the body is engaged. It becomes unbearable when the body is at ease. Sleep, meditation, a lazy afternoon — these are the places where the frequency presents its whole case at once, having been waiting all day for a hearing."
    },
    {
     "kind": "Anecdote",
     "text": "A woman lies down for a nap on a Sunday. Within a minute her mind is scanning for symptoms. She gets up. She feels better immediately. She believes she is not tired. She is tired. She is just unable to be tired in the presence of the watch."
    },
    {
     "kind": "Teaching",
     "text": "The frequency, when it stops, does not stop completely. It quietens. There is still a small voice in the corner of the room. But it is no longer running the meeting. The body can rest, and the person can be there for the rest."
    },
    {
     "kind": "Teaching",
     "text": "This is one of the clearest diagnostics for whether the health frequency is running. Try to lie still, comfortably, for ten minutes. If you cannot, the frequency is in the room. If you can, it has mostly stepped back."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal begins with one real rest. Not a productive rest. Not a rest after which you must achieve something. Just a rest that ends when the body ends it. Let it be enough. The frequency will want to say it was not. Do not argue. Just let it have been enough."
    }
   ]
  },
  {
   "id": "m09",
   "label": "9 · When the Body Begins to Trust You",
   "items": [
    {
     "kind": "Teaching",
     "text": "The body, when it is no longer being watched, does something the frequency would never predict. It starts to feel different. Not better immediately. Not healthier immediately. But different — quieter, softer, in a way the person has not felt in years."
    },
    {
     "kind": "Teaching",
     "text": "This is the body's response to being trusted. It is not a medical event. It is a relational one. The body has been treated as a suspect for so long that when the suspicion lifts, a real thing happens in the nervous system. The muscles rest. The breath deepens. The vigilance falls away."
    },
    {
     "kind": "Anecdote",
     "text": "A man has been watching his body for twenty years. He reads about a different way of being — not a treatment, just a suggestion. He tries it for one day. Nothing medical changes. Something else does. He can feel his own arms again."
    },
    {
     "kind": "Teaching",
     "text": "The body is not a mechanism that requires monitoring. The body is a partner that requires relationship. The difference is not semantic. A mechanism is watched. A partner is lived with. And a partner, over time, becomes a home."
    },
    {
     "kind": "Teaching",
     "text": "People who have made this shift describe the same small things. Waking without scanning. Eating without counting. Moving without measuring. Sleeping without preparatory rituals. Nothing dramatic. Just the quiet absence of a mechanism that was never needed."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to let the body begin to trust you. Not to trust the body first — the body has been doing its work all along. To trust the body is to stop suspecting it. And the trust, once given, is rarely unearned."
    }
   ]
  },
  {
   "id": "m10",
   "label": "10 · The Body as a Home",
   "items": [
    {
     "kind": "Teaching",
     "text": "There is a way of being in the body that is not vigilance and not denial. It is presence. The body is not watched. The body is not ignored. The body is simply inhabited — the way a person inhabits a home they have stopped evaluating."
    },
    {
     "kind": "Teaching",
     "text": "This is not a feeling of perfect health. The body still has sensations. It still has aches, tiredness, occasional strangeness. None of it is taken as evidence because there is no case being built. The sensations are simply what they are."
    },
    {
     "kind": "Anecdote",
     "text": "Two people have the same age, the same health, the same set of minor conditions. One manages them. The other lives with them. From the outside, they look almost the same. From the inside, the difference is not small."
    },
    {
     "kind": "Teaching",
     "text": "Inhabiting the body is what most people did before they learned not to. Children do not watch their bodies. They are their bodies. Somewhere in growing up, many people lose this. The health frequency is one of the places they lose it. The reversal is one of the places they get it back."
    },
    {
     "kind": "Teaching",
     "text": "The home body does not require constant reassurance. It requires attention, sometimes. It requires care, when care is needed. But most of the time it simply runs. The person is not managing the body. The person is living in it."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is not to feel good every day. It is to feel at home in the body, whatever the day is doing. This is available. It is not easy. It is more available than the frequency will ever suggest."
    }
   ]
  },
  {
   "id": "m11",
   "label": "11 · Recognising the Vigil",
   "items": [
    {
     "kind": "Teaching",
     "text": "The health frequency has a signature. A small pause before you answer a question about how you are. A quick scan before you enter a room. A moment of checking, in the middle of a conversation, whether the body is still fine. That is the vigil in miniature."
    },
    {
     "kind": "Teaching",
     "text": "Learn to hear the signature. Not to stop it, not yet. Just to hear it. The person who can hear the vigil has already changed their relationship to it. It is no longer the water they swim in. It is a sound they can notice."
    },
    {
     "kind": "Anecdote",
     "text": "A woman begins to notice that she checks her own pulse only when she is about to fall asleep. For years she believed this was normal. Now she sees it as a tell — the frequency's final revision of the day, before it can finally release her."
    },
    {
     "kind": "Teaching",
     "text": "The vigil is loudest in the moments you are most tired, most stressed, most alone. It is a load that the frequency places on the mind when the mind has nothing else to hold. Recognising the vigil at these moments is the whole of module eleven."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the vigil most clearly when you catch yourself preparing an answer you did not need to prepare. A sentence about your health, rehearsed silently, in a room where no one has asked. That preparation is the tell."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to pause on the tell. Not to fix it. Just to notice: 'ah, the vigil is here.' That sentence alone has more power than any technique. It is the beginning of the end of the frequency's monopoly on your attention."
    }
   ]
  },
  {
   "id": "m12",
   "label": "12 · Recalibrating",
   "items": [
    {
     "kind": "Teaching",
     "text": "The recalibration of the health frequency is not the achievement of perfect health. It is not the elimination of all symptoms, the erasure of all risk, or the construction of a body that never fails. It is much simpler and much larger: it is the slow, patient practice of stopping the vigil."
    },
    {
     "kind": "Teaching",
     "text": "The vigil does not disappear overnight. It is not a switch. It is a habit — a lifelong habit, built on the fear of a body that has been taught to fear itself. It comes back. It comes back often. Each time it comes back, the practice is the same: notice it, and let it go."
    },
    {
     "kind": "Anecdote",
     "text": "Two people, the same body, the same age, the same aches. One is still watching. The other has stopped. Nothing in the scans is different. Everything in the lives is."
    },
    {
     "kind": "Teaching",
     "text": "You will know the frequency is shifting when a strange sensation arrives and your first thought is not 'what is this?' but 'that is a sensation'. When a twinge does not summon a story. When a symptom does not become an identity."
    },
    {
     "kind": "Teaching",
     "text": "The health frequency is one of the most deeply installed in the human animal. It was installed before language, before memory, before the self that is reading this. It will not leave on request. But it can be recognised. And once recognised, it stops running the body from the shadows."
    },
    {
     "kind": "Teaching",
     "text": "You were not born watching yourself. That was taught. The person who taught you was also taught. There is nothing to blame, and nothing to earn. There is only the quiet work — the slow, patient return to being in the body, rather than outside it, watching."
    },
    {
     "kind": "Recalibration",
     "text": "The same body. The same day. Two different broadcasts. You have just read an entire sector about the space between them. That space is the whole of this course — and, in health, it is the space where you finally come home to your own skin."
    }
   ]
  }
 ]
};
