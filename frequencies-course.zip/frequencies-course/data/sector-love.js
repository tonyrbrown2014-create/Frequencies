window.FREQ_SECTOR={
 "key": "love",
 "title": "Love",
 "glyph": "✧",
 "blurb": "Abandonment, unworthiness, and the fear of not being enough. The frequency that keeps reaching out — and the frequency that finally lets itself be found.",
 "philTitle": "Love · The Fear Frequency & The Reversal",
 "philText": "Love is not the frequency. The fear of losing it is. This sector is not about romance — it is about the signal that arrives the moment love does: the fear of being too much, the fear of being not enough, the belief that love must be earned, and the relief of finally letting yourself be loved without needing to deserve it.",
 "modules": [
  {
   "id": "m01",
   "label": "1 · The Arrival",
   "items": [
    {
     "kind": "Teaching",
     "text": "The moment love arrives, the fear arrives with it. This is the quiet shock most people miss: they were waiting for love, and what came instead was a new kind of fear. The fear of losing what had only just been found."
    },
    {
     "kind": "Teaching",
     "text": "Before love, the fear was of absence. After love, the fear is of loss. It is the same frequency wearing a different face — and it is often louder, because now there is something to protect."
    },
    {
     "kind": "Anecdote",
     "text": "A woman meets someone kind. For three days she feels light. On the fourth, a small thing he says — nothing, really — and her whole body goes quiet with dread. The dread was not about him. It was the arrival of the fear, wearing his voice."
    },
    {
     "kind": "Teaching",
     "text": "This is why so many people sabotage love at the beginning. Not because they don't want it — because the frequency cannot imagine having it, and moves to end the uncertainty before the fear becomes unbearable."
    },
    {
     "kind": "Teaching",
     "text": "The frequency does not say 'I might lose this'. The frequency says 'I will lose this'. It speaks in the past tense of a future that has not yet happened. And it speaks with such authority that the body believes it."
    },
    {
     "kind": "Recalibration",
     "text": "Notice the moment the fear arrives. That is the whole of the first work. Not to push the fear away — just to see that it came in with the love, and that it is not the same thing as the love."
    }
   ]
  },
  {
   "id": "m02",
   "label": "2 · The Reach",
   "items": [
    {
     "kind": "Teaching",
     "text": "The frequency that fears abandonment reaches. It reaches for confirmation, for reassurance, for a sign that the love is still there. It reaches so often that the reaching itself becomes the thing that pushes love away."
    },
    {
     "kind": "Teaching",
     "text": "The reach is not neediness. The reach is the frequency's way of staying safe. It believes that if it checks often enough, the danger will not arrive unannounced. The checking has never worked. It will not work."
    },
    {
     "kind": "Anecdote",
     "text": "A man texts his partner four times a day at first. Then eight. Then a dozen. Each time she answers, he feels relief for a moment, then the fear returns stronger. By the time she leaves, he is convinced it was the texts. It was not the texts. The texts were the frequency, looking for a door."
    },
    {
     "kind": "Teaching",
     "text": "The reach does not know it is a reach. From the inside, it feels like caring. It feels like attentiveness. It feels like love, which is why it is so hard to see."
    },
    {
     "kind": "Teaching",
     "text": "The person being reached for feels the frequency long before they can name it. They do not feel loved. They feel responsible for someone else's peace. This is a burden no love can carry indefinitely."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is not to stop reaching. It is to notice the reach, and to let one text go unsent. Not out of strategy. Out of curiosity. Just to see what happens when the frequency does not get its reassurance."
    }
   ]
  },
  {
   "id": "m03",
   "label": "3 · The Withhold",
   "items": [
    {
     "kind": "Teaching",
     "text": "Some frequencies respond to the fear of loss by holding back. They give less than they feel, reveal less than they know, admit less than they want — all to keep a small piece of themselves safe in case the love turns out to be the loss they expect."
    },
    {
     "kind": "Teaching",
     "text": "The withhold believes it is protecting something precious. And it is — but what it protects is not the person. It is the frequency. The person waits inside the withholding, growing colder, wondering why love never feels as warm as it looked."
    },
    {
     "kind": "Anecdote",
     "text": "A man has been married twenty years. His wife says, near the end, that she has never quite known him. He is stunned. He thought he had been open. What he had been was careful — carefully kind, carefully present, carefully never quite here. The withholding had become invisible to him."
    },
    {
     "kind": "Teaching",
     "text": "Withholding is not cruelty. It is a defence that has outlived its use. It was built for a world where love was conditional, and it works very well in that world. It simply does not work in a love that is offered freely."
    },
    {
     "kind": "Teaching",
     "text": "The two frequencies — reach and withhold — often meet in the same couple. The more one reaches, the more the other withholds. The more one withholds, the more the other reaches. Neither is the villain. Both are afraid."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is small. Say one thing you were going to keep quiet. Not a confession — just a truth. The frequency will protest. Let it. The whole shift lives in the sentence you say anyway."
    }
   ]
  },
  {
   "id": "m04",
   "label": "4 · Too Much, Not Enough",
   "items": [
    {
     "kind": "Teaching",
     "text": "The love frequency carries two fears that seem to contradict each other and yet live in the same body. The fear of being too much. And the fear of being not enough. Most people run both, at once, and never notice the contradiction."
    },
    {
     "kind": "Teaching",
     "text": "Too much: too intense, too emotional, too needing, too difficult. Not enough: not pretty enough, not successful enough, not calm enough, not interesting enough. Together they make a person who is constantly apologising for existing."
    },
    {
     "kind": "Anecdote",
     "text": "A woman is told by two different partners, years apart, that she is 'a lot'. She believes them both. She spends a decade trying to become less. When she finally meets someone who does not flinch, she cannot quite trust it. She keeps waiting for him to say the thing the others said."
    },
    {
     "kind": "Teaching",
     "text": "The double bind is not a fact about the person running it. It is a fact about the frequency. The frequency was installed by someone — a parent, a culture, an early love — who transmitted both messages at once: be more, but do not be too much."
    },
    {
     "kind": "Teaching",
     "text": "You cannot reason your way out of the double bind. Any argument you make, the frequency makes the opposite. 'I am not too much' becomes 'then why does it feel like too much'. The frequency always has a reply."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is not to become neither too much nor not enough. It is to notice that no version of you was ever going to be the right size for a frequency that was never satisfied in the first place."
    }
   ]
  },
  {
   "id": "m05",
   "label": "5 · The Belief That Love Must Be Earned",
   "items": [
    {
     "kind": "Teaching",
     "text": "The deepest frequency in love is this: the belief that love must be earned. That it is a wage, not a gift. That you are currently in a probation period, and that at any moment the love might be withdrawn if you fail the unseen test."
    },
    {
     "kind": "Teaching",
     "text": "This belief is not dramatic. It is not confessed. It shows up as effort — as the constant small labour of being lovable. Being kind when you are tired. Being patient when you are furious. Being interesting when you want to be quiet. The labour is invisible. The exhaustion is not."
    },
    {
     "kind": "Anecdote",
     "text": "A man takes a week off work to look after his sick partner. He is attentive, gentle, generous. When she recovers, she tells him she loves him. He feels nothing. Later he realises: he had been waiting for the wage. She had been offering the gift. They were not the same currency."
    },
    {
     "kind": "Teaching",
     "text": "When love is earned, it is never received. It is only paid. And a payment, once made, must be made again — tomorrow, and tomorrow, until the person running the frequency collapses from the work of deserving something that was never conditional."
    },
    {
     "kind": "Teaching",
     "text": "The person who offers the love is often baffled by the receiver's inability to accept it. They keep saying 'you don't have to do anything' and the receiver keeps doing things. Neither can see the frequency. Both feel the friction."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to receive one thing without earning it. A compliment, a kindness, a small gift. Say thank you. Say nothing else. Do not deflect, do not return, do not pay. Notice how uncomfortable it is. That discomfort is the frequency."
    }
   ]
  },
  {
   "id": "m06",
   "label": "6 · The Test",
   "items": [
    {
     "kind": "Teaching",
     "text": "When the frequency is afraid, it tests. It creates situations to see if the love is real. It picks small fights. It goes quiet. It says 'I am fine' and means the opposite. It waits for the partner to fail, so the fear can finally be justified."
    },
    {
     "kind": "Teaching",
     "text": "The test is never conscious. On the surface, the person running the frequency believes they are simply having a bad day, or expressing a real concern. Beneath the surface, the frequency is confirming its own prediction: I will be left."
    },
    {
     "kind": "Anecdote",
     "text": "A woman repeatedly starts arguments on Sunday nights, without knowing why. Her partner is patient, then hurt, then tired. Eventually he stops responding. When he leaves, she is not surprised. 'I knew it,' she says. The frequency had known it all along. It had arranged for it to be true."
    },
    {
     "kind": "Teaching",
     "text": "The test is the frequency's most expensive habit. It is designed to protect the love, and it destroys the love. Every test passed brings a moment of relief; every test failed brings the proof the frequency was looking for. Either way, the frequency wins."
    },
    {
     "kind": "Teaching",
     "text": "You can tell the test by its aftermath. Real conflict leaves both people clearer. The test leaves one person relieved and the other confused. The relief is the tell — it is the frequency settling back into its familiar shape."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to catch the test before it runs. Not to stop the impulse — the impulse will come. But to name it, silently, before it does any damage. 'This is a test.' That sentence alone breaks the pattern."
    }
   ]
  },
  {
   "id": "m07",
   "label": "7 · The Mirror",
   "items": [
    {
     "kind": "Teaching",
     "text": "When a partner mirrors your frequency back to you, the relationship does not feel like love. It feels like exposure. Every fear you have about yourself is being acted out by the person in front of you, and you cannot look away."
    },
    {
     "kind": "Teaching",
     "text": "This is why the same person can be loved by one partner and hated by another. It is not the person who changed. It is the mirror. Someone who is running a peaceful frequency meets the same person as the mirror of peace. Someone running a fearful frequency meets them as the mirror of fear."
    },
    {
     "kind": "Anecdote",
     "text": "A man leaves his wife, saying she is too anxious. He meets someone calm. Within a year, he is accusing her of the same anxiety. She is not anxious. He is. The mirror had simply changed shape. The frequency had not."
    },
    {
     "kind": "Teaching",
     "text": "The mirror is not cruel. It is truthful. It shows you what you have been broadcasting, and it does not soften the image. Many people spend their lives looking for a mirror that will flatter. They will find it — and it will be a mirror that keeps the frequency hidden, which is worse."
    },
    {
     "kind": "Teaching",
     "text": "The partner who reflects your frequency is not your enemy. They are the most useful person you will ever meet. They are showing you, in real time, what your broadcast actually sounds like from the outside."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to ask, in the middle of a familiar argument, 'what am I broadcasting right now?' Not what is the other person doing. What am I sending. That question is the door."
    }
   ]
  },
  {
   "id": "m08",
   "label": "8 · The Rescue Fantasy",
   "items": [
    {
     "kind": "Teaching",
     "text": "Many love frequencies hold a quiet belief that someone is coming to save them. Someone who will finally make the fear go away. Someone whose love will be strong enough to overwrite the old broadcast. This is the rescue fantasy, and it is one of the frequency's most beautiful disguises."
    },
    {
     "kind": "Teaching",
     "text": "The rescue fantasy is beautiful because it feels like hope. It feels like openness. It feels like the willingness to be loved — which the frequency believes is the whole problem. But underneath the hope is a quiet refusal: the refusal to change the frequency yourself."
    },
    {
     "kind": "Anecdote",
     "text": "A woman leaves a difficult marriage and finds someone kind. She is sure this time is different. Three years later she is quietly exhausted, and cannot say why. The partner had not failed. The fantasy had simply done its work, and now the frequency was back — because the frequency had never left."
    },
    {
     "kind": "Teaching",
     "text": "No partner can change your frequency for you. They can hold space while you change it. They can reflect it back when you slip. They cannot do the work. A person whose love is trying to save you is not loving you — they are offering a temporary relief that will end when the frequency returns."
    },
    {
     "kind": "Teaching",
     "text": "The rescue fantasy is not a failure of love. It is an understandable wish. But love, real love, is what remains when the rescue has not arrived — and the two people are still here, still themselves, still choosing each other without the wish."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice when you are waiting to be saved. Not to judge the waiting. Just to notice it. And to ask, gently: what if the person I am waiting for is not coming — and I am still allowed to love, and to be loved, anyway?"
    }
   ]
  },
  {
   "id": "m09",
   "label": "9 · After Love Arrives",
   "items": [
    {
     "kind": "Teaching",
     "text": "The frequency that feared abandonment does not simply dissolve when love arrives. Often it grows louder. Because now there is something to lose. The fear of losing love is almost always stronger than the fear of never finding it."
    },
    {
     "kind": "Teaching",
     "text": "This is the quiet shock of a long marriage. The person finally has what they always wanted — and they are more afraid than they ever were alone. They had imagined that love would end the fear. Love revealed it."
    },
    {
     "kind": "Anecdote",
     "text": "A woman who spent years wishing for a partner finally finds one. Six months in, she is sleeping badly, snappish, distant. She does not understand it. She had believed her problem was the absence of love. It turned out her problem was the fear of love, and now the fear had something to hold."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is not afraid of being alone. The frequency is afraid of being seen — really seen — by someone who might decide you are not who they hoped you were. Being alone is safe in a way the frequency knows how to survive. Being loved is not."
    },
    {
     "kind": "Teaching",
     "text": "If the fear has grown louder since love arrived, this is not a sign that the love is wrong. It is a sign that the frequency has finally met the conditions it was always afraid of."
    },
    {
     "kind": "Recalibration",
     "text": "Notice the fear, and notice the love, in the same breath. They are not the same thing. They arrived together. They do not have to leave together."
    }
   ]
  },
  {
   "id": "m10",
   "label": "10 · Letting Yourself Be Loved",
   "items": [
    {
     "kind": "Teaching",
     "text": "This is the hardest module in this sector. Not because it is complicated — because it is quiet. Letting yourself be loved requires no action. It requires the absence of action. And the frequency hates doing nothing."
    },
    {
     "kind": "Teaching",
     "text": "The frequency wants to earn, to give, to prove, to be useful. It is deeply suspicious of a love that asks nothing of it. When someone loves you without condition, the frequency experiences this not as love but as a trick. It waits for the cost to appear."
    },
    {
     "kind": "Anecdote",
     "text": "A man is loved well by his partner for years. He never quite relaxes. She asks him, once, what he is waiting for. He says, without thinking, 'the moment it turns'. She is quiet. It never turns. He waits anyway. That is the frequency."
    },
    {
     "kind": "Teaching",
     "text": "Letting yourself be loved is not a decision. It is a slow habit of receiving without returning, of being held without deserving, of being seen without hiding. It feels, at first, like going against everything you were taught about how to be safe."
    },
    {
     "kind": "Teaching",
     "text": "The frequency will call this lazy, entitled, foolish. It will insist you must do something. Anything. Do not argue with it. Just keep receiving. The frequency will slowly lose its argument, and the love will be allowed in."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is not to love better. It is to be loved better — by letting someone love you without you having to be anything other than what you already are."
    }
   ]
  },
  {
   "id": "m11",
   "label": "11 · Recognising the Frequency",
   "items": [
    {
     "kind": "Teaching",
     "text": "The love frequency has a signature. A tone. A rhythm in the body. It arrives when you are about to be vulnerable, when someone is being kind, when you have just been seen. It arrives as a small tightening, a slight holding, a quiet 'not yet'."
    },
    {
     "kind": "Teaching",
     "text": "Learn that tone. Learn its arrival. It is the most useful skill in this whole sector — the ability to notice, in the moment, that the fear has arrived, before it has decided what to do with you."
    },
    {
     "kind": "Anecdote",
     "text": "A woman begins to notice that every time her partner is genuinely warm with her, she feels a small flash of irritation. Not anger. Just a slight 'oh, stop'. She never understood why. Then she realised: the warmth was reaching a place the frequency had spent her whole life keeping cold."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is loudest in the moments it is being contradicted. Kindness contradicts it. Tenderness contradicts it. Being believed in, being seen without judgement, being loved on a Tuesday for no reason — all these contradict it. So it fights back. The fight is the signal."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency most clearly in your reactions, not your thoughts. The irritation at a kind word. The awkwardness at a compliment. The pull to make a joke when someone is being sincere. These are the frequency's tells."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to pause on the tell. Just for a moment. Not to explain it, not to fix it. Just to notice: 'ah, there it is.' That pause is the whole of recognition."
    }
   ]
  },
  {
   "id": "m12",
   "label": "12 · Recalibrating",
   "items": [
    {
     "kind": "Teaching",
     "text": "The recalibration of the love frequency is not a technique. It is not affirmations, it is not visualisation, it is not the perfect partner. It is the slow, patient practice of noticing the fear each time it arrives, and letting love stay a moment longer anyway."
    },
    {
     "kind": "Teaching",
     "text": "The reversal does not feel like victory. It feels like rest. The person running the healed frequency does not feel brave. They feel unbraced. They can be warm without checking first. They can receive without bracing for the cost. They can be loved on a Tuesday for no reason and not need to explain it."
    },
    {
     "kind": "Anecdote",
     "text": "Two people, same devotion, same commitment. One is always waiting for the turn — for the moment the love becomes conditional. The other, with the same love, is quietly present. Ten years later, one is exhausted and the other is home. Neither can say exactly why."
    },
    {
     "kind": "Teaching",
     "text": "You will know the frequency is shifting when a small kindness no longer triggers the impulse to give it back. When someone says 'I love you' and your first thought is not 'why'. When you are held, and you do not need to hold yourself."
    },
    {
     "kind": "Teaching",
     "text": "The love frequency is one of the deepest in the human animal. It was installed early, and it will not leave quietly. But it can be recognised. And once recognised, it can be lived alongside, without letting it run the whole show."
    },
    {
     "kind": "Teaching",
     "text": "You did not come here to be rescued. You did not come here to earn. You came here to be loved. That has always been available to you. The frequency was the only thing standing in the way."
    },
    {
     "kind": "Recalibration",
     "text": "The same love. The same person. Two different broadcasts. You have just read an entire sector about the space between them. That space is the whole of this course — and, in love, it is the space where you finally let someone in."
    }
   ]
  }
 ]
};
