window.FREQ_SECTOR={
 "key": "money",
 "title": "Money",
 "glyph": "◈",
 "blurb": "The scarcity pattern — and the quiet frequencies of sufficiency. How the same figure on a bank statement runs through two entirely different beliefs, and where the numbers go from there.",
 "philTitle": "Money · The Fear Frequency & The Reversal",
 "philText": "The same bill. The same figure. Two different broadcasts. This sector is not about numbers — it is about the frequency underneath the numbers. What you will read here is the fear frequency in its most familiar costume, and the reversal that opens the moment it is seen.",
 "modules": [
  {
   "id": "m01",
   "label": "1 · The Scarcity Broadcast",
   "items": [
    {
     "kind": "Teaching",
     "text": "The scarcity frequency does not announce itself. It arrives disguised as good sense — as being realistic, as knowing your limits, as the careful management of a shortage. The person running it rarely feels afraid. They feel prudent."
    },
    {
     "kind": "Teaching",
     "text": "A frequency is not a mood. A mood passes. A frequency is the set of assumptions running beneath every mood — about what is possible for someone like you, about what you deserve, about what the world is fundamentally made of."
    },
    {
     "kind": "Teaching",
     "text": "You did not choose the scarcity broadcast. It was handed to you — by a parent who worried, a school that ranked, a culture that taught you to be grateful for less. You inherited the signal before you could question it."
    },
    {
     "kind": "Anecdote",
     "text": "Two friends, same salary, same city, same age. One checks her account three times a day. The other checks it once a week. Their money alone does not explain the difference. How each of them holds it does."
    },
    {
     "kind": "Teaching",
     "text": "The scarcity frequency is not about how much money you have. It is about how much money you believe you are allowed to have. Two people with identical balances can broadcast from entirely different places."
    },
    {
     "kind": "Recalibration",
     "text": "The moment you notice that the scarcity broadcast is a broadcast — not the truth of your situation — it already begins to weaken. The noticing is the whole shift. Everything else is a variation on it."
    },
    {
     "kind": "Teaching",
     "text": "Scarcity is not the absence of money. It is the expectation of absence — running quietly beneath the money you already have."
    }
   ]
  },
  {
   "id": "m02",
   "label": "2 · The Story of Never Enough",
   "items": [
    {
     "kind": "Teaching",
     "text": "The scarcity frequency is fed by a story. The story is always the same shape: it says that whatever you have is not enough, and whatever comes next cannot be relied upon. The story has no ending. That is its point."
    },
    {
     "kind": "Teaching",
     "text": "Children who grew up hearing money discussed in whispers, in arguments, or not at all — learned to hear money as weather. Something that happens to you. Something you cannot command. That learned weather becomes the adult's nervous system."
    },
    {
     "kind": "Anecdote",
     "text": "A man reaches the top of his industry. Same salary as his boss, same respect, same options. He still checks the price of every item twice. He still cannot bring himself to buy the thing without a discount. The world changed; the broadcast didn't."
    },
    {
     "kind": "Teaching",
     "text": "Never enough is not a fact about money. It is a fact about the frequency. A person running this signal would feel the same at ten million as at ten thousand. The number is not the variable."
    },
    {
     "kind": "Teaching",
     "text": "Scarcity propagates. A parent who is quietly afraid of money raises a child who is quietly afraid of money — not by what the parent says, but by what the parent is broadcasting beneath what they say."
    },
    {
     "kind": "Recalibration",
     "text": "The story of never enough was written before you could read. The moment you can say to yourself 'this is a story, not a fact', the story loses some of its authority. It does not vanish. It just stops being the only voice in the room."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is not the fear of poverty. The frequency is the fear of being the kind of person for whom poverty is possible. Which is a story about identity, not about money."
    }
   ]
  },
  {
   "id": "m03",
   "label": "3 · Money as Mirror",
   "items": [
    {
     "kind": "Teaching",
     "text": "Money is a mirror. It shows you your own broadcast more accurately than almost anything else in a life — because the way a person feels about money tends to show up there very clearly."
    },
    {
     "kind": "Teaching",
     "text": "Two identical workers, same job, same hours. One sees work as something to survive. The other sees the same work as a base to build from. Both are equally talented. Ten years later the numbers are not remotely comparable."
    },
    {
     "kind": "Anecdote",
     "text": "A woman keeps a small ledger of her spending. Same ledger for five years. It never shows more than survival. Then one year the ledger changes shape. Nothing external changed. What changed was that she had stopped believing the ledger was permanent."
    },
    {
     "kind": "Teaching",
     "text": "The mirror is not exact. Real shortage is real, and no change of mindset replaces an income. But when the strain stays the same whether the balance is low or high, some of it lives in the relationship to money rather than in the money itself."
    },
    {
     "kind": "Teaching",
     "text": "People do not usually look in a mirror and blame the mirror. With money, they do, constantly. The mirror is blamed for the reflection. Nothing changes, because the frequency is still what is being sent."
    },
    {
     "kind": "Recalibration",
     "text": "When you stop blaming the mirror, you can finally see what you are broadcasting. That is the whole work of this module — not to change the mirror, but to see what it has been showing you all along."
    }
   ]
  },
  {
   "id": "m04",
   "label": "4 · The Cost of Bracing",
   "items": [
    {
     "kind": "Teaching",
     "text": "A person running the scarcity frequency lives braced. The shoulders are slightly raised. The jaw is slightly held. The breath is slightly shallow. This is not metaphor. This is a body that has been told, quietly, for years, that the next moment may not be safe."
    },
    {
     "kind": "Teaching",
     "text": "Bracing is expensive. It uses energy that could be spent creating. It narrows the field of what you notice. It reduces your ability to see opportunity, because opportunity requires an open set of eyes and an open nervous system."
    },
    {
     "kind": "Anecdote",
     "text": "A man in his fifties, financially secure, cannot sleep. He has run the numbers a hundred times. Nothing adds up to the danger he feels. The danger is not on the spreadsheet. The danger is the frequency."
    },
    {
     "kind": "Teaching",
     "text": "Scarcity steals from the future by narrowing the present. Braced people don't take the risk that would have paid off. They don't say yes to the meeting that would have opened a door. They can't — the body has already said no."
    },
    {
     "kind": "Teaching",
     "text": "The cost of bracing shows up in health before it shows up in money. Sleep, digestion, immunity, patience. The body pays the frequency bill first."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal begins in the body before it begins in the bank. When the shoulders drop, when the breath deepens, the frequency is already changing. The money follows the nervous system, not the other way around."
    },
    {
     "kind": "Teaching",
     "text": "Most people try to fix the money to fix the bracing. The order is wrong. Fix the bracing, and the money has somewhere to land."
    }
   ]
  },
  {
   "id": "m05",
   "label": "5 · What Scarcity Sounds Like in a Room",
   "items": [
    {
     "kind": "Teaching",
     "text": "The frequency broadcasts outward, into a room, into a conversation, into a negotiation. It is not visible. It is felt. The same words carry a different weight depending on the frequency behind them."
    },
    {
     "kind": "Anecdote",
     "text": "Two people ask for a raise. Same words, same evidence, same manager. One is heard as a person stating a fact. The other is heard as a person asking for a favour. The difference is not the script. The difference is the broadcast."
    },
    {
     "kind": "Teaching",
     "text": "Scarcity in a room sounds like apology. Slightly too much explanation. Slightly too many hedges. Slightly too much gratitude for the opportunity. All of it heard by everyone."
    },
    {
     "kind": "Teaching",
     "text": "People respond to frequency faster than to content. They do not know why they trust one person and not another — but the frequency already told them. The content arrives second."
    },
    {
     "kind": "Teaching",
     "text": "The scarcity pattern can shape how a person behaves around others, and so how others respond — often echoing the way they already treat themselves. If you are quietly negotiating for less, the world will quietly offer less."
    },
    {
     "kind": "Recalibration",
     "text": "You can practise a new sentence, but if the frequency behind it is unchanged, the sentence will be heard as a variation of the old one. Change the frequency, and even an awkward sentence lands."
    },
    {
     "kind": "Teaching",
     "text": "This is the practical cost of the frequency: it shapes how you are received long before it shapes what you are offered."
    }
   ]
  },
  {
   "id": "m06",
   "label": "6 · The Prosperity Disguise",
   "items": [
    {
     "kind": "Teaching",
     "text": "The scarcity frequency is clever. When challenged, it does not defend itself as fear. It defends itself as ambition. It shows up as the drive to work harder, to prove more, to never quite rest."
    },
    {
     "kind": "Teaching",
     "text": "A person who works every hour, chases every opportunity, and cannot stop — is often described as driven. Frequently they are braced. The activity is the frequency in motion."
    },
    {
     "kind": "Anecdote",
     "text": "A man builds three businesses in a decade. Each one succeeds. Each one is sold. He has never once felt safe. His accountant calls him a success. His body calls him something else."
    },
    {
     "kind": "Teaching",
     "text": "Prosperity disguised as fear looks productive and feels exhausting. You can tell the difference by what happens when you try to stop. If rest is intolerable, the frequency is running the show."
    },
    {
     "kind": "Teaching",
     "text": "The scarcity broadcast is not lazy. It is not passive. It is often the most productive force in a life — and that is what makes it hard to notice."
    },
    {
     "kind": "Recalibration",
     "text": "When you can rest for an afternoon without the world ending, you will know the frequency is shifting. Rest is the great diagnostic. Nothing else reveals the broadcast as clearly."
    },
    {
     "kind": "Teaching",
     "text": "You can be busy and still be braced. The two are not opposites. Often they are the same thing wearing different clothes."
    }
   ]
  },
  {
   "id": "m07",
   "label": "7 · The Numbers Are Not the Frequency",
   "items": [
    {
     "kind": "Teaching",
     "text": "Here is the release. The numbers are not the frequency. The numbers are the weather. The frequency is the climate. You do not change the climate by arguing with the weather."
    },
    {
     "kind": "Teaching",
     "text": "A person can double their income and stay in the scarcity frequency. A person can lose half their income and leave the scarcity frequency. The numbers are not the variable. The broadcast is."
    },
    {
     "kind": "Anecdote",
     "text": "A woman leaves a well-paid job she hated and takes one at half the salary that she loves. Within three years she earns more than she ever did before. Nothing about the market explains it. Everything about the frequency does."
    },
    {
     "kind": "Teaching",
     "text": "When you understand that money is a mirror and not a master, the urgency drops. You stop running toward money and start living in a way that money can find."
    },
    {
     "kind": "Teaching",
     "text": "This is not a promise that money appears by magic. It is an observation about how opportunities travel. They travel toward open nervous systems, not toward braced ones."
    },
    {
     "kind": "Recalibration",
     "text": "The moment you stop treating the number as the goal, the number starts moving. This is one of the oddest facts of a life — and one of the most reliable."
    }
   ]
  },
  {
   "id": "m08",
   "label": "8 · Other People as Broadcasters",
   "items": [
    {
     "kind": "Teaching",
     "text": "Frequencies meet other frequencies. Two scarcity broadcasts in a room make each other more afraid. A scarcity broadcast and an open one make each other uneasy — until one of them shifts."
    },
    {
     "kind": "Anecdote",
     "text": "A couple argues about money for years. Same argument, same words, same conclusion. Then one of them stops arguing. The frequency shifts. Within a year the arguments about money have ended — and neither of them can say precisely why."
    },
    {
     "kind": "Teaching",
     "text": "This is the hardest part. You cannot change someone else's frequency by arguing. You can only change yours. And often, that changes what happens next."
    },
    {
     "kind": "Teaching",
     "text": "When two people with the same broadcast meet, they reinforce. When two people with different broadcasts meet, one of them either shifts or leaves. This is why communities so often become echo chambers of a single frequency."
    },
    {
     "kind": "Teaching",
     "text": "You do not need to leave the people in your life. You need to stop broadcasting at their frequency. That alone changes the conversation."
    },
    {
     "kind": "Recalibration",
     "text": "If you change your frequency and the relationship does not change, the relationship may not have been about you at all. It may have been about the frequency you were carrying for both of you."
    }
   ]
  },
  {
   "id": "m09",
   "label": "9 · When the World Starts Answering Differently",
   "items": [
    {
     "kind": "Teaching",
     "text": "When the frequency shifts, the world does not immediately change. But it starts answering differently. Small things. A call returned. A conversation that lands. An unexpected opening."
    },
    {
     "kind": "Teaching",
     "text": "These early signals are quiet. They are easy to miss if you are still braced. Part of the practice is learning to hear them — to notice that the world is answering, even before it is answering loudly."
    },
    {
     "kind": "Anecdote",
     "text": "A man in debt runs a new frequency for six months. Nothing in his accounts changes. Then one morning, a stranger asks him a question in a café — and it turns out to be a doorway. The door had been there all along. He simply couldn't see it."
    },
    {
     "kind": "Teaching",
     "text": "The world answering differently is not a reward. It is a consequence. The frequency that opens the eyes to possibility cannot help but see possibility. And what the eyes see, the world gradually provides."
    },
    {
     "kind": "Teaching",
     "text": "Beware expecting the world to change overnight. The frequency that expected immediate reward for immediate change is the same frequency that thought it had to earn everything. Both are the scarcity broadcast."
    },
    {
     "kind": "Recalibration",
     "text": "Notice one small thing today that answered differently. That is enough. The whole course is built on noticing one small thing at a time."
    }
   ]
  },
  {
   "id": "m10",
   "label": "10 · What Reversal Looks Like From the Inside",
   "items": [
    {
     "kind": "Teaching",
     "text": "The reversal does not feel like victory. It feels like quiet. The person who has shifted the scarcity frequency does not feel rich. They feel unbraced. Nothing in their life has to be proven anymore."
    },
    {
     "kind": "Teaching",
     "text": "The strangest mark of the reversal is that you stop needing to talk about money. Not because you have plenty — because it is no longer a frequency at the front of your mind."
    },
    {
     "kind": "Anecdote",
     "text": "A woman pays off a debt she carried for twenty years. She expected relief. She got something quieter — a strange absence of an alarm that had been ringing under everything she did. It took her a week to realise the alarm was gone."
    },
    {
     "kind": "Teaching",
     "text": "The scarcity frequency is exhausting to run. When it stops, the relief is not dramatic — it is simply the absence of an old weight. Many people do not notice it has gone until they look back."
    },
    {
     "kind": "Teaching",
     "text": "You will know the reversal is real when a small financial setback no longer shakes the foundation. You will still feel it. You will not feel it the same way."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is not the same as being safe. It is the frequency of someone who can hold the possibility of not being safe — without collapsing under it."
    }
   ]
  },
  {
   "id": "m11",
   "label": "11 · Recognising the Frequency",
   "items": [
    {
     "kind": "Teaching",
     "text": "The practice is simple but not easy. The practice is to catch the frequency in the act — to notice, in the moment, the tiny tightening that happens when money is mentioned. That notice is the work."
    },
    {
     "kind": "Teaching",
     "text": "You do not need to fix the frequency the moment you notice it. The noticing is enough. Fixing is the old pattern. Noticing is the new one."
    },
    {
     "kind": "Anecdote",
     "text": "A man starts keeping a small notebook. Every time he feels a pinch of scarcity, he writes down the moment. Nothing more. After a year he has a map of his own frequency — and the map alone has changed it."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is strongest in the moments you are most certain it is real. That certainty is the tell. When the broadcast feels like the truth, it is at its most powerful — and most hidden."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by its tone. Not its content. It has a distinctive inner voice. Slightly urgent. Slightly cautious. Slightly apologetic. Learn to hear that tone, and the frequency stops running you."
    },
    {
     "kind": "Recalibration",
     "text": "The signal becomes visible the moment you stop arguing with it. Stop defending it. Stop justifying it. Just notice it. That noticing is the recalibration."
    }
   ]
  },
  {
   "id": "m12",
   "label": "12 · Recalibrating",
   "items": [
    {
     "kind": "Teaching",
     "text": "The recalibration is not a technique. It is not a mantra. It is not a money mindset exercise. It is the slow, patient practice of seeing what you have been broadcasting — and letting that seeing do the work."
    },
    {
     "kind": "Teaching",
     "text": "The pivot is small. The moment the person running the scarcity frequency says 'oh — I am doing the thing again' — that is the pivot. The whole of the shift lives inside that sentence."
    },
    {
     "kind": "Anecdote",
     "text": "Two people receive the same disappointing news. One is crushed. One is quietly curious. The news alone does not explain the difference. How each person holds it does. And the broadcast, in the second person, had been practised for years."
    },
    {
     "kind": "Teaching",
     "text": "You do not have to believe a new frequency before it starts working. You only have to stop believing the old one — completely, or in part. Belief arrives second. Recognition arrives first."
    },
    {
     "kind": "Teaching",
     "text": "The reversal is not a destination. It is a direction. A day of openness. Then another. Then another. The frequency does not change in an instant. It changes in a habit of noticing."
    },
    {
     "kind": "Teaching",
     "text": "The people who shift the frequency permanently are not the ones who had a dramatic insight. They are the ones who kept noticing the old one, patiently, without judgement, until one day it was no longer there."
    },
    {
     "kind": "Recalibration",
     "text": "The same bill. The same figure. Two different broadcasts. You have just read an entire sector about the space between them. That space is the whole of this course."
    }
   ]
  }
 ]
};
