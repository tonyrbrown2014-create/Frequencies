window.FREQ_SECTOR={
 "key": "creativity",
 "title": "Creativity",
 "glyph": "◓",
 "blurb": "The work you don't make because it wouldn't be good enough. The frequency that decides whether a person is allowed to create at all — and the reversal that lets the work exist.",
 "philTitle": "Creativity · The Fear Frequency & The Reversal",
 "philText": "Creativity is not the problem. The frequency that decides whether a person is allowed to make anything at all is the problem. This sector is not about artistic talent or productivity — it is about the quiet assumption, installed long before the first blank page, that the work is either good enough to justify its own existence or should not exist at all. It is about the moment the work is allowed to be what it is.",
 "modules": [
  {
   "id": "m01",
   "label": "1 · The Work You Did Not Make",
   "items": [
    {
     "kind": "Teaching",
     "text": "The most common creative act is the work that was never made. Not the work that was made and failed — the work that never arrived at the point of existing. A phrase for a song. A shape for a painting. An opening line for something. The person had it, briefly, and then it was gone. Not discarded. Prevented."
    },
    {
     "kind": "Teaching",
     "text": "The creativity frequency is not about the quality of the work. It is about whether the work is permitted to come into existence at all. The person may have talent, may have ideas, may have whole projects in their mind. The frequency decides, before any of it reaches paper, whether the making is going to happen."
    },
    {
     "kind": "Anecdote",
     "text": "A woman in her forties is asked by a friend whether she still writes. She says no. Then she pauses. She says — actually, she has four notebooks at home, all started, all with the first few pages filled. She has never got past the third page of any of them. It is not that she stopped writing. It is that she has never finished starting."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is not visible to the person running it, because it works before the work exists. It does not say 'this is not good enough'. It says 'why don't we just wait until we have more time'. It says 'this isn't the right moment'. It says 'we will do it properly next week'. The frequency uses ordinary good sense as its method. The person does not experience resistance. They experience a series of small reasonable postponements."
    },
    {
     "kind": "Teaching",
     "text": "The work that was never made is the largest body of work the person has. It lives in the notebooks, in the files, in the mind, in the notes app. It is the true creative output of a life spent mostly holding back — a life whose making has been quietly redirected into preparation."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of what is accumulating. The person has more ideas than they have made things. They have more plans than they have finished projects. They have more notebooks than pages. The frequency does not stop the making. It stops the finishing."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal begins with one small noticing: what is one thing you have been about to start for a long time? You do not need to start it. Just to see that it is still there, waiting, and that it has been waiting for years."
    }
   ]
  },
  {
   "id": "m02",
   "label": "2 · Where the Permission Was Withdrawn",
   "items": [
    {
     "kind": "Teaching",
     "text": "The creativity frequency is installed by a specific moment, usually in childhood, when the person was making something and something happened. It is often small — smaller than the person's adult mind would expect. A parent's comment. A teacher's correction. A sibling's laugh. A room going slightly quiet."
    },
    {
     "kind": "Teaching",
     "text": "The child, in that moment, learned something the adult cannot remember learning. That this making, here, in this form, is not entirely welcome. The child drew the natural conclusion: making is safe up to a point, and the point was reached."
    },
    {
     "kind": "Anecdote",
     "text": "A man is asked, in therapy, why he stopped drawing at nine. He says he does not know. Then, quietly, he remembers: at nine he drew a picture at school. The teacher looked at it, and said, kindly, that it was very good — for him. The 'for him' was not intended as a wound. It was meant as encouragement. He has not drawn seriously since."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is installed by the sense that the making was noticed and placed into a category. The category was usually some version of 'this is nice, considering'. The person, receiving this, learned that the making needed a defence before it could exist. The defence was impossible for a child, so the child stopped making, or made only in forms that no one could categorise."
    },
    {
     "kind": "Teaching",
     "text": "The permission is not withdrawn by cruelty. It is withdrawn by category. The person who was told their work was good, or impressive, or remarkable — was placed in a category. And categories are often more binding than criticism. Criticism can be worked with. A category becomes the shape of what the person thinks they are allowed to produce."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the installation by the shape of the person's hesitation. There is a specific memory, sometimes barely remembered, of a moment when the making was met with a response that did not match the making. That mismatched response is the frequency's origin."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal, in this module, is not to forgive the teacher, or the parent, or the sibling. It is to remember the moment — even faintly — and to see that the permission was withdrawn, not by the work, but by the response. The work was never the problem."
    }
   ]
  },
  {
   "id": "m03",
   "label": "3 · The Voice That Says Not Good Enough",
   "items": [
    {
     "kind": "Teaching",
     "text": "The creativity frequency has a voice. It is specific, it is constant, and it speaks with authority. It says: this is not good enough. It says it at the moment the work is closest to being made. Not the moment it is worst — the moment it is almost there. The frequency does not want the work to fail. It wants the work to remain in a state where it can still theoretically be good."
    },
    {
     "kind": "Teaching",
     "text": "The voice is often mistaken for a standard. The person believes they are being rigorous, disciplined, demanding of themselves. They are not. Rigour is a faculty of the mind that works on finished work. The voice that says 'not good enough' works on unfinished work and never lets it finish."
    },
    {
     "kind": "Anecdote",
     "text": "A composer has been working on the same piece for eleven years. He has played sections of it for friends. He has never finished it, and cannot explain why. In a session with a producer, he plays it. The producer says it is beautiful. The composer says it is not ready. The producer asks when it will be ready. The composer cannot answer. He has never once in eleven years been able to say when it would be ready."
    },
    {
     "kind": "Teaching",
     "text": "The voice is not the work's standard. It is the frequency's standard, and its standard is unusual. It does not want the work to be good. It wants the work to be in a state where no one can assess it. Including the person making it. That is what 'not good enough' really means — not yet, not here, not this."
    },
    {
     "kind": "Teaching",
     "text": "The voice can be recognised by its timing. It arrives just before the person is about to finish. It arrives just before the person is about to show something. It arrives at the threshold. The threshold is where the frequency is most active, because the threshold is where the work stops being a private possibility and starts being a public fact."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the voice by its language. It speaks in absolutes. It does not say 'this could be better here'. It says 'this is not good'. The absoluteness is the tell. A real assessment is specific. This is a broadcast."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one moment this week when the voice arrived — not to argue with it, not to fight it. Just to hear it, and to see that its timing is suspicious. The voice arrives at the threshold. The work was on the verge of existing."
    }
   ]
  },
  {
   "id": "m04",
   "label": "4 · The Fear of Being Seen Making It",
   "items": [
    {
     "kind": "Teaching",
     "text": "The frequency has a second face, quieter than the first and often less visible. It is the fear of being seen making the work — not the fear of the work being judged, but the fear of the act of making being witnessed. The person can tolerate being a maker in private. They cannot tolerate the process being observed."
    },
    {
     "kind": "Teaching",
     "text": "The fear of being seen making is not about competence. It is about the exposure of the person in a state of not knowing — the state the maker is actually in. The maker, while making, is uncertain, vulnerable, changing their mind, going back, doing things badly at first. That state is the state the frequency most resists showing."
    },
    {
     "kind": "Anecdote",
     "text": "A woman has been a painter for twenty years. She can show finished paintings. She cannot show the studio mid-work — even to her partner. She closes the door. She covers the easel when someone comes in. She has no explanation. The exposure of the in-progress is the thing she cannot bear. The finished is fine. The in-progress is the part of her the frequency will not permit to be seen."
    },
    {
     "kind": "Teaching",
     "text": "The frequency also uses the fear to prevent the work. If being seen making is intolerable, then the person will not make when someone might see. And since the person is not always alone, they will simply not make when they are not alone. And since life is mostly not-alone, the making becomes rare."
    },
    {
     "kind": "Teaching",
     "text": "The fear of being seen making is one of the reasons the frequency is so effective. It does not need to stop the person writing. It only needs to stop them writing when someone else is in the house. The work is not stopped. The work is heavily postponed."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the fear by the shape of the person's private habits. They work in secret. They hide drafts. They close the notebook when someone enters. They do not show the process. They show only the product, and only the polished product, and only rarely. The frequency has made a clean division: the private is permitted, the visible is not."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to let one person see one unfinished thing. Not to ask for feedback. Just to let the unfinished be seen. The discomfort is the frequency, and the discomfort is what begins the shift."
    }
   ]
  },
  {
   "id": "m05",
   "label": "5 · The Comparison Room",
   "items": [
    {
     "kind": "Teaching",
     "text": "The frequency keeps a room. In that room are all the other makers the person has ever encountered — the ones they admire, the ones they resent, the ones they have never met, the ones the algorithm keeps producing. The person enters this room, in the mind, whenever the work is about to be made."
    },
    {
     "kind": "Teaching",
     "text": "The comparison room is not an accurate room. The other makers in it are not the same age, at the same stage, doing the same work, working in the same conditions. They have been assembled by the frequency for a specific purpose — to make the person's making look foolish by comparison."
    },
    {
     "kind": "Anecdote",
     "text": "A writer in her thirties cannot start a novel. She has read a hundred debuts by writers her age. Each of them has written the novel she cannot start. She keeps a list, in her head, of the ones she is behind. The list is long. When she finally starts writing, in her forties, she discovers after three years that she was never in a race at all. The list had been entirely her own invention."
    },
    {
     "kind": "Teaching",
     "text": "The comparison room is a frequency, not a fact. It has no walls. It does not exist in any actual place. But it is where the person spends the early part of every making — checking where they sit against the imagined standard of the room."
    },
    {
     "kind": "Teaching",
     "text": "The frequency also uses the room to make the work feel derivative. Whatever the person is about to make, someone in the room has already made it better. The frequency does not tell the person to make something else. It tells them the thing they are about to make has already been made, by someone better, and the making would be a copying rather than a making."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of the person's reading, listening, and watching. The person is often drawn to the work of people who make them feel behind. Not because they enjoy it — because the frequency has taught them that this is what cultural engagement is. It is not. It is the frequency, feeding itself."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one moment this week when you entered the comparison room. Not to leave it. Just to see that you have a room of your own making, and that no one else in the room knows they are in it."
    }
   ]
  },
  {
   "id": "m06",
   "label": "6 · When the Work Is Finished and You Are Not",
   "items": [
    {
     "kind": "Teaching",
     "text": "For the person running the creativity frequency, there is a specific and unexpected difficulty: the moment of finishing. The work the frequency has permitted to exist, and permitted to be finished, arrives at the world — and the person is not done. The frequency has not been resolved by the work's completion. It has simply moved to the next problem."
    },
    {
     "kind": "Teaching",
     "text": "This is one of the clearest ways to see that the frequency is not about the work. The work was made. The work was finished. The work was shown. The frequency is still running. If the frequency were about the work, the frequency would stop. It does not."
    },
    {
     "kind": "Anecdote",
     "text": "A man spends four years on a project. He finishes it. It is released. It is well received. Within a fortnight he is back at his desk with the same feeling he had at the beginning. Not because the success has failed — because the frequency was never about success. The frequency has simply taken up residence in the next project, before he has even started it."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is not the same as ambition. Ambition wants the work to be good and to find its audience. The frequency wants the work to resolve something in the person, and the work never does. The frequency has been pointing at the work the whole time, but the thing the frequency is really about is not the work. It is the person's permission to be a maker."
    },
    {
     "kind": "Teaching",
     "text": "The frequency can also make a finished work feel like a loss. The person is briefly unmoored. The project that had been holding the frequency is gone. The frequency finds a new object immediately, but for a week or two there is a strange emptiness. The emptiness is not the work's absence. It is the frequency without a surface to attach to."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of the person's relationship to their own finished work. They rarely revisit it. They rarely feel proud of it. They rarely pause. The frequency has taught them that the finished work is a thing to move past, not a thing to enjoy. Enjoyment would delay the next work."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to sit, once, with one thing you have made, and let it be finished. Not to assess it. Not to improve it. Not to plan the next one. Just to look at it, and to know that the making of it was real."
    }
   ]
  },
  {
   "id": "m07",
   "label": "7 · The Block as a Messenger",
   "items": [
    {
     "kind": "Teaching",
     "text": "The person running the creativity frequency believes the block is the enemy. It arrives, and the person experiences it as an obstacle, a failure, a thing to be overcome with discipline, or acceptance, or a change of scene. But the block is not the enemy. The block is the frequency, visible at last."
    },
    {
     "kind": "Teaching",
     "text": "The block arrives when the person sits down to make something. It stops the making. It arrives as a blankness, a tiredness, a sudden conviction that the person should do the dishes instead. It is not a mystery. It is the frequency, arriving at the moment of making, and doing what the frequency has always done — postponing the arrival of the work."
    },
    {
     "kind": "Anecdote",
     "text": "A woman begins a painting. Within an hour she is suddenly certain the studio needs to be tidied. She tidies it. Then she is certain she needs to write a message to a friend. She writes it. Then she is certain she should read for a while first. She reads. The day is over. She has not painted. She tidies the studio the next day too. She does not notice that the painting is now three days behind and the studio has never been cleaner."
    },
    {
     "kind": "Teaching",
     "text": "The block is not the absence of something. It is the presence of something. The frequency, given a body and a time and a canvas, and asked to act. It acts by producing a substitute activity. The substitute is always plausible. It is always good. It is sometimes even useful. It is never the work."
    },
    {
     "kind": "Teaching",
     "text": "The frequency uses the block to keep the person from the threshold. The threshold is where the work becomes real, and the frequency cannot bear the reality of the work. The block is the frequency's method for holding the person one step back from the threshold, permanently."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the block by the shape of the substitute. When the person sits down to make, what do they actually do? The block is not the not-doing. The block is the list of things that are not the work, but are also not nothing. The frequency does not produce stasis. It produces redirection."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to sit, once, with the block itself, without doing anything else. Not to overcome it. Just to let the block be there, and to let the person be there, and not to leave the room. The block is the frequency. Sitting with it is the beginning of seeing it."
    }
   ]
  },
  {
   "id": "m08",
   "label": "8 · The Work That Was Not Allowed to Be Yours",
   "items": [
    {
     "kind": "Teaching",
     "text": "Some people make things, and the things that are made are not quite their own. They have learned to make in the style of the household. They have learned to write what someone else would approve of. They have learned to make the work that fits the family's idea of a maker, or the partner's, or the culture's."
    },
    {
     "kind": "Teaching",
     "text": "The frequency in these cases is a form of adaptation. The person can make, but only the permitted making. The work is smooth, competent, and slightly absent. It does not embarrass anyone. It also does not quite stand for the person who made it."
    },
    {
     "kind": "Anecdote",
     "text": "A woman writes three novels in her thirties. All published. All well received. All — she says, eventually — not hers. She had written them for a version of herself that her family would have been proud of. In her forties, she writes a fourth. It is unrecognisable to her family. It is unmistakably hers. Her career, until that point, had been running the frequency's version of the work."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is often not visible as a restriction. It shows up as taste. The person does not experience the work as forbidden. They experience their own genuine preferences as lining up with what was expected. The frequency has taught them to want what they are permitted to want."
    },
    {
     "kind": "Teaching",
     "text": "The work that is not allowed to be the person's own often appears over time to be slightly dishonest. Not because the person lied — because they were not present in it. The work is competent. The work is not inhabited."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of what the person has never made. What is the work they have wanted to make, and have not? That work is the work the frequency has been preventing. It is usually the work that would most embarrass the original household."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal, in this module, is not to reject the work that was made. It is to name, once, the work that was not. Not to make it yet. Just to admit that it exists."
    }
   ]
  },
  {
   "id": "m09",
   "label": "9 · The Discipline That Is Not Punishment",
   "items": [
    {
     "kind": "Teaching",
     "text": "The frequency uses a specific trick. It tells the person that they are not disciplined enough. If they were more disciplined, the frequency says, the work would happen. The person, hearing this, tries to become more disciplined. They schedule the work. They set a daily word count. They buy a new notebook. The work still does not happen."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is not about discipline. It is about permission. But 'discipline' is a category the person can accept. It implies a failing that can be corrected by effort, rather than a permission that has never been given. The frequency prefers the discipline explanation because it keeps the person busy, and busy is the frequency's favourite activity."
    },
    {
     "kind": "Anecdote",
     "text": "A man sets up a strict writing schedule. Up at five. Two hours before work. Six days a week. He follows the schedule for three weeks. Nothing comes. Then one Saturday, in the middle of an ordinary morning, with no schedule and no plan, a piece of writing arrives in twenty minutes. He does not understand why the schedule failed and the unplanned Saturday worked. The schedule was the frequency. The Saturday was permission."
    },
    {
     "kind": "Teaching",
     "text": "Real discipline is not the same as punishment. Real discipline is the shape a person gives to work that is already permitted to exist. Without the permission, the discipline is just a series of small punishments. With the permission, the discipline becomes a structure that the work can live inside."
    },
    {
     "kind": "Teaching",
     "text": "The frequency always recommends discipline first, because discipline can be attempted endlessly, and each failed attempt is fresh evidence for the frequency's case. The person ends up believing they are lazy, or undisciplined, or unsuited to the work — when in fact the frequency has been making the attempt, and the failure, and the conclusion."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of the person's shelves. They often own more books about making than books they have made. They have subscribed to courses. They have read about other people's routines. They have prepared for the work rather than doing it. The preparation is the frequency, in its most respectable form."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to try the opposite of discipline for one week. Not to write less. To schedule less. To prepare less. To sit down with no plan and no target and see whether the work is more or less available. The frequency will be very uncomfortable with this."
    }
   ]
  },
  {
   "id": "m10",
   "label": "10 · The Failure That Was Necessary",
   "items": [
    {
     "kind": "Teaching",
     "text": "The creativity frequency is intolerant of failure. Not of large failure — of small, ordinary, day-to-day failure. The failed draft. The abandoned song. The thing that was wrong. The frequency has taught the person to treat each failed attempt as evidence, rather than as the ordinary fact of a making life."
    },
    {
     "kind": "Teaching",
     "text": "The person who has made anything has failed more times than they have succeeded. This is not inspirational. It is arithmetic. The frequency has hidden this arithmetic from the person, and replaced it with the sense that failure is a sign of unfitness, and that a person suited to the work would not fail so often."
    },
    {
     "kind": "Anecdote",
     "text": "A man reads, at fifty, the notebooks of a painter he admires. The notebooks are full of failed attempts — wrong colours, discarded sketches, sentences that go nowhere. The man is stunned. He had imagined the admired painter produced only finished work, only good work. He had been comparing his whole messy process to someone else's edited product. He had been running the frequency's arithmetic, not the real one."
    },
    {
     "kind": "Teaching",
     "text": "The failure that is necessary is not a moral fact. It is the way making works. The person does not try and fail and then succeed. The person tries, and tries, and tries, and one of the tries is the work. All of the tries before it were not failures. They were the work, in a form that had not yet arrived."
    },
    {
     "kind": "Teaching",
     "text": "The frequency often stops the person from getting to enough attempts. It does not need to prevent the first attempt. It only needs to prevent the twenty-fifth. The twenty-fifth attempt is where the work usually arrives. The frequency knows this, and stops the person at the fourth, or the seventh, or the eleventh, where the failure is still abundant and the arrival has not yet come."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of the person's archive. They have a small number of attempts, and a large number of abandoned projects. The abandoned projects were not abandoned because they were bad. They were abandoned because the frequency arrived before enough attempts had accumulated."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to make, once this week, something deliberately bad. Not as an exercise. As a permission. The frequency will find this very difficult, and the difficulty is the whole point."
    }
   ]
  },
  {
   "id": "m11",
   "label": "11 · The Making That Continues",
   "items": [
    {
     "kind": "Teaching",
     "text": "There comes a moment in the loosening of the creativity frequency when the person realises they are still making. Not finishing. Not succeeding. Making. The act has returned. And it is not dramatic. The person does not have a breakthrough, or a new discipline, or a new project. They have simply begun to make again, sometimes, without the frequency arriving first."
    },
    {
     "kind": "Teaching",
     "text": "This is the reversal. It is not the ending of the frequency. It is the ending of the frequency's monopoly on the person's relationship to the work. The frequency continues to show up. It just does not run the whole morning."
    },
    {
     "kind": "Anecdote",
     "text": "A woman in her sixties has been writing for forty years. She published, in her twenties, and then stopped publishing for twenty years, and then began again, quietly, without any announcement. She does not describe herself as a writer. She writes. That is the whole of it. The frequency, which once ran her entire relationship with the work, is now a small voice in the corner. She is aware of it. She is not run by it."
    },
    {
     "kind": "Teaching",
     "text": "The making that continues has an unremarkable quality. It does not feel like a victory. It feels like the ordinary fact of a life where making is simply one of the things the person does. The frequency would prefer the drama — the breakthrough, the reclamation, the moment of arrival. The frequency dislikes the ordinary because the ordinary is where the frequency has no purchase."
    },
    {
     "kind": "Teaching",
     "text": "You will know the frequency is loosening when the person makes something without noticing they have made it. The work arrives, and is made, and no one — including the maker — has made an event of it. The frequency requires the event. The loosening is quiet."
    },
    {
     "kind": "Teaching",
     "text": "The making that continues is not always good. The making that continues is not always finished. The making that continues is not always shown. It is simply making, in the ordinary way, in the ordinary day. This is the shape the work takes when the frequency is no longer running it."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to make something small, today, and to let it be nothing more than that. Not a beginning. Not a project. Not a statement. Just a thing made, in a life that makes things."
    }
   ]
  },
  {
   "id": "m12",
   "label": "12 · Recalibrating",
   "items": [
    {
     "kind": "Teaching",
     "text": "The recalibration of the creativity frequency is not the achievement of a productive, disciplined, regularly outputting creative life. It is not the arrival at the perfect routine, or the discovery of a muse, or the abandonment of the inner critic. It is the slow, patient practice of letting the work arrive when it arrives, and letting it be what it is, and letting it be seen or not seen by the same permission that made it."
    },
    {
     "kind": "Teaching",
     "text": "The creativity frequency does not disappear. It was installed early, in a household, in a moment the person cannot quite remember. It will return in the presence of certain people, in certain rooms, in the moments of exposure. What changes is that the person can see it running, and can choose — sometimes — to make anyway."
    },
    {
     "kind": "Anecdote",
     "text": "Two people with the same talent, the same inclination, the same years available. One spends her life preparing, reading about the work, planning projects, buying notebooks, waiting for the right conditions. The other, with no more talent and no more time, quietly makes things. Ten years later, the first has a beautiful studio and no finished work. The second has a small body of work and no studio. The difference was not talent or dedication. It was permission. One had been given it, or had taken it. The other was still waiting to be given it."
    },
    {
     "kind": "Teaching",
     "text": "You will know the frequency is shifting when the person makes something without the third-page feeling. When a small amount of work arrives and it does not have to be finished to be real. When the notebooks get a bit further in. When the studio gets slightly untidier because it is being used."
    },
    {
     "kind": "Teaching",
     "text": "The creativity frequency is one of the deepest sectors in this course, because it is not about a mood or a fear. It is about the person's relationship to their own making — and the making is not separate from the person's life. The work that was never made is the life that was never quite lived. The permission the person withholds from the work is the permission they withhold from themselves."
    },
    {
     "kind": "Teaching",
     "text": "You were not born with a standard. You were given one. The people who gave it to you were given one before that, by people who were told that making is a thing to be assessed, rather than a thing to be done. The standard is a chain. It can be set down — not by making better work, but by noticing that the work was never the problem."
    },
    {
     "kind": "Recalibration",
     "text": "The same blank page. The same afternoon. Two different permissions. You have just read an entire sector about the space between them. That space is the whole of this course — and, in creativity, it is the space where the work is finally allowed to exist."
    }
   ]
  }
 ]
};
