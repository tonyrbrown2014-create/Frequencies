window.FREQ_SECTOR={
 "key": "solitude",
 "title": "Solitude",
 "glyph": "◕",
 "blurb": "Alone as punishment, or alone as room. The frequency of what being by yourself means — and what opens when solitude stops being exile.",
 "philTitle": "Solitude · The Fear Frequency & The Reversal",
 "philText": "Solitude is not the problem. The frequency that has decided what being alone means is the problem. This sector is not about whether a person likes company — it is about the quiet assumption, installed long before the first evening alone, that solitude is either a punishment or a defect, and never simply a room. It is about the moment the person can be alone without it meaning anything.",
 "modules": [
  {
   "id": "m01",
   "label": "1 · The Room You Are Afraid Of",
   "items": [
    {
     "kind": "Teaching",
     "text": "There is a room in every life that some people can enter and some people cannot. It is the room of being alone. Not lonely — alone. The state of having no one to be with, and nothing to be doing, and no screen and no task between the person and their own company. Some people walk into this room without thinking. Many do not. Many have not been in it for years."
    },
    {
     "kind": "Teaching",
     "text": "The solitude frequency is the set of assumptions about what that room is. It has been installed early, usually by a specific household in a specific cultural moment, and it arrives with a verdict already attached. The room is either a place of rest or a place of exile. A person who was given the first will seek the room out. A person who was given the second will avoid it for the rest of their life."
    },
    {
     "kind": "Anecdote",
     "text": "A woman in her thirties lives alone for the first time. She has always shared flats, always had a partner, always had flatmates. Within a week she is sleeping badly and cannot explain why. She has no fear of the dark. She has no reason to be unhappy. She simply cannot be in the flat by herself in the evenings. She starts going to the gym at nine o'clock, and then to a café, and then to a friend's. She has not been alone in an evening, in her own home, in six months."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is not the same as introversion or extroversion. Those are temperaments, and both introverts and extroverts can be at peace with solitude or afraid of it. The frequency is about meaning. What does being alone mean to the person? That meaning, not the temperament, is what determines whether the room is habitable."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is often inherited. A parent who could not be alone raises a child who cannot be alone. A parent who sought solitude raises a child who seeks it. The child receives the meaning of the room along with everything else in the household, and by the time the person is an adult, the meaning feels like a fact."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of the person's evenings. What does the person do when no one is asking anything of them? Do they sit down? Do they read? Do they move through the house slowly? Or do they immediately begin looking for someone, or something, to fill the room with? The shape of the evening is the shape of the frequency."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal begins with one small noticing: when did you last spend an hour alone, with no task and no screen and no one to speak to? You do not need to plan one. Just to notice how long it has been."
    }
   ]
  },
  {
   "id": "m02",
   "label": "2 · The Household That Taught You What Alone Means",
   "items": [
    {
     "kind": "Teaching",
     "text": "The meaning of being alone is installed by the household, but not in the way the person usually imagines. It is not installed by a parent saying 'being alone is bad'. It is installed by the parent's own relationship to their own solitude — by what the parent did with their evenings, by how they moved through the house when no one was watching."
    },
    {
     "kind": "Teaching",
     "text": "A child watches. A child notices when a parent is alone. A parent who sat quietly and read, who went for a walk, who stood in the kitchen for a few minutes with a cup of tea — that parent showed the child that being alone is a room that can be entered. A parent who was anxious, who phoned someone immediately, who turned the television on the moment they were alone — that parent showed the child the opposite."
    },
    {
     "kind": "Anecdote",
     "text": "A man realises in his fifties that he has never seen either of his parents be alone. His mother was always on the phone. His father was always busy. He does not have a memory of either of them simply sitting in a room by themselves, doing nothing in particular. He is the same. He has been the same for fifty years. He had assumed this was simply what people were like."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is also installed by what happened in the house when someone was alone. A parent whose solitude was interrupted, criticised, or constantly disturbed by another parent transmits a meaning to the child — that solitude is not safe, or not permitted, or not a thing this household does."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the installation by the shape of the person's own evenings. They often replicate the household's evenings without noticing. The same television in the same room. The same phone call at the same hour. The same difficulty sitting still. The person has been running the household's evening their whole adult life."
    },
    {
     "kind": "Teaching",
     "text": "This is not a moral inheritance. It is a transmission. The parent who could not be alone was often a parent who had never been taught that it was safe to be alone. The chain is old, and none of the links chose it."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one thing your household did with its evenings, and to see it as a household's choice rather than the shape of all evenings everywhere. Not to change it. Just to see it as a choice."
    }
   ]
  },
  {
   "id": "m03",
   "label": "3 · The Company That Is Not Company",
   "items": [
    {
     "kind": "Teaching",
     "text": "The solitude frequency has a distinctive modern disguise. It does not require the person to be around other people. It only requires the person to be around something. The phone. The television. The podcast. The endless scroll. These are not company, but they are close enough that the frequency cannot tell the difference."
    },
    {
     "kind": "Teaching",
     "text": "Many people running the frequency believe they are comfortable alone, because they spend a great deal of time alone. They live alone. They eat alone. They work alone. But they are never actually alone. The phone is always on. The podcast is always playing. There is always a screen, a voice, a scroll. The room is empty of others, but it is not empty."
    },
    {
     "kind": "Anecdote",
     "text": "A woman describes herself as someone who likes her own company. She is asked, gently, when she last sat in silence for fifteen minutes. She cannot answer. She is not a person who is comfortable alone. She is a person who is very good at filling the room with low-level company that does not require her to speak. She has not been alone in years, and the frequency has convinced her she is good at it."
    },
    {
     "kind": "Teaching",
     "text": "The frequency uses the noise as proof. It says: see, you are alone. You are fine. But the person is not alone, in the sense the frequency was supposed to test. The person is with the phone. The frequency has not been asked the actual question — whether the person can be in a room with only themselves — because the person has never quite been in that room."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of the person's silence. What happens when the phone is in another room, the television is off, and there is nothing to read? Not for a minute — for an hour. If the person has not been in that situation for years, the frequency is running, whatever the person believes about themselves."
    },
    {
     "kind": "Teaching",
     "text": "The reversal, in this module, is not to abandon technology. It is to see that the frequency has been calling the noise 'company'. Once that is seen, the room can be entered on the person's own terms, at their own pace."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to spend fifteen minutes alone, today, with no phone in the room and no sound playing. Not as a test. As a small experiment. Notice what arrives."
    }
   ]
  },
  {
   "id": "m04",
   "label": "4 · The Solitude That Was Called Loneliness",
   "items": [
    {
     "kind": "Teaching",
     "text": "The frequency often uses the word loneliness to describe a state that is not quite loneliness. Loneliness is the felt absence of connection. What the frequency calls loneliness is often simply the felt absence of distraction. The person is not missing anyone. They are missing the noise."
    },
    {
     "kind": "Teaching",
     "text": "This is one of the frequency's most effective confusions. A person sits alone for ten minutes, feels the room go quiet, and the frequency labels the feeling loneliness. The person then reaches for the phone, because loneliness is not a thing to sit with. The label has produced the action. The action has confirmed the label."
    },
    {
     "kind": "Anecdote",
     "text": "A man realises that the feeling he has been calling loneliness for years arrives specifically at two moments: when he first gets home in the evening, and when he wakes up in the morning. Both moments are simply the moments when he is alone and undistracted. He had assumed, for decades, that he was a person who was lonely. He is a person who is uncomfortable with the arrival of stillness."
    },
    {
     "kind": "Teaching",
     "text": "Real loneliness is real, and does not need to be reframed. It is the presence of an absence. What the frequency does is to name the absence of distraction 'loneliness', and then use the name to prevent the person from ever being still."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the confusion by the shape of the person's answer to 'how are you'. They say lonely. But when asked what specifically they are missing, there is no person, no event, no relationship. Only a general sense of emptiness that arrives when the room is quiet. The emptiness is the room, not the missing."
    },
    {
     "kind": "Teaching",
     "text": "The distinction matters, because the two states have different remedies. Loneliness is answered by connection. The other state is answered by learning to be with the room. The frequency has been sending the person toward the first remedy, which does not quite work, because the room is still the room."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one moment this week when you called a feeling loneliness, and to ask whether the feeling was actually about someone — or about the silence. The silence is not a wound. The silence is a state."
    }
   ]
  },
  {
   "id": "m05",
   "label": "5 · The Solitude That Is Not Chosen",
   "items": [
    {
     "kind": "Teaching",
     "text": "Not all solitude is the same. There is a specific kind of solitude that is not chosen — the solitude of the person whose marriage has ended, whose friends have moved, whose children have left, whose work has collapsed. This solitude is not the room a person enters. It is the room a person finds themselves in, sometimes without warning, sometimes for years."
    },
    {
     "kind": "Teaching",
     "text": "The frequency handles this solitude differently. It reads it as proof of the person's unworthiness, or unattractiveness, or basic unlikeability. The frequency says: this is where you were always going to end up, and everyone can see it. This is not the same as the ordinary fear of being alone. It is the fear of being alone because the person has failed to be wanted."
    },
    {
     "kind": "Anecdote",
     "text": "A woman is widowed in her sixties. Her husband was not perfect, and their marriage was ordinary, and she loved him. He was the person she spoke to about the day. When he dies, she is alone, and the frequency arrives immediately with a story: that she was not enough for the marriage, that she was never someone people wanted, that this is what she deserved. None of the story is true. The frequency has simply taken the fact of the solitude and turned it into evidence."
    },
    {
     "kind": "Teaching",
     "text": "The unchosen solitude is often the most difficult, because the person has not consented to it. The chosen solitude is a room a person enters. The unchosen solitude is a room a person is placed in. The frequency does not distinguish. It treats both as evidence."
    },
    {
     "kind": "Teaching",
     "text": "The frequency also uses the unchosen solitude to make the person unavailable for the chosen kind. When the person's solitude is a wound, they cannot be alone by choice. Being alone is always the wound. The chosen solitude has been contaminated by the unchosen one."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of the person's response to an evening alone. If the evening is spent quietly and the next morning the person wakes up convinced they need to do something about their life, the frequency has been at work. The evening was not the problem. The interpretation of the evening was."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal, in this module, is not to stop wishing the unchosen solitude were different. It is to notice that the frequency has been treating the unchosen solitude as evidence about who the person is. The solitude is a fact. The evidence is an invention."
    }
   ]
  },
  {
   "id": "m06",
   "label": "6 · The Solitude That Was Taught to Be Selfish",
   "items": [
    {
     "kind": "Teaching",
     "text": "For many people, particularly those raised in households where care for others was the central organising value, solitude was taught to be a form of selfishness. To be alone was to be unavailable. To take time for oneself was to take something from someone else. The person learned that solitude was permitted only after the needs of others were met, which is to say, never."
    },
    {
     "kind": "Teaching",
     "text": "The frequency in these lives is not a fear of being alone. It is a fear of being perceived as abandoning someone. The person can be alone in the bathroom, or in the car, or on a walk that is technically for exercise. But real solitude — sitting in a room, on purpose, for its own sake — arrives with guilt."
    },
    {
     "kind": "Anecdote",
     "text": "A woman realises that she has not been alone on purpose since her children were born. Her children are now adults. She still cannot sit down in a room without a task. Every single thing she does in her own home is for someone, or on behalf of someone, or preparatory for someone. She is not a martyr. She is a person who has never once been taught that sitting alone was not a small theft."
    },
    {
     "kind": "Teaching",
     "text": "The frequency in these lives is often inherited from a parent who was also never permitted solitude. A mother who never rested transmitted to her child the lesson that rest required an excuse. The child learned to produce excuses. The adult produces them without noticing."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of the person's reasons. When they sit down, there is always a reason. A cup of tea. A book. A phone call with a friend. The sitting itself is never the activity. Something is always being done."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is also visible in the shape of what the person would feel if they simply sat. Not rested — sat. The guilt that would arrive is the frequency, and the guilt would be the exact measure of how deeply the meaning was installed."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to sit, once, in the middle of a day, on purpose, with no task and no phone, for ten minutes, and to let the guilt be there if it arrives. The guilt is not a signal. The guilt is the frequency."
    }
   ]
  },
  {
   "id": "m07",
   "label": "7 · The Solitude That Becomes Loneliness When Watched",
   "items": [
    {
     "kind": "Teaching",
     "text": "There is a strange trick of the frequency. The same evening alone can be a quiet rest or an unbearable loneliness depending on whether the person is watching the evening. Not watching a screen — watching the evening. Observing themselves having it. The witness is the frequency, and the witness makes the difference."
    },
    {
     "kind": "Teaching",
     "text": "The person who is simply alone, doing what they do, reading, cooking, listening to music, is not lonely. The person who is alone and watching themselves be alone — thinking 'I am alone, this is what being alone looks like, this is what I have become' — is lonely. The loneliness is not in the room. It is in the observation of the room."
    },
    {
     "kind": "Anecdote",
     "text": "A man spends an evening alone at home. He cooks something. He watches an old film. He goes to bed. He feels fine. The next morning he tells a friend he spent the evening alone and, hearing himself say it, feels a pang. The pang was not there last night. It arrived this morning, in the retelling. The frequency had not been present the night before. It arrived with the witness."
    },
    {
     "kind": "Teaching",
     "text": "This is one of the deepest moves of the frequency. It does not need to be present in the room. It only needs to be present in the person's account of the room. The evening becomes lonely when it is described as lonely. The description is the frequency, arriving after the fact."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of the retelling. How does the person describe their time alone? If the time is described as a fact — 'I cooked, I watched a film' — the frequency was not present. If the time is described with a small apology, or a justification, or a resigned tone — 'I just stayed in, I didn't do anything' — the frequency has arrived to reframe the evening as a small defeat."
    },
    {
     "kind": "Teaching",
     "text": "The reversal is to catch the retelling before it happens. To sit alone without immediately narrating the sitting. Not to defend the solitude. Just to let it not be an event that needs an account."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to spend one evening alone this week, and to let the evening end without the retelling. Not because retelling is wrong — because the retelling is the frequency, and the evening was fine on its own."
    }
   ]
  },
  {
   "id": "m08",
   "label": "8 · The Person Who Cannot Be Alone and the Person Who Cannot Be With",
   "items": [
    {
     "kind": "Teaching",
     "text": "The solitude frequency has two faces, and they are not opposites. There is the person who cannot be alone, and the person who cannot be with. Both are running the same frequency. Both are reacting to the same assumption about what company and solitude mean."
    },
    {
     "kind": "Teaching",
     "text": "The person who cannot be with is often quieter about it. They are not afraid of a crowd, or of a party, or of a conversation. They are afraid of a specific kind of closeness — the closeness of being known by someone for a long time, of being depended on, of having to stay. They find reasons to leave. They work late. They have a busy period that never quite ends. They are running the frequency from the other side."
    },
    {
     "kind": "Anecdote",
     "text": "A man is described by his friends as a person who cannot commit. He has been in relationships, but they end, always for reasons that seem reasonable at the time. In his fifties he realises something. The ending is not about the person he is with. It is about the ending itself. He ends things because ending things keeps him safe. He has been alone in every relationship, by design, for decades."
    },
    {
     "kind": "Teaching",
     "text": "The person who cannot be with is not actually comfortable alone. They are comfortable with solitude as long as no one is close. The moment someone is close, the frequency starts looking for exits. The frequency is not about company. It is about the specific risk of being known."
    },
    {
     "kind": "Teaching",
     "text": "The two faces are often found in the same family. A parent who could not be alone raises a child who cannot be with, because the child's way of coping was to keep distance. A parent who could not be with raises a child who cannot be alone, because the child's way of coping was to fill the room."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the second face by the shape of the person's relationships. They are usually warm, usually liked, usually successful in the early part of any connection. What they cannot do is the middle. The middle is where the frequency acts, and the middle is where the exits begin to appear."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice which face is yours — or whether the frequency runs both, in different rooms and different decades. Not to change the pattern. To see it as a pattern, and not a personality."
    }
   ]
  },
  {
   "id": "m09",
   "label": "9 · The Solitude That Is Not Held",
   "items": [
    {
     "kind": "Teaching",
     "text": "One of the frequency's quieter moves is to keep the person's solitude unheld. Not to prevent it — to prevent the person being rested by it. The person can be alone, but the aloneness is always slightly used, slightly productive, slightly justified. The solitude is permitted but it is never simply received."
    },
    {
     "kind": "Teaching",
     "text": "Held solitude is the state of being alone and being rested by it. Not by doing anything. Just by being in the room, with the room, and letting the room do what rooms do. Held solitude is where the body recovers. Held solitude is where thinking softens. Held solitude is often where the person finally hears something they have been avoiding hearing."
    },
    {
     "kind": "Anecdote",
     "text": "A woman takes a week's holiday alone. She has been looking forward to it for months. She packs her books, her notebooks, her camera, her walking shoes. Each day is full. She comes home more tired than when she left. She did not have a week of solitude. She had a week of tasks, alone. She had been alone, but she had not been held by it."
    },
    {
     "kind": "Teaching",
     "text": "The frequency does not have to prevent solitude. It only has to prevent the solitude from being received. The person can be alone for hours, and the hours can be entirely filled. The frequency does not care about the aloneness. It cares about the resting."
    },
    {
     "kind": "Teaching",
     "text": "The person often believes they are resting. They are not resting. They are managing the solitude. The management is the frequency, doing what it has always done, in a new room."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of the tiredness that arrives after a period of solitude. If the person comes home tired, the solitude was used. If the person comes home quiet, the solitude was held. The quietness is the tell."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to plan one hour of held solitude this week — no books, no music, no task. Not to be productive in the hour. Not even to rest in the hour. To be in the hour, without doing anything in it, and see whether the body can let itself be held by the room."
    }
   ]
  },
  {
   "id": "m10",
   "label": "10 · The Solitude That Arrives Without Warning",
   "items": [
    {
     "kind": "Teaching",
     "text": "There is a specific kind of solitude that arrives without warning. A friend dies. A partner leaves. A group disperses. A person moves to a new city where they know no one. The life has not been abandoned by the person — the life has been rearranged around them. And in the middle of the rearrangement, the person finds themselves alone in a way they did not plan."
    },
    {
     "kind": "Teaching",
     "text": "This sudden solitude is often the moment the frequency most resists. The person has been running a life organised around company. The company is gone. The frequency is now facing the room it has been avoiding for decades, without the ordinary filler the person has used."
    },
    {
     "kind": "Anecdote",
     "text": "A man moves cities for a new job. For the first two weeks he is busy with the move, the settling, the setup. In the third week, on a Saturday, with the flat finished and nothing to do, he sits down and finds the room unbearable. He had not known he had been afraid of his own company. He had been travelling through a life that did not have room for that question. The room had been waiting for him."
    },
    {
     "kind": "Teaching",
     "text": "The sudden solitude is often where the person learns who they actually are. Not as a philosophy — as a fact. When the filler is gone, what remains? A person who reads, or walks, or sits still, or is uncomfortable, or is at peace. The remaining is not discovered in the busy life. It is discovered in the sudden room."
    },
    {
     "kind": "Teaching",
     "text": "The frequency often uses the sudden solitude to convince the person that they need to do something immediately. Join a club. Sign up to a course. Start dating again. Reach out to a group. The activity is not always wrong — but the timing is often the frequency's, not the person's. The frequency wants the room filled before the person has had a chance to be in it."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise this by the shape of what the person does in the first month. If the room is filled in the first week, the frequency has arrived early. If the person allows a month or two of the room before deciding what to do with it, the frequency has been at least partially recognised."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is not to refuse the activities. It is to refuse them for the first month, on principle, and see what the room is like when it is actually empty. The activities will still be available afterward."
    }
   ]
  },
  {
   "id": "m11",
   "label": "11 · The Solitude That Becomes a Home",
   "items": [
    {
     "kind": "Teaching",
     "text": "There comes a moment in the loosening of the solitude frequency when the person realises — often without drama — that they are at home in their own company. Not that they prefer it, or that they have become hermits, or that they no longer want people. Simply that the room is no longer a threat. They can enter it. They can be in it. They can leave it."
    },
    {
     "kind": "Teaching",
     "text": "This is the reversal. It is not the ending of the person's social life. It is the ending of the frequency's verdict on the person's social life. The person still does everything they did. They simply no longer depend on the company to make the room habitable."
    },
    {
     "kind": "Anecdote",
     "text": "A woman in her fifties, who has been alone for a few years after a long marriage, is asked how she is finding it. She says she is finding it quiet. Then she says: but I have started to like quiet. She does not say this as a declaration. She says it as an observation. The frequency is no longer narrating her evenings. She is simply having them."
    },
    {
     "kind": "Teaching",
     "text": "The solitude that becomes a home does not feel like a solution. It feels like an ordinary state — like the way a person feels about their kitchen, or their car, or their own hands. It is not a triumph. It is a fact. The fact is what has changed."
    },
    {
     "kind": "Teaching",
     "text": "You will know the frequency is loosening when the person stops narrating their solitude. Not because they are keeping it secret — because there is nothing to narrate. It was a Tuesday evening. They cooked. They read. They went to bed. The frequency has nothing to add."
    },
    {
     "kind": "Teaching",
     "text": "The solitude that becomes a home is not permanent. The frequency returns at certain moments — a weekend with no plans, a holiday alone, a period between relationships. What changes is the return. It becomes a familiar visitor, not the running commentary."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to spend one evening this week alone, and to let the evening end without an internal account of it. Not because the account is wrong — because the account is optional, and the evening is enough."
    }
   ]
  },
  {
   "id": "m12",
   "label": "12 · Recalibrating",
   "items": [
    {
     "kind": "Teaching",
     "text": "The recalibration of the solitude frequency is not the achievement of a life of chosen isolation. It is not the cultivation of monastic habits, or the loss of the wish for company, or the arrival at a state of pure self-sufficiency. It is the slow, patient practice of letting being alone mean what it actually means — a state, a room, a fact — and not what the frequency has been telling the person it means."
    },
    {
     "kind": "Teaching",
     "text": "The solitude frequency does not disappear. It has been installed early, in a household, in a specific time and culture. It will return in the moments of unchosen loneliness, in the presence of certain people, in the evenings that feel unaccountably heavy. What changes is that the person can see the frequency running, and can choose not to obey it."
    },
    {
     "kind": "Anecdote",
     "text": "Two people reach fifty in similar circumstances — single, in their own flats, with work and friends. One spends the following decade trying to fill the room. Classes, clubs, dating apps, holidays planned two years ahead, always a call on the way home. The other, quietly, does much the same things — but with a different relationship to the evenings that are not filled. Ten years later, the first is exhausted and still slightly afraid of Sunday nights. The second has the same Sundays and is not afraid of them. Neither has more or less of anything. One has stopped finding the room threatening."
    },
    {
     "kind": "Teaching",
     "text": "You will know the frequency is shifting when the person can be alone on a Saturday night without the evening becoming a small verdict. When the empty hour between two things does not require filling. When being alone is simply a state the person is in, not a fact about them."
    },
    {
     "kind": "Teaching",
     "text": "The solitude frequency is one of the deepest sectors in this course, because it is not really about being alone. It is about the person's relationship to their own company — and the relationship to one's own company is the relationship to the self. The person who cannot be alone is often the person who has not been introduced, properly, to themselves."
    },
    {
     "kind": "Teaching",
     "text": "You were not born with a verdict on the room. You were given one. The people who gave it to you were given one before that, by people who were told that being alone was a punishment, or a defect, or a thing to be avoided. The verdict is a chain. It can be set down — not by learning to like being alone, but by noticing that being alone was never the problem."
    },
    {
     "kind": "Recalibration",
     "text": "The same evening. The same room. Two different meanings. You have just read an entire sector about the space between them. That space is the whole of this course — and, in solitude, it is the space where the person finally meets the company they will never be without."
    }
   ]
  }
 ]
};
