window.FREQ_SECTOR={
 "key": "feeling",
 "title": "Feeling",
 "glyph": "❁",
 "blurb": "The whole course, in one place. Not a summary of the other nineteen sectors — an illumination of them. How the mind creates the feeling, how the feeling confirms the assumption, and the moment the loop is seen.",
 "philTitle": "Feeling · The Fear Frequency & The Reversal",
 "philText": "Feeling is not the problem. The assumption that feeling is a fact about the world is the problem. This sector is not a summary of the other nineteen — it is the illumination of them. Every sector has been running the same mechanism in a different room: an assumption arrives before a thought, the thought produces a feeling, the feeling confirms the assumption, and the loop closes. This sector is where the loop is finally seen. It is about the moment a person notices that what they feel is not what is happening.",
 "modules": [
  {
   "id": "m01",
   "label": "1 · The Feeling Is Not the Fact",
   "items": [
    {
     "kind": "Teaching",
     "text": "Every sector in this course has been describing the same mechanism in a different room. An assumption arrives — before any thought, before any decision. The assumption produces a thought. The thought produces a feeling. The feeling is then read by the person as a fact about the world. This is the loop. This sector names it directly."
    },
    {
     "kind": "Teaching",
     "text": "The feeling is real. That has never been in question. The feeling is a physiological event — the chest tightening, the stomach dropping, the warmth arriving, the breath shortening. What is not real is the claim the feeling makes. The feeling says: something is wrong. The feeling says: this is dangerous. The feeling says: you are in trouble. The feeling is not the fact. The feeling is the interpretation of the fact, arriving as if it were the fact itself."
    },
    {
     "kind": "Anecdote",
     "text": "A woman receives an email from a colleague and feels a small drop in her stomach. She reads it again. It is neutral. She reads it a third time. It is still neutral. The drop in her stomach came before she read it. The drop is not about the email. The drop is the frequency, arriving first, and inviting her to interpret the email as its cause."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is not the feeling. The frequency is the assumption that organised the feeling before the feeling arrived. In the example above, the woman was already running an assumption — perhaps that her colleague was disappointed in her, perhaps that she is always about to be told off. The email arrived into that assumption. The feeling was produced by the assumption, not by the email."
    },
    {
     "kind": "Teaching",
     "text": "This is the deepest move of the whole course. Every sector has been running this mechanism in a specific territory. Money. Love. Voice. Death. The feeling is always the visible surface. The frequency is always the invisible organisation of the surface. This sector is where the two are finally separated."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the mechanism by the shape of the speed. Feelings produced by the frequency arrive fast — faster than thinking. This is why they feel like facts. A fact is something you do not have to think about. The frequency has arranged the feeling to arrive already organised, so it appears the way a fact appears."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal begins with one small noticing: in the last hour, did a feeling arrive faster than thinking? Not to question the feeling. Just to notice the speed, and to notice that a speed like that is not a fact. It is a frequency."
    }
   ]
  },
  {
   "id": "m02",
   "label": "2 · The Assumption That Arrives Before the Thought",
   "items": [
    {
     "kind": "Teaching",
     "text": "If the feeling is not the fact, what is underneath the feeling? The assumption. Not the belief the person could state if asked — the assumption that arrived before any statement. The one that has been running since before the person could speak about it."
    },
    {
     "kind": "Teaching",
     "text": "Assumptions are not thoughts. They are the ground on which thoughts stand. When a person thinks about money, they are thinking within an assumption about money. When a person thinks about their body, they are thinking within an assumption about the body. The thinking is visible. The assumption is not."
    },
    {
     "kind": "Anecdote",
     "text": "A man is told, in conversation, that a friend has been diagnosed with an illness. The man's first thought is a small one — a practical one. His second thought is a larger one: I might have that. The second thought arrived automatically. He had not decided to have it. It had been lying in wait. The assumption — that his body is under threat — was already there, and the news simply gave it a reason to speak."
    },
    {
     "kind": "Teaching",
     "text": "The assumption is not chosen. It was installed. It arrived in the first years of life, from a household, a family, a culture, a first frightening experience. By the time the person is an adult, the assumption is invisible because it is the ground, and ground is hard to see."
    },
    {
     "kind": "Teaching",
     "text": "The assumption is not the same as a belief. A belief can be argued with. An assumption cannot, because the person does not experience it as a position. They experience it as the shape of reality. When the course says 'frequencies,' it means these assumptions — the invisible, unexamined ground on which the visible life is standing."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the assumption by the shape of the second thought. The first thought is usually practical. The second thought is usually a verdict. It is the second thought the assumption produces. The first thought was just thinking. The second thought is the frequency."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one second thought this week — a verdict that arrived without being asked for. Not to argue with it. Just to notice that it arrived already formed, and that it arrived from somewhere."
    }
   ]
  },
  {
   "id": "m03",
   "label": "3 · The Loop That Closes",
   "items": [
    {
     "kind": "Teaching",
     "text": "The mechanism has a feature that makes it unusually effective. The feeling it produces then becomes evidence for the assumption that produced it. The loop closes. The assumption is confirmed by the feeling it has generated. The person believes they are responding to the world. They are responding to a closed circuit they themselves are running."
    },
    {
     "kind": "Teaching",
     "text": "This is why the frequencies are so durable. Each sector in this course has been describing a loop that has been running since childhood. The person receives evidence for the assumption every day — but the evidence is being produced by the assumption. The frequency is not being disproved. It is being fed."
    },
    {
     "kind": "Anecdote",
     "text": "A man is running the health frequency. He notices a twinge in his chest. The assumption produces a thought: this is the beginning of something. The thought produces a feeling: fear. The fear produces another thought: the fear must mean something. The man calls the doctor. The doctor says it is nothing. The man is relieved for a day. The next twinge arrives, and the loop closes again. The doctor's reassurance has not disproved the assumption. It has simply been filed as a temporary exception."
    },
    {
     "kind": "Teaching",
     "text": "The loop is often not broken by new information, because the assumption is not in the market for new information. The assumption is generating its own evidence. The only way out is to see the loop itself — to notice, in real time, that the feeling is not evidence for the assumption, because the feeling was produced by the assumption."
    },
    {
     "kind": "Teaching",
     "text": "This is what every sector in this course has been trying to do — to move the person, briefly, outside the loop, so they can see it running. The recalibrations in each sector have been small moves out of the loop. This sector names the loop directly."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the loop by the shape of the person's self-diagnosis. When a person is asked why they feel the way they feel, they will cite the evidence. But if you trace the evidence back, the evidence is the feeling, and the feeling came from the assumption. The loop is closed. There is no outside evidence being consulted."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one moment this week where the feeling was confirmed by a feeling. Not to break the loop. Just to see it, briefly, from outside."
    }
   ]
  },
  {
   "id": "m04",
   "label": "4 · The Three Layers of a Single Feeling",
   "items": [
    {
     "kind": "Teaching",
     "text": "Most feelings the person experiences are not one thing. They are three things stacked. The first is the raw sensation — the chest tightening, the stomach dropping, the warmth rising. The second is the interpretation — this is fear, this is shame, this is anger. The third is the meaning — this is happening because of X, this is a fact about Y, this is what Z means."
    },
    {
     "kind": "Teaching",
     "text": "The frequency runs at layer three. It is the meaning-making layer. But the frequency is often invisible because the person experiences all three layers as one. They say 'I feel anxious,' as if the feeling and the meaning arrived together. They did not. The sensation arrived first. The interpretation arrived as a name. The meaning arrived as a verdict. All three were produced, not found."
    },
    {
     "kind": "Anecdote",
     "text": "A woman feels a tightness in her chest. She names it fear. She names the fear as being about her partner, who has been quiet all evening. She has now completed the sequence: sensation, interpretation, meaning. Her partner is quiet because he is tired. The meaning the woman arrived at was not about her partner. It was about her assumption — that a quiet partner is a partner about to leave."
    },
    {
     "kind": "Teaching",
     "text": "Layer one is real and cannot be argued with. The chest tightened. It is not necessary to argue with the sensation. Layer two is a name. It is a useful name, but it is a name. Layer three is the frequency. This is where the entire course has been running."
    },
    {
     "kind": "Teaching",
     "text": "The three layers are often collapsed by language. The word 'feel' does all three at once. 'I feel afraid' contains a sensation, an interpretation, and usually a meaning, all in three words. The frequency uses the word to hide the layers."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the layers by the shape of the sentence. When a person says 'I feel X because of Y,' they have revealed the meaning layer. When they say 'I feel X,' they have hidden it. The hidden layer is where the frequency is."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to slow one feeling down, once this week, and to notice the three layers. The sensation. The name. The meaning. Not to change any of them. To see that they are three things, not one."
    }
   ]
  },
  {
   "id": "m05",
   "label": "5 · The Feeling That Was Named Wrong",
   "items": [
    {
     "kind": "Teaching",
     "text": "Many of the feelings the person is running are not the feelings the person believes they are running. The assumption does not always produce the obvious emotion. It produces whatever emotion is permitted. And what is permitted is often not the truth of what is being felt."
    },
    {
     "kind": "Teaching",
     "text": "A person running the anger frequency, but in a body where anger is not permitted, will experience the anger as sadness. A person running the fear frequency, in a body where fear is shameful, will experience the fear as irritation. A person running the love frequency, in a body where wanting is not permitted, will experience the wanting as indifference. The feeling was named wrong. The frequency, underneath, is unchanged."
    },
    {
     "kind": "Anecdote",
     "text": "A woman describes herself as a person who cries easily. She cries at films, at adverts, at other people's happiness. When asked what she cries about, she cannot say. The tears are not connected to a specific sadness. They are the release valve for a larger feeling that does not have a name in her life. She has been running an anger frequency, in a body where anger was not permitted, for decades. The tears are the anger, arriving in the only form the body will allow."
    },
    {
     "kind": "Teaching",
     "text": "The person running the frequency does not know the feeling was named wrong. They have a genuine sadness, or a genuine irritation, or a genuine indifference. The frequency has hidden itself inside a mislabel. This is why the course is about the assumption and not about the emotion. The emotion is often a decoy."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the mislabel by the shape of the person's reactions. When the reaction is disproportionate to the situation, but the situation is not the original, the feeling is probably the wrong name for something older. The frequency is using the mislabel to keep the assumption out of view."
    },
    {
     "kind": "Teaching",
     "text": "The reversal is not to find the correct name. The reversal is to notice that the name might not be correct. The noticing is enough. The frequency has been counting on the name being accepted at face value."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to ask, once, of one feeling you have been having for a long time: is this feeling actually what I have been calling it? The question does not need an answer. The question weakens the frequency's monopoly on the name."
    }
   ]
  },
  {
   "id": "m06",
   "label": "6 · The Feeling That Is Not Yours",
   "items": [
    {
     "kind": "Teaching",
     "text": "Some of the feelings a person is running are not theirs. They are inherited, or transmitted, or absorbed. A parent's grief running in a child's chest. A family's anger, or fear, or shame, arriving in a body that did not originate it. The person experiences the feeling as their own. The feeling was handed to them before they could refuse."
    },
    {
     "kind": "Teaching",
     "text": "The inherited feeling is often more difficult to see than the personal one, because it does not have a story attached. The person cannot say when it started, or what it is about, or who it belongs to. It simply has been present for as long as the person can remember. This is the signature of the inherited feeling."
    },
    {
     "kind": "Anecdote",
     "text": "A man carries a low-grade dread for most of his adult life. Nothing in his life explains it. He has been to doctors. He has been to therapists. Nothing has quite touched it. In his fifties he learns that his mother had been terrified, as a child, during a war — a war that had ended before the man was born. The dread has been in the family for two generations. It arrived in him before he had any life of his own to attach it to."
    },
    {
     "kind": "Teaching",
     "text": "The inherited feeling is loosened, not by processing, but by naming the owner. When the person can say, quietly, 'this dread is my mother's,' the dread begins to move. Not because it is solved. Because it has finally been given back to the person it belongs to."
    },
    {
     "kind": "Teaching",
     "text": "This is one of the deepest moves of the whole course. Every sector has been running this pattern in some lives. Family. Belief. Body. Voice. The person is not only carrying their own frequencies. They are carrying frequencies that were handed to them before they could refuse."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the inherited feeling by the shape of what would happen if you tried to describe it to someone. You cannot. There is no story. There is no cause. The feeling has been there since before the story began. The feeling has an owner. The owner is not you."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to consider, once, one feeling you have carried for as long as you can remember, and to ask whether it belongs to someone else in your family. Not to solve it. Just to hand it back, in your mind, to the original owner."
    }
   ]
  },
  {
   "id": "m07",
   "label": "7 · The Feeling That Arrives as Thought",
   "items": [
    {
     "kind": "Teaching",
     "text": "The frequency does not always arrive as a feeling. Sometimes it arrives as a thought — a small, unremarkable thought, that has the shape of a fact. 'I should probably check that.' 'What if this goes wrong.' 'They seemed a bit cold.' These thoughts arrive fully formed. They arrive without the person having decided to have them. They are the frequency, wearing the clothes of reason."
    },
    {
     "kind": "Teaching",
     "text": "A person running a frequency as thought often believes they are a thinker. They experience themselves as analytical, careful, thorough. They are not thinking. They are the recipient of thoughts the frequency has generated on their behalf. The thoughts are not conclusions. They are the assumption, arriving in fragments."
    },
    {
     "kind": "Anecdote",
     "text": "A woman notices she has been going over a conversation from three days earlier. She has been rehearsing what she said, checking whether she sounded fine, imagining what the other person thought. She believes she is reflecting. She is not reflecting. The frequency is running a small loop, and she has mistaken it for thinking."
    },
    {
     "kind": "Teaching",
     "text": "Real thinking has a movement to it. It arrives at something. It changes. It lands. The frequency's thoughts do not land. They circle. They return to the same shape. They are not going anywhere because they are not trying to go anywhere. They are the assumption, repeating itself for the purpose of staying."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency-thought by the shape of the returns. The same sentence arriving again. The same worry in a slightly different form. The same rehearsal of a moment that is over. The returns are the tell. Real thinking does not return. The frequency returns."
    },
    {
     "kind": "Teaching",
     "text": "The reversal is to notice one thought that arrived today, fully formed, that the person had not decided to think. Not to argue with it. To notice the arrival. The frequency is counting on the arrival going unobserved."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one thought this week that arrived finished. Not to question the content. To see the arrival, and to see that the thought had no author the person can name."
    }
   ]
  },
  {
   "id": "m08",
   "label": "8 · The Feeling That Was Supposed to Be a Verdict",
   "items": [
    {
     "kind": "Teaching",
     "text": "There is a specific move the frequency makes that is worth naming directly. It takes a feeling and turns it into a verdict. Not a feeling about a specific thing. A feeling about the person. The dread does not say the situation is uncertain. It says the person is not safe. The shame does not say the person did something wrong. It says the person is wrong."
    },
    {
     "kind": "Teaching",
     "text": "This is the deepest and most costly move of the whole mechanism. The feeling arrives, and the frequency reads it as evidence about identity. The person, briefly, becomes what the feeling is. They are not afraid. They are a frightened person. They are not grieving. They are a grieving person. The two are not the same."
    },
    {
     "kind": "Anecdote",
     "text": "A woman feels a surge of anger at her partner. The feeling is real. And immediately, the frequency does its work: it says she is an angry person, that this anger is a fact about her character, that her mother was the same. In ten seconds she has moved from a feeling about a specific moment to a verdict about her entire life. The feeling was momentary. The verdict was installed."
    },
    {
     "kind": "Teaching",
     "text": "The verdict is often inherited. A parent who was told they were too sensitive passes it on. A culture that labelled a child difficult gives them a name they have been carrying ever since. The frequency is not producing a new verdict. It is reproducing an old one, in a new emotional form."
    },
    {
     "kind": "Teaching",
     "text": "The reversal is not to deny the feeling. It is to refuse the verdict. The feeling is real. The feeling is also momentary, and specific, and not a fact about the person. The two are separable. The frequency has been insisting they are not."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the verdict by the shape of the sentence. 'I am [emotion]' rather than 'I feel [emotion].' The two sentences feel similar. The first is a verdict. The second is a report. The frequency prefers the first."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice, once this week, a moment where a feeling became a verdict in your mind. Not to stop the verdict. Just to notice that the verdict arrived, and that the feeling was smaller than the verdict."
    }
   ]
  },
  {
   "id": "m09",
   "label": "9 · The Feeling That Is Present Without the Story",
   "items": [
    {
     "kind": "Teaching",
     "text": "One of the most surprising moments in the loosening of a frequency is the discovery that the feeling can be present without the story. The chest tightens, and no interpretation arrives. The stomach drops, and no verdict attaches itself. The feeling is simply there, briefly, and then it moves."
    },
    {
     "kind": "Teaching",
     "text": "This is not the ending of the feeling. It is the ending of the frequency's monopoly on the feeling. The feeling continues to arrive. What does not arrive is the layer three — the meaning. The meaning was always the frequency's contribution. The feeling is older than the meaning, and simpler, and can be permitted to move."
    },
    {
     "kind": "Anecdote",
     "text": "A man notices, one morning, that his chest has tightened. In the past, this would have been the beginning of a familiar loop — worry, checking, more worry. This morning, the tightening is just a tightening. It moves. By the time he has made his tea, it is gone. He had not argued with it. He had not interpreted it. It had simply arrived, and passed."
    },
    {
     "kind": "Teaching",
     "text": "The feeling without the story is often described as quieter, or emptier, or stranger than the person expected. The feeling is smaller than the previous versions. What was previously an event is now simply a sensation."
    },
    {
     "kind": "Teaching",
     "text": "This is what every sector in this course has been pointing toward. Not the absence of the feeling. The absence of the meaning-layer that the frequency attaches. The feeling is real. The story about the feeling was the frequency."
    },
    {
     "kind": "Teaching",
     "text": "You will know the frequency is loosening when the person describes a feeling without immediately attaching an interpretation to it. The description is not 'I felt anxious.' It is 'my chest tightened for a minute.' The difference is small and complete."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to let one feeling this week be felt without being named or interpreted. Not to suppress the naming. To simply let the feeling pass, this once, without the frequency's commentary."
    }
   ]
  },
  {
   "id": "m10",
   "label": "10 · The Feeling That Was Never Asked What It Was",
   "items": [
    {
     "kind": "Teaching",
     "text": "Most people, most of their lives, have not been asked what they are actually feeling. They have been asked to summarise. They have been asked whether they are okay, which is a question with two permitted answers. They have been asked to describe their emotional state in a sentence, as if the emotional state were a fact."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is often sustained by the absence of the question. If no one asks what the feeling actually is, the feeling continues to be run as the frequency has always run it. The question — asked by another person, or asked by the person themselves — is one of the small reversals."
    },
    {
     "kind": "Anecdote",
     "text": "A man is asked, by a friend, what he is actually feeling. Not what he is doing, or what he is planning, or how he is managing. What he is actually feeling. He does not have an answer. He has not been asked this question in decades. The friend waits. In the silence, a small thing arrives — not the summary he would have given, but something underneath it. He names it. It is not what he expected."
    },
    {
     "kind": "Teaching",
     "text": "The question is small and the question is significant. The frequency has been running on the assumption that the feeling is obvious, or irrelevant, or something to be managed. The question reopens the possibility that the feeling has a shape, and that the shape has never been looked at directly."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of the person's answers when asked how they are. The answers are summaries. They are delivered quickly. They are chosen from a small set. The frequency has been running the answer for decades, and the answer is not the feeling."
    },
    {
     "kind": "Teaching",
     "text": "The reversal, in this module, is quiet. Ask the question of yourself, once this week, without any of the summaries ready. What is actually being felt, right now, underneath the answer? The question is the whole practice. The frequency cannot survive the question being asked honestly."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to sit with the question for one minute this week. What am I actually feeling, right now, underneath the answer I would give? The answer is not required. The question is the whole of it."
    }
   ]
  },
  {
   "id": "m11",
   "label": "11 · The Loop, Finally Seen",
   "items": [
    {
     "kind": "Teaching",
     "text": "There comes a moment in the loosening of any frequency when the person sees the loop — the assumption, the thought, the feeling, the confirmation. It arrives whole, briefly, and the person can see that it is a loop. Not a response to the world. A circuit."
    },
    {
     "kind": "Teaching",
     "text": "This seeing is not the ending of the loop. The loop continues to run. What has changed is that it is no longer invisible. The person is inside it and outside it at the same time. The two are not the same, and the difference is the whole shift."
    },
    {
     "kind": "Anecdote",
     "text": "A woman is in a familiar conversation with her mother. Something is said. The familiar small contraction arrives in her chest. And then, for the first time, she sees the sequence — the assumption that she has done something wrong, the thought that her mother is disappointed, the feeling in her chest, the wish to apologise. She does not apologise. The loop has not gone. But she has seen it, and the seeing has interrupted the automatic completion."
    },
    {
     "kind": "Teaching",
     "text": "The seeing is not the same as the fixing. The frequency has taught the person to fix things — to argue, to reorganise, to plan. The seeing is not that. The seeing is simply seeing. It arrives on its own, in a moment of quiet, and it changes the relationship to what has always run."
    },
    {
     "kind": "Teaching",
     "text": "This is what every sector has been pointing toward — the moment the person sees the mechanism running. The mechanisms are different. The seeing is the same. This sector is where the seeing is named."
    },
    {
     "kind": "Teaching",
     "text": "You will know the loop is being seen when the person can describe it in real time. 'I am doing the thing.' 'The frequency is here.' 'I can see it.' The naming is not a technique. The naming is the seeing, expressed in words."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one moment this week where the loop was visible. Not to solve it. Just to see it, and to know that it has been seen."
    }
   ]
  },
  {
   "id": "m12",
   "label": "12 · Recalibrating",
   "items": [
    {
     "kind": "Teaching",
     "text": "The recalibration of the feeling frequency is not the achievement of a person who no longer has feelings. It is not the cultivation of stoicism, or the elimination of emotion, or the arrival at a state of permanent equanimity. It is the slow, patient practice of noticing that the feeling is not the fact — and that the loop that produces the feeling has been running quietly for a very long time."
    },
    {
     "kind": "Teaching",
     "text": "The feeling frequency does not disappear. It is the deepest of the sectors because it is the mechanism all the other sectors have been running. It will return in every room the other sectors described. What changes is that the person can see it running, and can tell the difference between the feeling and what the feeling is claiming."
    },
    {
     "kind": "Anecdote",
     "text": "Two people live the same life, in the same conditions, with the same events. One spends the whole of it responding to the world as the frequency presents it — reacting, bracing, confirming, looping. The other, quietly, over decades, learns to see the loop. The events do not change. The frequency does not stop. What changes is that the second person is not inside the loop without knowing it. The same life is being lived, but only one of them is being lived."
    },
    {
     "kind": "Teaching",
     "text": "You will know the frequency is shifting when the person can feel something without immediately believing what the feeling says. When the chest tightens and the person does not move into interpretation. When the fear arrives and is not taken as evidence. When the assumption is running but is not being obeyed."
    },
    {
     "kind": "Teaching",
     "text": "This is the sector that names the whole course. Every other sector has been a specific instance of the same mechanism. Money, Love, Health, Work, Family, Belief, Voice, Power, Body, Time, Belonging, Death, Grief, Anger, Creativity, Solitude, Desire, Trust, Status — each one a territory. Feeling is the mechanism. The territory is different. The loop is the same."
    },
    {
     "kind": "Teaching",
     "text": "You were not born with the mechanism. You were born with feelings — real ones, simple ones, brief ones. The mechanism was installed on top of them, by a household, a culture, a specific set of early experiences. The mechanism can be seen. Once it is seen, it does not run the whole of a life. It only runs as much as it is permitted."
    },
    {
     "kind": "Recalibration",
     "text": "The same feeling. The same moment. Two different relationships to what the feeling means. You have just read the final sector of this course. That space is what the whole course has been standing on. And the space between the two — the space where the feeling is not the fact — is where the person finally comes home to their own life."
    }
   ]
  }
 ]
};
