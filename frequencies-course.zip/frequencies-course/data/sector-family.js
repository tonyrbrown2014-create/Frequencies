window.FREQ_SECTOR={
 "key": "family",
 "title": "Family",
 "glyph": "❖",
 "blurb": "The frequencies you were handed before you could speak. Ancestral patterns running through your choices — and the moment you can name them, and stop passing them on.",
 "philTitle": "Family · The Fear Frequency & The Reversal",
 "philText": "The family frequency is the one you were given before you could speak. It runs underneath your choices long after you have left the house, long after the people who transmitted it have gone. This sector is not about blame — it is about seeing the inheritance clearly, and the moment you stop carrying what was never yours to keep.",
 "modules": [
  {
   "id": "m01",
   "label": "1 · The Frequency You Didn’t Choose",
   "items": [
    {
     "kind": "Teaching",
     "text": "There is one frequency in your life that was installed before you had any say in it. The family frequency. It arrived in the first years, before memory formed, before language could name it. It ran underneath every early experience — how your parents worried, how they loved, how they feared, what they believed was dangerous, what they believed was safe."
    },
    {
     "kind": "Teaching",
     "text": "You did not learn the family frequency. You absorbed it. Like a language. Like a climate. You do not remember learning it because there was never a moment of learning — there was only the quiet, constant presence of it, and the slow formation of a self inside it."
    },
    {
     "kind": "Anecdote",
     "text": "A woman is asked, in therapy, why she always arrives fifteen minutes early everywhere. She does not know. Then she remembers: her mother was always fifteen minutes early. The mother is dead now, twenty years. The woman is still arriving fifteen minutes early, still running the frequency of a woman who is no longer alive."
    },
    {
     "kind": "Teaching",
     "text": "This is what makes the family frequency so difficult to see. It does not feel like an inherited set of assumptions. It feels like reality. It feels like the shape of things. Only in moments of extraordinary honesty — or in a new country, or a new love, or a new fear — does the person notice that some of what they call 'me' is actually a small inherited room they have been living in."
    },
    {
     "kind": "Teaching",
     "text": "The family frequency is not a moral inheritance. It is not a defect. It is a transmission — from a parent, who received it from their parent, who received it from theirs. The chain is old. None of the links chose it. All of the links passed it on."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal begins with one question: what did the people who raised me believe about the world? Not what did they say. What did they believe. You do not need to answer it completely. The question alone has already begun the work."
    }
   ]
  },
  {
   "id": "m02",
   "label": "2 · What Was Never Said",
   "items": [
    {
     "kind": "Teaching",
     "text": "The loudest part of the family frequency is often what was never said. Not the instructions, not the rules, not the moral lessons — those are the surface. Beneath them is the shape of what could not be spoken. What was too painful, too dangerous, too complicated to name."
    },
    {
     "kind": "Teaching",
     "text": "Silence in a family is not the absence of a frequency. It is one of the frequency's most effective methods of transmission. What is not discussed becomes a law. What cannot be named becomes the ground everything else is built on."
    },
    {
     "kind": "Anecdote",
     "text": "A man reaches forty before he learns that his grandmother died in a hospital he was told, as a boy, was a hotel. No one lied to him. No one told him the truth. The silence had simply been sufficient. He had built a life around a shape that was not there."
    },
    {
     "kind": "Teaching",
     "text": "The silent parts of the family frequency are almost always protective. Someone, once, decided that the truth was too much for the children. The decision was often kind. Its consequence is a frequency that runs on shadows."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise your own family's silences by the places your mind slips around. The topics that feel slightly too heavy. The questions you have never quite asked your parents. The stories you have heard three versions of, each slightly different, none of them complete."
    },
    {
     "kind": "Teaching",
     "text": "The silences are not the family's failure. They are the family's symptom. A fear frequency was already running, and the silence was how it protected itself from being seen. When you notice the silence, you have already begun to see the frequency."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is not to force the silences open. It is to notice they are there. Some will open with time. Some will not. What matters is that the silence no longer runs you from beneath the floor of the house."
    }
   ]
  },
  {
   "id": "m03",
   "label": "3 · The Parent Inside",
   "items": [
    {
     "kind": "Teaching",
     "text": "By the time you are an adult, you are no longer just yourself. You are also, in a quiet and continuous way, the people who raised you. Their voices live inside your head. Their fears run beneath your days. Their standard of what is acceptable arrives before your own opinion does."
    },
    {
     "kind": "Teaching",
     "text": "This is not a metaphor. The inner parent is the family frequency in its most concentrated form. It speaks in a particular tone — usually the tone your parent used when they were worried or disapproving — and it speaks with a confidence that is difficult to argue with, because it arrived before your own voice did."
    },
    {
     "kind": "Anecdote",
     "text": "A man is successful and unhurried in every area of his life except one — money. He cannot spend on himself without a flash of discomfort. He recognises, eventually, that the discomfort is not his. It is his father's, still running, thirty years after the man died, in a body that is not the father's."
    },
    {
     "kind": "Teaching",
     "text": "The inner parent is not always negative. Many people carry an inner parent who is loving, encouraging, warm. But even the loving inner parent is a broadcast — a shape that was given, and that continues to run whether it fits the present situation or not."
    },
    {
     "kind": "Teaching",
     "text": "The difficulty is that the inner parent feels like common sense. When it speaks, it does not feel like an inheritance. It feels like your own judgement. This is why it takes so long to notice — the frequency is wearing your voice."
    },
    {
     "kind": "Teaching",
     "text": "You do not have to remove the inner parent. That is not possible, and it is not the goal. You have to be able to tell the difference between a voice that is yours and a voice that is theirs. That difference is the whole of module three."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal begins with one question, asked in the middle of a familiar hesitation: would I still feel this way if my parent had never felt it? The question does not require an answer. It requires only to be asked."
    }
   ]
  },
  {
   "id": "m04",
   "label": "4 · What You Promised Yourself",
   "items": [
    {
     "kind": "Teaching",
     "text": "Some children, watching the family frequency run, make a quiet promise to themselves. They will not be like that. They will not run the same patterns. They will not pass on the same fear. The promise is sincere, and the promise is real, and the promise rarely holds."
    },
    {
     "kind": "Teaching",
     "text": "The promise fails not because the person was weak. It fails because promising not to be something is not the same as being able to be something else. The frequency is not a habit. It is a shape of the self. You cannot leave a shape by deciding to."
    },
    {
     "kind": "Anecdote",
     "text": "A woman swears she will never shout at her children the way her mother shouted at her. She does not shout for years. Then one day, in the middle of a difficult morning, she hears her mother's voice coming out of her own mouth, in her mother's exact tone. She stops cold. The promise had never been the point. The frequency was still there, waiting."
    },
    {
     "kind": "Teaching",
     "text": "The promise to be different is often made at the age when the person is least able to keep it — childhood or adolescence, when the parent's frequency is still fully installed. The promise runs on willpower. The frequency runs on the nervous system. The nervous system wins."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the failed promise by the particular shape of the guilt that follows. It is not the guilt of having done something wrong. It is the guilt of having become the very thing you promised you would not be. That guilt is the frequency's most painful signature."
    },
    {
     "kind": "Teaching",
     "text": "The promise is not the problem. The promise is the beginning of the awareness. The problem is that the promise was made too early, in a form the person could not yet fulfil. To keep the promise, the person needs to change the frequency — not just swear at it."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is not to renew the promise with more force. It is to notice the frequency underneath, and to let the promise be a direction rather than a verdict."
    }
   ]
  },
  {
   "id": "m05",
   "label": "5 · The Favourite and the Forgotten",
   "items": [
    {
     "kind": "Teaching",
     "text": "Families assign roles. Quietly, without a meeting. One child is the hope, another the difficult one, another the one who never caused trouble. The role is not the child. The role is the frequency that was assigned to the child, and the child will often spend their life living inside it."
    },
    {
     "kind": "Teaching",
     "text": "The role is not always negative. Even being the favourite is a frequency — a set of expectations and assumptions that runs for a lifetime. The favourite often cannot fail. The forgotten often cannot ask. Both are running a broadcast that was handed to them before they could hold their own weight."
    },
    {
     "kind": "Anecdote",
     "text": "A man and his brother are in their fifties. The man is the elder, the one who was always expected to sort things out. His brother is the one who was always a bit of a worry. Their parents died years ago. The roles are the same. Both men still speak as if the roles had been announced this morning."
    },
    {
     "kind": "Teaching",
     "text": "The role is not a fact about the person. It was assigned. It was maintained. It is still being maintained. Most adults in families believe they are being themselves in their family — but the family is the one room in which the original frequency is most difficult to step out of."
    },
    {
     "kind": "Teaching",
     "text": "You can often tell the role best in the moments of family stress. Who is called first. Who is blamed. Who is assumed to be fine. The pattern is not the person. The pattern is the frequency that was assigned to that person and never revisited."
    },
    {
     "kind": "Teaching",
     "text": "The role is also what the person expects themselves to be. The person called the strong one cannot ask for help. The person called the difficult one cannot surprise the family by being easy. The role has become the shape of what they believe themselves to be."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal begins with one question, asked without an audience: what role was I assigned, and is it still mine? The question often lands harder than expected. That landing is the beginning of the shift."
    }
   ]
  },
  {
   "id": "m06",
   "label": "6 · The Family Story You Tell",
   "items": [
    {
     "kind": "Teaching",
     "text": "Every family has a story it tells about itself. The story is not the family. The story is the frequency the family has agreed to run. It has heroes, difficult chapters, an old wound, a version of how things have gone. The story is stable, and the story is edited."
    },
    {
     "kind": "Teaching",
     "text": "You inherited the story along with the frequency. You can probably recite it without thinking. It is the version of the family that has been agreed. It is also a version of the family that has been chosen — and whatever does not fit has been gently folded out."
    },
    {
     "kind": "Anecdote",
     "text": "A woman grows up hearing that her father was a difficult man and her mother a saint. As an adult she learns, from an aunt, that her mother was the difficult one and her father the gentle one, and that the family narrative had been rewritten in a specific year for a specific reason. She is not sure which version she believes. She is now aware there is a version."
    },
    {
     "kind": "Teaching",
     "text": "The family story often serves a protective function. It smooths over the parts that were too painful. It builds a version of the family that can be lived with. The person inside the frequency rarely notices that they are not seeing the family — they are seeing the story about the family."
    },
    {
     "kind": "Teaching",
     "text": "The story is also what the family transmits to the next generation. The children receive the story, and the story becomes their frequency. Every generation edits the story a little, and every generation believes it is the truth."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is not to replace the family story. It is to notice that a story is being told, and to hear the silences in it. What is not in the story is often more revealing than what is."
    }
   ]
  },
  {
   "id": "m07",
   "label": "7 · Going Back for a Weekend",
   "items": [
    {
     "kind": "Teaching",
     "text": "For many adults, going back to the family home — even for a short visit — reveals the frequency with unusual clarity. Within minutes of arriving, they are back inside a version of themselves they do not recognise. Their voice changes. Their posture changes. Their fears return in full."
    },
    {
     "kind": "Teaching",
     "text": "This is not weakness. It is the frequency, in its original habitat. The adult self that functions everywhere else is standing next to a much older self that arrived on the scene when the person was three. The older one wins, because the older one has been here longer."
    },
    {
     "kind": "Anecdote",
     "text": "A woman in her forties is confident and direct in every part of her life except one. The moment she crosses the threshold of her mother's house, she becomes, without choice, the daughter who is cautious, apologetic, and slightly too eager to please. She notices it now. She cannot stop it. But she can watch it."
    },
    {
     "kind": "Teaching",
     "text": "The visit is often the clearest diagnostic the adult has. What is the frequency that arrives in the first ten minutes? What is the person you become before you have decided to become them? That person is not a failure of willpower. That person is the original broadcast, still running."
    },
    {
     "kind": "Teaching",
     "text": "The frequency of the visit is almost never the frequency of the family itself. It is a third thing — the meeting of the family's frequency and the adult's own. Some adults run a frequency that cooperates with the family's. Others run one that resists. Both are playing out the original dynamic."
    },
    {
     "kind": "Teaching",
     "text": "Real change rarely happens during the visit itself. It happens afterwards — in the noticing. What did I become? Why did I become it? Whose voice was I using? The visit reveals the frequency. The reflection is where the shift begins."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is not to change the visit. It is to bring something home with you from the visit — one clear observation about the frequency that only appears there. That observation is worth more than any argument that could have been had at the table."
    }
   ]
  },
  {
   "id": "m08",
   "label": "8 · What You Passed On",
   "items": [
    {
     "kind": "Teaching",
     "text": "By the time a person has children of their own, they are not only running the frequency they received. They are transmitting it. The transmission is often invisible. It does not look like parenting. It looks like the person's ordinary way of being in the world, caught without permission by a small pair of eyes."
    },
    {
     "kind": "Teaching",
     "text": "What a person passes on is rarely the frequency they would have chosen. It is the frequency they actually run. The child receives not what the parent wishes to give but what the parent is broadcasting — and the broadcast is always wider than the words."
    },
    {
     "kind": "Anecdote",
     "text": "A man hears his eight-year-old daughter use a phrase that his mother used to use, in a tone his mother used to use, in a situation he had not noticed was the same. He is not surprised by the phrase. He is surprised by the tone. It is his tone now. He had not known he had one."
    },
    {
     "kind": "Teaching",
     "text": "This is the part of the family frequency that brings people to the whole course. Not the pain they inherited, but the pain they realise they are transmitting. The moment a person sees their child running a frequency that came from somewhere behind the child — that is often the moment the shift finally begins."
    },
    {
     "kind": "Teaching",
     "text": "The good news is that the transmission is not fixed. A person who becomes aware of their own frequency, in the presence of their children, begins transmitting something subtly different. Not a new frequency overnight. Just a small crack in the old one. The child picks up the crack."
    },
    {
     "kind": "Teaching",
     "text": "The reversal does not require the parent to have completed their own healing. It requires them to be honest about the process. Children receive frequencies, but they also receive the shape of a person meeting their own frequency — and that shape is often more important than the frequency itself."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal begins with one question: what am I transmitting right now? Not what am I saying. What is the broadcast my children are picking up in this moment? The question is a small act of transmission itself."
    }
   ]
  },
  {
   "id": "m09",
   "label": "9 · When the Family Changes Shape",
   "items": [
    {
     "kind": "Teaching",
     "text": "Families change shape. A death, a birth, a marriage, a divorce, a rupture, a reconciliation. The frequency that was running in a stable form suddenly has to adapt — and in the adaptation, the frequency becomes unusually visible."
    },
    {
     "kind": "Teaching",
     "text": "When a family member dies, the frequency that has run in their presence is suddenly released into the room. The remaining members often find themselves feeling things they did not expect — not just grief, but relief, or anger, or a strange lightness, or a strange weight. The frequency that person held is now falling into the rest of the family, and it is heavy."
    },
    {
     "kind": "Anecdote",
     "text": "After her mother dies, a woman begins to speak in her mother's phrases — a much stronger version than she ever did in her mother's life. She is not pretending. She is holding. The frequency has passed to her because there is no longer anyone else in the house to hold it."
    },
    {
     "kind": "Teaching",
     "text": "This is why grief is often more complicated than it looks. The person who is missed was often also the person who held a particular piece of the family frequency. When they leave, the piece lands somewhere else — usually on the person most capable of carrying it, or the person least able to refuse it."
    },
    {
     "kind": "Teaching",
     "text": "New shapes also carry new frequencies. A new baby receives the current family broadcast without filter. A new spouse enters the family's frequency and either adapts, resists, or becomes the mirror that finally shows the family what it has been running."
    },
    {
     "kind": "Teaching",
     "text": "The family frequency is not a fixed thing. It is a living arrangement between people, and it reshapes itself every time the arrangement changes. Some of the reshaping is a burden. Some of it is an opportunity — because a change in shape is often the clearest moment to leave an old frequency behind."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice which parts of the family frequency you are holding because you chose to, and which parts you are holding because there was no one else. The two are easily confused. They are not the same."
    }
   ]
  },
  {
   "id": "m10",
   "label": "10 · The Forgiveness That Isn’t Forced",
   "items": [
    {
     "kind": "Teaching",
     "text": "Many people arrive at this module believing they must forgive their family in order to move forward. They have been told this by well-meaning voices. The message is often wrong — or at least, misleading. The family frequency does not require forgiveness. It requires seeing."
    },
    {
     "kind": "Teaching",
     "text": "Forced forgiveness is its own frequency. It is a performance of peace that runs on top of the original wound. It does not heal the wound. It teaches the person to be quiet about it. Many people spend decades forgiven in this way and quietly more ill than when they started."
    },
    {
     "kind": "Anecdote",
     "text": "A man forgives his father, at his mother's urging, when he is twenty-five. His father accepts the forgiveness, and the relationship returns to what it was. Ten years later, the man is in therapy, discovering that he has never really dealt with any of it. The forgiveness had been a lid. The frequency was still underneath."
    },
    {
     "kind": "Teaching",
     "text": "Real forgiveness — when it arrives — is quiet and unasked for. It arrives not because it was required but because the frequency underneath finally stopped running so hard. It is not an act of will. It is a consequence."
    },
    {
     "kind": "Teaching",
     "text": "You do not have to forgive your family for the course to work. You do not have to reconcile, or visit, or call. What you have to do is see the frequency clearly, and stop running it as if it were your own. That is enough. That is a life's work, and it is more than most people complete."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to release the pressure to forgive. If forgiveness comes, let it come. If it does not, let that be. The frequency is what matters, not the performance of release."
    }
   ]
  },
  {
   "id": "m11",
   "label": "11 · Recognising the Inherited Voice",
   "items": [
    {
     "kind": "Teaching",
     "text": "The inherited voice is often felt before it is recognised. A hesitation that arrives without reason. A flash of shame in a moment that was going well. A sudden tightening in the chest at an ordinary request. The inherited voice has arrived, and it is wearing your own."
    },
    {
     "kind": "Teaching",
     "text": "Learn to hear its tone. Every family has a distinct sound — a particular way of worrying, a particular way of disapproving, a particular way of being silent. That sound is running inside you. It has been running since before you could name it."
    },
    {
     "kind": "Anecdote",
     "text": "A woman notices, over a year, that she gives herself a small, sharp laugh whenever she does something that might be considered self-indulgent. She has done this for as long as she can remember. Eventually she recognises the laugh: it is her grandmother's laugh, played in her grandmother's voice, saying the words her grandmother used to say about people who were too comfortable."
    },
    {
     "kind": "Teaching",
     "text": "The inherited voice is not always an enemy. Some of the voice is protective, kind, wise. The point is not to silence it. The point is to know which voice is speaking, and to be able to choose whether to follow it or not."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the inherited voice most clearly in the moments you most want to hide. The moment before a small success. The moment before a rest. The moment of being seen. Those are the moments the inherited frequency is most likely to step in and quietly take over."
    },
    {
     "kind": "Teaching",
     "text": "The voice does not need to be argued with. Argued with, it grows louder. It needs to be heard, named, and left. The naming is the whole practice."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to name the voice when it speaks: 'this is my mother's fear', 'this is my father's worry', 'this is the voice of the family I grew up in'. The naming does not fix the frequency. It ends its monopoly on your attention."
    }
   ]
  },
  {
   "id": "m12",
   "label": "12 · Recalibrating",
   "items": [
    {
     "kind": "Teaching",
     "text": "The recalibration of the family frequency is not a rupture. It is not a break with your family, or a rejection of where you came from, or a decision to become someone else. It is the slow, patient work of noticing the inheritance, and letting it stop running your life as if it were your own."
    },
    {
     "kind": "Teaching",
     "text": "The family frequency does not leave on request. It was installed before you could form a self. It will be with you in some form for the rest of your life. But it can stop being the frequency in which you live. It can become one voice among many, rather than the voice that runs the show."
    },
    {
     "kind": "Anecdote",
     "text": "Two siblings grow up in the same house, receive the same frequency, and live very different lives. One carries it into everything, slowly becoming a slightly quieter, slightly more careful version of the parent. The other notices, in their thirties, that the frequency is running, and begins, slowly and awkwardly, the work of letting it be one voice rather than the whole room. Thirty years later the two are not especially different in circumstance. They are entirely different in how they are living."
    },
    {
     "kind": "Teaching",
     "text": "You will know the frequency is shifting when a family gathering no longer pulls you back into the original version of yourself as completely as it used to. Not because you have left the family. Because you have stopped living inside the frequency alone."
    },
    {
     "kind": "Teaching",
     "text": "The work does not complete in a lifetime. The chain of transmission goes back centuries. Every generation inherits, and every generation has the chance to soften it a little. You are one link. The work you do now does not only change your own life — it changes what arrives at the next link."
    },
    {
     "kind": "Teaching",
     "text": "You were not born carrying the family frequency. It was given. You can be grateful for what it gave you and honest about what it cost you. Both can be true. Both usually are."
    },
    {
     "kind": "Recalibration",
     "text": "The same family. The same history. Two different broadcasts. You have just read an entire sector about the space between them. That space is the whole of this course — and, in family, it is the space where the inheritance finally becomes yours to shape rather than the shape you were born into."
    }
   ]
  }
 ]
};
