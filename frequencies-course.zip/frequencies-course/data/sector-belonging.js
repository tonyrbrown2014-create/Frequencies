window.FREQ_SECTOR={
 "key": "belonging",
 "title": "Belonging",
 "glyph": "◍",
 "blurb": "Exclusion, otherness, the fear of being outside. How the frequency of \"I don't quite fit\" can push away what it most wants — and what opens when it doesn't try so hard.",
 "philTitle": "Belonging · The Fear Frequency & The Reversal",
 "philText": "Belonging is not the problem. The frequency that watches for the moment of exclusion is the problem. This sector is not about being popular or fitting in — it is about the quiet, continuous sense of being slightly outside: the extra beat of hesitation before entering a room, the interpreting of neutral looks as signals, the belief that the people around you are inside something you are not quite a part of. It is about the moment the person stops auditioning for the room and simply joins it.",
 "modules": [
  {
   "id": "m01",
   "label": "1 · The Slightly Outside Feeling",
   "items": [
    {
     "kind": "Teaching",
     "text": "Some people move through rooms as though they are inside them. Others move through rooms as though they are standing just outside the doorway, watching. Both are physically inside. The difference is not the location. The difference is the frequency."
    },
    {
     "kind": "Teaching",
     "text": "The slightly outside feeling is not shyness. It is not social anxiety in the clinical sense. It is a quieter, more continuous orientation — a settled sense that the belonging the person sees in others is available to them only partially, conditionally, on probation. The frequency is not loud. It does not need to be. It has been running since childhood and it feels like the truth."
    },
    {
     "kind": "Anecdote",
     "text": "A woman is at a dinner party, present, laughing, listening. She is having a good time. And yet, she notices, at the end of the evening, that she has not once let her guard down. She has been performing the belonging all evening rather than simply being in it. She has been doing this for thirty years and has only just realised there might be a difference."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is often invisible to the person running it, because it does not have a specific object. It is not fear of one person, or of one group. It is a general orientation — a slight tilt of the inner life towards the outside. The person may be loved, and know they are loved, and still feel slightly outside the love."
    },
    {
     "kind": "Teaching",
     "text": "The slightly outside feeling is one of the most universal frequencies in modern life. Many people run it. Fewer know they are running it, because the frequency tends to describe itself as personality: 'I am a bit of an outsider', 'I have always been slightly different', 'I prefer my own company'. Some of that is true. Some of it is the frequency, wearing the clothes of identity."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency in the small physical sensation of hesitating before entering a room. Not always — but often. The half-second pause, the quick scan of faces, the micro-adjustment of posture before going in. That half-second is the frequency, arriving before the person has decided anything."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal begins with one noticing: in a familiar room this week, did you let yourself be inside it, or were you standing slightly outside it? No correction. Just noticing where you actually were."
    }
   ]
  },
  {
   "id": "m02",
   "label": "2 · Where the Outside Was First",
   "items": [
    {
     "kind": "Teaching",
     "text": "The belonging frequency usually has a first scene. A moment, or a season, when the child learned that they were on the outside of something. The scene is often small — not dramatic cruelty, not obvious exclusion, but a small natural event that the child registered as a permanent fact about themselves."
    },
    {
     "kind": "Teaching",
     "text": "A child who was not invited to a party that everyone else was invited to. A child whose accent did not match the room. A child whose family was slightly different from the families of the other children — different food, different money, different language, different religion, different structure. The difference did not have to be said. The child read it in the air."
    },
    {
     "kind": "Anecdote",
     "text": "A man remembers being six and being told, gently, by his mother, that he should not talk about the food they ate at home when he was at school. He did not understand at the time. He understands now. His mother was protecting him from a difference that she knew — correctly — would mark him. He is fifty-five. He still eats quickly at other people's tables."
    },
    {
     "kind": "Teaching",
     "text": "Some belonging frequencies are installed by the world's actual behaviour. A child of colour in a white school. A child with a visible disability. A child who speaks a different language at home. A child from a class where the school was not built for them. The frequency is not invented. It is the correct reading of a world that was, in fact, more welcoming to others."
    },
    {
     "kind": "Teaching",
     "text": "This is important to name, because the frequency is often blamed on the person. 'You are too sensitive', 'you always felt different', 'you never quite fit'. In many cases the person was not creating the difference. The person was accurately perceiving a difference that was already there. The frequency was not a distortion. It was a reasonable response to an unreasonable arrangement."
    },
    {
     "kind": "Teaching",
     "text": "The other frequencies installed by love — Body, Family, Voice — often contain some comfort in their origin. The belonging frequency rarely does. It is one of the few frequencies in this course that was often installed by the person's genuine encounter with exclusion, not by the affectionate clumsiness of a parent."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the origin by the shape of the discomfort. If the discomfort is about being different, the origin was probably a difference in the family or in the child. If the discomfort is about being unknown, the origin was probably an early absence of recognition. Both run the same frequency. They are not the same wound."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal, in this module, is not to forgive the world. It is to see that the frequency began as an accurate reading, and to note that the world the person is now in may not be the same world the frequency was calibrated for."
    }
   ]
  },
  {
   "id": "m03",
   "label": "3 · The Many Small Proofs",
   "items": [
    {
     "kind": "Teaching",
     "text": "The belonging frequency gathers evidence. It is not content with the general sense of being outside — it wants proof. And the proofs are always small: a look, a pause, a change in the room's tone, a joke that landed and one that did not, a moment of being spoken to later than others, a door left slightly open when it might have been closed."
    },
    {
     "kind": "Teaching",
     "text": "These small proofs are everywhere, because the frequency has trained the person's attention to find them. Any group of humans contains hundreds of small signals every minute. The frequency selects, from this flood, the signals that confirm the outside feeling, and misses the hundreds of small signals that contradict it."
    },
    {
     "kind": "Anecdote",
     "text": "A woman reads a group chat message from a colleague that arrives without a smiley face at the end. She spends the morning convinced the relationship has shifted. In fact, the colleague was typing quickly in a taxi. Nothing had shifted. The frequency had found its proof for the day."
    },
    {
     "kind": "Teaching",
     "text": "The proofs are not lies. Each one is technically possible. But the frequency treats each one as evidence for a case it is already running, rather than as one data point among thousands. A person is not being excluded because they were not asked first. A person is not being excluded because a message arrived without punctuation. The frequency cannot tell the difference between a small sign and a verdict."
    },
    {
     "kind": "Teaching",
     "text": "The collection of proofs is exhausting. It is why people running the frequency are often tired after social events, even pleasant ones. They have been running an investigation the whole evening, and the investigation has found a great deal to write down."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency in the moments you find yourself rereading a message. Not reading it again — rereading it. Looking for what you might have missed. The frequency is in the rereading. The rereading rarely finds anything new."
    },
    {
     "kind": "Teaching",
     "text": "You will also recognise the frequency in the relief when the proof does not arrive. A message is answered warmly. A look is warm. The relief is disproportionate. It is the frequency standing down for a moment, before quietly reassuming its post."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one rereading this week. Not to stop it. Just to see that you are doing it, and that the frequency has been at work in your attention."
    }
   ]
  },
  {
   "id": "m04",
   "label": "4 · Joining Late, Leaving Early",
   "items": [
    {
     "kind": "Teaching",
     "text": "The belonging frequency shapes the person's timing. They arrive late, or they leave early, or both. Not by plan — by reflex. The arrival is delayed because the room is a small test. The leaving is early because the person has already run out of the small energy the test requires."
    },
    {
     "kind": "Teaching",
     "text": "Late arrivals and early exits are often mistaken for social preference. 'I am not a party person', 'I prefer a quiet evening', 'I like to leave before it gets too much'. Some of that may be true. Some of it is the frequency, editing the person's calendar to reduce the exposure."
    },
    {
     "kind": "Anecdote",
     "text": "A man notices that he has never once been the first person to arrive at anything — a party, a meeting, a dinner — except when he is hosting. He has always arrived after the room was warm. He has always left while the room was still warm. He thought, all his life, that this was simply his way. It is his way. It is also the frequency's way of managing the exposure."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is also visible in the room where the person is genuinely comfortable — with one friend, with their immediate family, with a partner. In those rooms, the person often arrives on time and stays late. The pattern shifts because the frequency is not running."
    },
    {
     "kind": "Teaching",
     "text": "This is one of the more actionable parts of the frequency. The person cannot change the sense of being outside by decision. But they can, slowly, adjust the timing. Arriving early once. Staying later once. Not as a strategy. As an experiment. The body learns from the experiment."
    },
    {
     "kind": "Teaching",
     "text": "Many people running the frequency discover that the room they were afraid of is warmer than they assumed. Arriving early, they find one person alone and easy to talk to. Staying late, they find a smaller, softer version of the party that they had never seen before."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is not to become the life of the party. It is to arrive early once, this month, and see what it feels like to be in a room before it has become a room."
    }
   ]
  },
  {
   "id": "m05",
   "label": "5 · The Performance of Belonging",
   "items": [
    {
     "kind": "Teaching",
     "text": "People running the belonging frequency often become highly skilled at performing the belonging they do not feel. They learn the language, the jokes, the rhythms of the group. They can hold a conversation. They can be liked. They may even be popular. And underneath the performance, the frequency is still running."
    },
    {
     "kind": "Teaching",
     "text": "The performance is not fake. The person genuinely enjoys the conversation. They genuinely like the people. But there is a small, continuous layer of management running in parallel — checking whether the performance is landing, adjusting the tone, following the room's temperature. The person is both in the room and outside it, at once."
    },
    {
     "kind": "Anecdote",
     "text": "A woman is described, by her friends, as the most socially skilled person they know. She is warm, funny, quick. She is also, in her own private description, exhausted. She has spent her whole adult life performing the belonging. Her friends do not know. Why would they? The performance has been good for forty years."
    },
    {
     "kind": "Teaching",
     "text": "The performance of belonging is one of the great costs of the frequency. The person is doubly tired at the end of a social day — once for the actual socialising, and once for the management. And the management is invisible to everyone in the room."
    },
    {
     "kind": "Teaching",
     "text": "The performance is often strongest with the people the person is closest to. Not because those people are harder, but because the stakes of the frequency feel higher there. The person can relax in front of strangers, sometimes, because strangers do not yet have a verdict to give. The people the person loves can feel, paradoxically, like the greatest audition."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the performance in the moment after a good conversation, when the person is alone in the car or the kitchen and the frequency quietly resumes. If the conversation was warm and the drive home is cold, the frequency was performing in the conversation and has now returned to the person."
    },
    {
     "kind": "Teaching",
     "text": "The performance does not have to be dismantled by decision. It dismantles itself, slowly, as the frequency is loosened. As the person begins to trust that they are actually inside the room, the small layer of management becomes unnecessary, and the person can be just one thing instead of two."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is not to stop performing. It is to notice, once, that you are performing. The noticing is the beginning of the performance no longer being entirely automatic."
    }
   ]
  },
  {
   "id": "m06",
   "label": "6 · The Room You Are Actually In",
   "items": [
    {
     "kind": "Teaching",
     "text": "The belonging frequency is often running in rooms where the person is, in fact, entirely welcome. The frequency is not an accurate reading of the current room — it is a broadcast from an older room, being played in a new one. The person believes they are reading the present. They are reading a memory."
    },
    {
     "kind": "Teaching",
     "text": "This is the frequency's central trick. It has been running since childhood, and it has not updated. The people the person is now with are not the people from the original scene. The world has changed, sometimes completely. The frequency has not."
    },
    {
     "kind": "Anecdote",
     "text": "A man moves to a new country in his forties. He expects, before he arrives, that he will feel the outsider feeling more strongly there — a foreigner in a foreign place. Instead, he is surprised to find that the belonging frequency runs less. He is obviously outside in the new country, and the obviousness makes the frequency unnecessary. He is not performing belonging because no one expects him to have it. He has the easiest social year of his life."
    },
    {
     "kind": "Teaching",
     "text": "This is one of the frequency's most revealing tells. When the person is genuinely outside — clearly, explicitly, without ambiguity — the frequency often quiets. The anxiety of belonging comes from the ambiguity. When there is no ambiguity, the frequency has nothing to check."
    },
    {
     "kind": "Teaching",
     "text": "The room the person is actually in is often warmer than the frequency reports. The frequency has been calibrated in a colder room, years ago, and is still running that calibration. The people around the person, most of the time, are already on their side. The frequency does not believe it."
    },
    {
     "kind": "Teaching",
     "text": "You can test the frequency by asking: what would the people in this room say, honestly, if I asked them whether I belong here? Most of the time, the answer would surprise the frequency. The person does not ask, because the frequency is certain the answer is bad."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal begins with an experiment. Choose one person in your life who you trust, and ask them, in your own way, whether they consider you inside. Not the full question — just a lighter version. Notice the answer."
    }
   ]
  },
  {
   "id": "m07",
   "label": "7 · When You Are the Only One",
   "items": [
    {
     "kind": "Teaching",
     "text": "Some people are the only one in many rooms. The only one from their country. The only one with their accent. The only one of their religion, their race, their class, their age, their body. The frequency of belonging arrives in these lives with a weight that is different — not invented, not imagined, but literally accurate."
    },
    {
     "kind": "Teaching",
     "text": "For these people, the frequency is often running for a real reason, and it is important to say this clearly. The course is not telling anyone that their sense of being outside is irrational. In some lives, the sense is entirely rational. The person is genuinely the only one."
    },
    {
     "kind": "Anecdote",
     "text": "A woman joins a company where she is the only woman on a team of nine, the only person of colour in the building, and the youngest by fifteen years. She runs the belonging frequency every day. It is not a distortion. It is an accurate reading. Over time, three of those facts change — and the frequency, slowly, begins to update."
    },
    {
     "kind": "Teaching",
     "text": "The frequency in these lives often has two layers. The first layer is the historical frequency that arrived in childhood. The second layer is a current, live, accurate response to a world that is still reading the person as outside. The two are not the same. Both are real."
    },
    {
     "kind": "Teaching",
     "text": "The work in these lives is not to pretend that the frequency is a distortion. It is to hold two truths at once: that the world is often genuinely unwelcoming, and that the person's own belonging is not contingent on the world's welcome. The frequency often collapses these two. The person's sense of belonging has been outsourced to the room's temperature. The room has a frequency, and it is not the person's frequency, and the person's own belonging is theirs to occupy regardless."
    },
    {
     "kind": "Teaching",
     "text": "This is a harder position than it sounds. It is not toxic positivity. It is not pretending that being the only one is easy. It is the discipline of no longer letting the room's frequency be the sole measure of one's own."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise this progress by the shape of the tiredness. When the person is still tired at the end of days spent as the only one — but the tiredness is only the actual tiredness, and no longer the additional weight of the frequency believing the room's assessment — the shift has begun."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal, in this module, is not to feel that you belong. It is to notice that you belong to yourself, regardless of the room's verdict. That sentence is the whole work."
    }
   ]
  },
  {
   "id": "m08",
   "label": "8 · The Belonging You Already Have",
   "items": [
    {
     "kind": "Teaching",
     "text": "People running the belonging frequency usually have more belonging than they can feel. They have relationships, family members, friends, colleagues — people whose lives would change if the person disappeared. The frequency does not deny these relationships. It simply does not count them."
    },
    {
     "kind": "Teaching",
     "text": "The frequency counts the belonging that is uncertain, and discounts the belonging that is settled. It remembers the colleague who was slightly cool, and forgets the colleague who has been warm for years. It remembers the group that never quite included the person, and forgets the group that did."
    },
    {
     "kind": "Anecdote",
     "text": "A woman, at the end of her life, is surrounded by a small group of people who love her. She has spent her life feeling like an outsider. Looking around the room, she begins to see, for the first time, the actual belonging she has had all along. She is in her eighties. The frequency has kept this information from her for seventy years."
    },
    {
     "kind": "Teaching",
     "text": "The belonging that already exists does not have to be created. It does not have to be earned. It is already there, often in quieter forms than the frequency was looking for. The person's task is not to build belonging. It is to see the belonging that is already present and stop treating it as insufficient."
    },
    {
     "kind": "Teaching",
     "text": "The frequency also discounts the person's belonging to themselves. The person's own company, their own habits, their own body, their own history — all of these are forms of belonging that the frequency has been treating as nothing. The person has been looking for the room to include them, and has not been including themselves."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of the person's own description of their life. If the description is dominated by the rooms they were not in, and empty of the rooms they were, the frequency is doing the counting. The belonging is there. The bookkeeping is missing it."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to count, once, without the frequency's arithmetic, the people who would actually notice if you disappeared. Not the ones from uncertain groups. The actual ones. The list is usually longer than the frequency believes."
    }
   ]
  },
  {
   "id": "m09",
   "label": "9 · The Room That Was Never a Room",
   "items": [
    {
     "kind": "Teaching",
     "text": "The belonging frequency chases rooms. It collects them, tries them, remembers the ones it did not quite get into, and returns to new ones with the same hope. It behaves as though belonging is a room — a specific group, a specific place, a specific set of people — that has not yet been found."
    },
    {
     "kind": "Teaching",
     "text": "But belonging is not a room. Belonging is a state. And it is a state that can be entered, in any room, by anyone who has stopped waiting for the room to admit them. The person who belongs is not the person in the right group. The person who belongs is the person who has decided they are already inside."
    },
    {
     "kind": "Anecdote",
     "text": "A man spends his twenties trying to get into various groups. Bands, sports teams, political circles, creative communities. Each time, the frequency runs: he is slightly outside. In his thirties, he stops chasing. He joins fewer things. In the few he joins, he begins, almost experimentally, to behave as though he is already inside. And then, without any membership being granted, he is."
    },
    {
     "kind": "Teaching",
     "text": "The rooms the frequency chases are not actually the source of belonging. They are a testing ground for the frequency's belief that the person is outside. Even if the room fully accepted the person, the frequency would continue in the next room. It has been looking for something the rooms cannot provide."
    },
    {
     "kind": "Teaching",
     "text": "The person who has stopped chasing rooms is not antisocial. They still enjoy company. They still join groups. They still have friendships and communities. The difference is that they are not auditioning. They have placed themselves inside, and the room is welcome to notice or not."
    },
    {
     "kind": "Teaching",
     "text": "This is one of the frequency's deepest reversals, and it is quiet. Nothing external changes. The person is still in the same rooms. But the person is no longer standing slightly outside the room in their own mind, because they have taken the small step over the threshold themselves."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to enter one room this week as someone who is already inside it. Not as a test. Not as a strategy. Just as a fact about where you have decided to stand."
    }
   ]
  },
  {
   "id": "m10",
   "label": "10 · The Frequency of the Room",
   "items": [
    {
     "kind": "Teaching",
     "text": "Every room has a frequency of its own. Every group, family, workplace, community has a way of being, a way of including, a way of excluding, a way of reading who is inside and who is not. The belonging frequency of the individual is often responding to the frequency of the room."
    },
    {
     "kind": "Teaching",
     "text": "Some rooms are genuinely hard to be in. Rooms where the belonging is earned rather than offered. Rooms where the group has a fixed story about itself and new people are welcomed only if they fit the story. Rooms where the temperature is slightly cold and no one notices. These rooms are not the person's imagination. They exist."
    },
    {
     "kind": "Anecdote",
     "text": "A woman changes jobs and finds, in the new workplace, that the belonging frequency has almost disappeared. The work is similar. The people are similar. The building is similar. But the room is warmer, and the frequency that was running for years at the old place has quietly stopped. She had assumed, for a decade, that the outside feeling was hers. Some of it was the room."
    },
    {
     "kind": "Teaching",
     "text": "This is one of the more important and more difficult recognitions in this sector. The frequency of the person and the frequency of the room interact. Sometimes the person's belonging frequency is running because the room is cold. Sometimes the room is warm and the person's frequency cannot feel it. Often it is some combination of both."
    },
    {
     "kind": "Teaching",
     "text": "The work is not to assume the frequency is always the person's fault, or always the room's fault. It is to see both. When the room is genuinely cold, some of the frequency is accurate. When the room is warm, the frequency has stopped being accurate, and is running on memory."
    },
    {
     "kind": "Teaching",
     "text": "The same person can belong easily in one community and feel completely outside in another. The frequency is not the person's alone. The frequency is a conversation between the person and the room, and the conversation can be changed from either side."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise this most clearly by noticing the rooms in which the frequency does not run. Those rooms tell you more about the frequency than the ones where it does."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice the difference between rooms. Not to find the perfect room. Just to see that the frequency is not universal — it is specific, and the specificity is information."
    }
   ]
  },
  {
   "id": "m11",
   "label": "11 · Recognising the Outside",
   "items": [
    {
     "kind": "Teaching",
     "text": "The belonging frequency has a signature. A small scan of faces on entering a room. A subtle check of whether the person is being included in a conversation or watching it. A particular quality of relief when a message is answered warmly. A particular quality of deflation when it is not."
    },
    {
     "kind": "Teaching",
     "text": "Learn the signature. Not to fight it. Just to see it, in the moment it arrives. The frequency cannot run a whole life once it is visible. Once visible, it becomes one voice among several, no longer the automatic reading of every room."
    },
    {
     "kind": "Anecdote",
     "text": "A woman begins to notice that she counts the number of people who greet her when she arrives at work. Not deliberately — she becomes aware, one morning, that she has been doing this all along. She has been running a small, private census, every morning, for years, of the belonging she is receiving."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is loudest in the moments of transition: entering a room, joining a conversation, being introduced to someone new, receiving a message, waiting for a reply. These are the moments when the person's belonging is being tested — or, more accurately, when the frequency believes it is being tested. Most of these moments are not tests. They are just moments."
    },
    {
     "kind": "Teaching",
     "text": "You will also recognise the frequency in the moments after being included. There is often a small disbelief — a quiet sense that the inclusion was a fluke, that the group will shortly correct itself. This is the frequency's second act, arriving after the good moment to undo it."
    },
    {
     "kind": "Teaching",
     "text": "You will know the frequency is loosening when the census stops. When a greeting is not counted. When a reply that is late is simply a reply that is late. When the room's temperature is allowed to be what it is, without the frequency taking it as information about the person."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one census this week. Not to stop it. Just to see that you were counting."
    }
   ]
  },
  {
   "id": "m12",
   "label": "12 · Recalibrating",
   "items": [
    {
     "kind": "Teaching",
     "text": "The recalibration of the belonging frequency is not the achievement of universal popularity. It is not the elimination of the wish to be included, or the ending of the perfectly human wish to be wanted. It is the slow, patient practice of standing inside the room in one's own mind — regardless of what the room is actually doing."
    },
    {
     "kind": "Teaching",
     "text": "The frequency does not disappear. It has been running since childhood. It will return in new rooms, new groups, new countries. It will return in the presence of people whose warmth is uncertain, and in the moments when the person is the only one. What changes is that the person can see the frequency running, and can choose where to stand inside themselves."
    },
    {
     "kind": "Anecdote",
     "text": "Two people reach their forties with the same sense of being slightly outside, and with the same set of rooms available to them. One spends the next twenty years continuing to look for the room that will finally admit them. The other begins, slowly, to stand inside the rooms she is already in. Twenty years later, the first has tried every room and still feels outside. The second has one small community, three close friends, and a settled sense of being inside her own life. Neither has anything the other does not. One has stopped auditioning."
    },
    {
     "kind": "Teaching",
     "text": "You will know the frequency is shifting when the room no longer needs to confirm your belonging. When the greeting, or the lack of a greeting, is just a greeting. When you can be the only one in the room and still be at home in it. When being outside a particular group stops being evidence that you are outside in general."
    },
    {
     "kind": "Teaching",
     "text": "The belonging frequency is one of the deepest of all the sectors in this course, because it is the frequency most likely to be confused with an accurate reading of the world. In some lives, the reading is accurate. In many lives, it is not — the world is warmer than the frequency believes, and the person has not been told."
    },
    {
     "kind": "Teaching",
     "text": "You were not born outside. You were placed outside, by a world that had its own arrangements, or by a childhood that gave you the wrong coordinates. The placing can be undone. Not by finding the right room — by taking the small, quiet step back over the threshold, into the room you are actually already standing in."
    },
    {
     "kind": "Recalibration",
     "text": "The same room. The same people. Two different positions inside the mind. You have just read an entire sector about the space between them. That space is the whole of this course — and, in belonging, it is the space where the person finally joins the room they were always already in."
    }
   ]
  }
 ]
};
