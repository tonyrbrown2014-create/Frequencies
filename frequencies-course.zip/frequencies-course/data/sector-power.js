window.FREQ_SECTOR={
 "key": "power",
 "title": "Power",
 "glyph": "◆",
 "blurb": "Being seen, taking up space, the fear of one's own strength. The pattern that shrinks — and what becomes possible when it stops shrinking.",
 "philTitle": "Power · The Fear Frequency & The Reversal",
 "philText": "Power is not dominance. Power is presence — the natural size of a person when nothing is being hidden. This sector is not about ambition or control — it is about the frequency that arrives when you are about to take up your actual space, and the quieter frequency that keeps shrinking you to a size that feels safe. It is about the moment you stop making yourself smaller than you are.",
 "modules": [
  {
   "id": "m01",
   "label": "1 · The Shrinking",
   "items": [
    {
     "kind": "Teaching",
     "text": "There is a natural size that a person occupies when nothing is being hidden. Presence, not dominance. Space taken as though it belonged to them, which it does. Some people live at this size without thinking. Many do not. Many have learned, quietly, to live at something smaller."
    },
    {
     "kind": "Teaching",
     "text": "The shrinking is not a personality trait. It is a frequency. It shows up as a settled set of reflexes: the leaning-back in a chair, the apology in a voice that has not done anything wrong, the instinct to take up less of the pavement as someone walks toward you, the tendency to move your own possessions slightly aside to make room for someone else's."
    },
    {
     "kind": "Anecdote",
     "text": "A woman notices, at a dinner party, that she has been sitting with her arms tucked in and her plate pulled close to her, while the woman beside her sits with her elbows out and her body loose. Nothing is wrong with either posture. But the woman realises, in that moment, that she has been sitting like this her whole adult life — and no one asked her to."
    },
    {
     "kind": "Teaching",
     "text": "The shrinking is often invisible to the person doing it because it is small. It is not a dramatic bow. It is a thousand adjustments across a day, each of which on its own would be nothing. Together, they are the frequency. Together, they are a life."
    },
    {
     "kind": "Teaching",
     "text": "The shrinking is not humility. Real humility leaves a person's natural size intact — it only removes the illusion of being larger than they are. The shrinking does the opposite. It reduces a person below their actual size, and calls the reduction good manners."
    },
    {
     "kind": "Teaching",
     "text": "People running the frequency often believe they are simply considerate. The consideration is real. The reflex behind it is not consideration. It is the avoidance of a consequence the person cannot quite name but is certain would arrive if they stopped shrinking."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal begins with a small observation: notice one moment today when you took up less space than you actually needed. Not to correct it. Not to expand. Just to see it. The noticing is the whole of the beginning."
    }
   ]
  },
  {
   "id": "m02",
   "label": "2 · What Was Taken the First Time",
   "items": [
    {
     "kind": "Teaching",
     "text": "Behind the power frequency there is usually a first time. A moment — sometimes a season, sometimes an afternoon — when the person took up their natural space and was punished for it. Not necessarily physically. Often something subtler and more effective: a withdrawal of warmth, a look, an offhand correction, a laugh at the wrong moment."
    },
    {
     "kind": "Teaching",
     "text": "The child, in that moment, learned something the adult often cannot name: that their natural size is not welcome here. The lesson was not said aloud. It did not need to be. The nervous system registered it, and the frequency was installed."
    },
    {
     "kind": "Anecdote",
     "text": "A man remembers, at seven, being excited about a drawing and running to show it to his father. His father was on the phone. His father gave him a look — not angry, just impatient. The man, now fifty-six, cannot remember the drawing. He remembers the look. He has been careful about enthusiasm ever since."
    },
    {
     "kind": "Teaching",
     "text": "The first time is often not a punishment. It is an accident. A parent who was tired, distracted, or themselves running their own shrinking frequency. The child does not know this. The child only knows that enthusiasm was met with something cold, and the child draws the obvious conclusion: enthusiasm is not safe."
    },
    {
     "kind": "Teaching",
     "text": "This is why the power frequency is often deeply tied to enthusiasm and joy. Not just to being heard or seen — to being *glad* in a way that is visible. Many adults have learned to hide their pleasure. The hiding is the shrinking, in its warmest and most costly form."
    },
    {
     "kind": "Teaching",
     "text": "The first time does not need to be found. Many people never find it, and the frequency can still soften. But knowing that there *was* a first time — that the shrinking did not come from nowhere — is often the beginning of the shift."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is not to go back and fix the moment. It is to stop treating the shrinking as a personality. It is not who you are. It is what you learned. Those are different."
    }
   ]
  },
  {
   "id": "m03",
   "label": "3 · Taking Up Less Than Your Share",
   "items": [
    {
     "kind": "Teaching",
     "text": "The power frequency runs through the small economy of a life. Space on a bench. Time in a conversation. Attention at a table. A voice in a meeting. Someone running the shrinking frequency consistently takes less than their share of all of these — and often does not notice they are doing it."
    },
    {
     "kind": "Teaching",
     "text": "This is one of the clearest signatures of the frequency. Not the big refusals, but the small ones. The chair that is a little further back. The sentence that is a little shorter. The wish that is stated a little more quietly. The turn that is always given away."
    },
    {
     "kind": "Anecdote",
     "text": "A man and his wife go for a walk. He notices, without having planned to, that he has been walking on the outside edge the whole way — the side with the traffic. He has done this for twenty years. It started with good intention, and it has become a small, constant concession. His wife has never asked him to. He has never offered. He simply does it. The frequency does it through him."
    },
    {
     "kind": "Teaching",
     "text": "The economy of a life is real. Attention, time, space, and voice are finite resources in any given hour. A person who consistently takes less than their share is not being generous. They are running a frequency that says they are not entitled to the share."
    },
    {
     "kind": "Teaching",
     "text": "The shrinking is not always visible from the outside. Many people running the frequency are perceived as kind, thoughtful, easy to be with. The visibility is not the point. The cost is felt inside. The person's own wish for a slightly fuller life has been quietly and consistently refused by a reflex they did not choose."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency most clearly in the moments you noticed a desire and did not speak it. Not because it was unreasonable — because the shrinking pre-empted it. The desire never made it into the room. It was deleted before it could be considered."
    },
    {
     "kind": "Teaching",
     "text": "The economy does not need to be corrected all at once. But it does need to be seen. A person running the frequency for decades has usually stopped noticing that they are taking less. The first work is simply to see the accounting."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one small concession today — the chair pulled in, the last piece of bread left on the plate, the wish not spoken. The noticing is the whole of the beginning. The choosing comes later."
    }
   ]
  },
  {
   "id": "m04",
   "label": "4 · The Room That Cannot Hold You",
   "items": [
    {
     "kind": "Teaching",
     "text": "There are rooms in every life where the person's natural size is welcome, and rooms where it is not. This is not a mystery. Some rooms were built for the full size of everyone in them. Others were built for a specific smallness, and any larger presence in them is quietly discouraged."
    },
    {
     "kind": "Teaching",
     "text": "The power frequency often keeps a person in the wrong rooms. Not out of weakness. Out of loyalty, or inertia, or because the smaller frequency still feels familiar. The person's natural size is unwelcome in the room, and rather than leave, they shrink to fit."
    },
    {
     "kind": "Anecdote",
     "text": "A woman realises, in her late forties, that she has spent twenty years in a professional context where she has always been, quietly, the smallest presence in the room. Nothing happened. No one attacked her. She simply joined a group whose frequency was set slightly lower than hers, and she adjusted to it without noticing."
    },
    {
     "kind": "Teaching",
     "text": "The shrinking is often not forced by the room. It is chosen for the room. The person does it to stay. Leaving would have cost something real — a friendship, a sense of belonging, a story about who they are. Staying and shrinking cost something too. It just cost less visibly."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is also reinforced by the room. A person who shrinks receives warmth, agreement, acceptance. A person who takes up their natural size in the same room receives something cooler. The room does not have to punish them. It only has to be slightly less warm. The nervous system notices."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency in the rooms where you feel, without being able to explain why, unusually tired. Not because the room is demanding. Because the shrinking is exhausting, and you have been doing it the whole time you were in there."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal does not require you to leave the room. It requires you to notice whether your size in that room is chosen, or automatic. The noticing begins to loosen the choice."
    }
   ]
  },
  {
   "id": "m05",
   "label": "5 · The Anger That Arrives Late",
   "items": [
    {
     "kind": "Teaching",
     "text": "People running the power frequency often have a distinctive relationship with anger. Not anger they express — anger that arrives late. The moment has passed, the person is home, the day is done, and only then does the anger arrive. Full, clear, unmistakable, and useless. The moment for it is gone."
    },
    {
     "kind": "Teaching",
     "text": "The late anger is not a mystery. It is the frequency, releasing its hold. During the original moment, the shrinking kept the anger suppressed — the size it would have taken to feel it was not permitted. Later, in safety, the body releases what was held."
    },
    {
     "kind": "Anecdote",
     "text": "A woman leaves a difficult meeting with nothing to say. She is quiet on the train home. That evening, in the kitchen, she becomes suddenly and completely clear about what was wrong with what was said, and what she should have replied. She writes it all down. The next morning she reads it and puts it away. The anger was real. The delay was the frequency."
    },
    {
     "kind": "Teaching",
     "text": "The late anger is often mistaken for rumination. It is not rumination. It is the frequency's own timetable. The anger would have arrived on time if the person had been permitted the size to have it on time. The frequency's rule — do not take up that much space — delayed it until later."
    },
    {
     "kind": "Teaching",
     "text": "Some people running the frequency eventually stop noticing the late anger. It has become so ordinary that they no longer connect it to the earlier moment. The anger arrives, is acknowledged as frustration, and passes. The link to the moment that produced it has been lost."
    },
    {
     "kind": "Teaching",
     "text": "The late anger is a diagnostic. If a person's anger consistently arrives hours or days after the moment that should have produced it, they are running the power frequency. The delay is the whole tell."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is not to force the anger to arrive on time. It is to notice the connection between the late anger and the moment it belonged to. That noticing is already beginning to shift the frequency."
    }
   ]
  },
  {
   "id": "m06",
   "label": "6 · Making Yourself Small for Others",
   "items": [
    {
     "kind": "Teaching",
     "text": "Some shrinking is done in the presence of specific people. Not for the room in general, but for one or two individuals whose presence has always produced the reflex. A parent. A partner. An old friend. A boss. Someone whose own frequency is incompatible with the person's natural size."
    },
    {
     "kind": "Teaching",
     "text": "The shrinking is not a strategy. It is not done consciously to please. It happens on arrival — the person walks into the room and, before any decision has been made, is already smaller. The presence of that person triggers the frequency, and the frequency takes over."
    },
    {
     "kind": "Anecdote",
     "text": "A woman notices that in her own home, with her own friends, she is spacious. In the presence of one particular old school friend, she becomes a version of herself from twenty years ago — slightly apologetic, slightly over-attentive, slightly less than she is. The friend is not a bully. She is simply running a frequency that has always required the woman to be smaller in order to feel comfortable."
    },
    {
     "kind": "Teaching",
     "text": "This is one of the most difficult parts of the frequency because the shrinking is often reciprocal. The person shrinks to make the other comfortable. The other, in turn, relies on that comfort. The relationship functions, but it functions at the smaller size — and neither party usually knows why they are so tired after seeing each other."
    },
    {
     "kind": "Teaching",
     "text": "The shrinking in these relationships is not a sign that the relationship is bad. It is a sign that the relationship is running a frequency that was set many years ago and has never been revisited. The relationship can change. It rarely changes by itself."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the pattern in the relationships where you consistently leave feeling slightly less than you actually are. Not attacked. Not undermined. Just less. The less is the frequency, and it has been produced by both of you."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is not to stop shrinking around these people by force. It is to notice the shrinking in the moment — and to give it one sentence of your own voice, in your own head, at your own size. 'I am smaller here than I am.' That sentence alone begins the shift."
    }
   ]
  },
  {
   "id": "m07",
   "label": "7 · The Presence You Have Not Met",
   "items": [
    {
     "kind": "Teaching",
     "text": "People who have spent decades running the shrinking frequency often have no idea what their natural presence is like. They have never met it in a room. They know their small version well. They have sometimes glimpsed the natural size in a foreign city, in a moment of exhaustion, in a conversation with a stranger — but they have not recognised it as themselves."
    },
    {
     "kind": "Teaching",
     "text": "This is one of the strangest consequences of the frequency. A person can be well into midlife and still not know what they feel like at their own size. The frequency has been running so consistently that the natural size has become a rumour — a version of them that other people occasionally describe and that they themselves have never met."
    },
    {
     "kind": "Anecdote",
     "text": "A man is told by a colleague, after a long project, that he is one of the most grounded people in the office. He is genuinely surprised. He has spent the whole of the project running a small frequency, and he cannot reconcile the description with what he thought he was doing. He begins, slowly, to wonder what other people see."
    },
    {
     "kind": "Teaching",
     "text": "The natural presence is not aggression. It is not dominance. It is not volume. It is the ordinary fact of a person who is not making any adjustments. When it appears in someone who has spent decades shrinking, the person themselves rarely feels powerful — they feel relieved."
    },
    {
     "kind": "Teaching",
     "text": "Many people first encounter their natural size in a room where the frequency is not running. A foreign country where no one knows them. A group of strangers. A moment of fatigue so complete that the frequency simply cannot keep up. In those moments, the person sometimes notices a different quality in themselves — a spaciousness they did not know they had."
    },
    {
     "kind": "Teaching",
     "text": "The work is not to invent a new self. It is to recognise the self that has been there all along, mostly hidden behind the shrinking. The recognition is the shift."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one moment today when the frequency was not running — a small moment, ordinary, unremarkable. That moment is a portrait of your natural size. It can be returned to."
    }
   ]
  },
  {
   "id": "m08",
   "label": "8 · The Fear of Being Too Much",
   "items": [
    {
     "kind": "Teaching",
     "text": "The power frequency rests on a specific belief: that your natural size is too much. Not too much for the world in general — too much for the specific people who were there when the frequency was installed. The belief is often not about size at all. It is about the discomfort your size once produced in someone else."
    },
    {
     "kind": "Teaching",
     "text": "This belief is usually attached to a memory. A moment when a person's natural enthusiasm, or natural directness, or natural sadness, or natural joy, produced a response that registered as too much. A sigh. A step back. A change of subject. A silence. The child drew the conclusion and has been running it ever since."
    },
    {
     "kind": "Anecdote",
     "text": "A woman is in her thirties before she realises she has been apologising for enthusiasm her whole life. When she is excited, she says 'sorry' first — automatically, before the enthusiasm has finished arriving. She notices this one day and cannot remember when it started. Her mother, when told, says: 'You were always a bit much as a child.' The sentence lands as a joke. The woman understands."
    },
    {
     "kind": "Teaching",
     "text": "'Too much' is a description that is rarely about the person. It is a description of the discomfort their size produced in someone who had their own reasons for needing a smaller room. The child was not too much. The adult is not too much. The room was too small."
    },
    {
     "kind": "Teaching",
     "text": "This belief is often deeply intertwined with gender, race, class, and family role. Some people were told by the culture they lived in that their natural size was not welcome. Others were told only by a parent. The instinct that results is the same. The size the person carries is unwelcome in the room they grew up in."
    },
    {
     "kind": "Teaching",
     "text": "Realising that the belief was never about you is not a cure. It is a foothold. Once the belief has been seen to belong somewhere else, it begins, slowly, to loosen."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one moment today where 'sorry' arrived before the enthusiasm. You do not have to stop the apology yet. You only have to see what it is apologising for."
    }
   ]
  },
  {
   "id": "m09",
   "label": "9 · The Strength That Was Called Aggression",
   "items": [
    {
     "kind": "Teaching",
     "text": "Some people have been told, in more or less subtle ways, that their natural strength was actually aggression. Not because they were aggressive — because the room they were in could not hold the strength without feeling threatened by it. The child learns to soften the strength. The adult still does."
    },
    {
     "kind": "Teaching",
     "text": "This is one of the most confusing pieces of the power frequency, because the person may genuinely have been told that they were being aggressive. The message is often repeated, by the same people, over years. Eventually the person believes it. They live with a quiet doubt about their own character."
    },
    {
     "kind": "Anecdote",
     "text": "A woman is told, at work and in her family, that she is direct. The word is always said with a slight grimace. She learns to preface her sentences with a laugh. The laugh does not change the content, but it softens the arrival. After decades of laughing before she speaks, she begins to wonder whether the directness was ever the problem — or whether the reactions were."
    },
    {
     "kind": "Teaching",
     "text": "Real aggression is not direct. It is indirect, cruel, manipulative, and often quiet. The person accused of being aggressive for being direct is usually being accused of something else — of making the room feel something the room did not want to feel."
    },
    {
     "kind": "Teaching",
     "text": "This is the particular pain of the power frequency in people who have been labelled 'too direct' or 'too strong' or 'too intense'. The natural size is not the problem. The natural size has simply arrived in a room that has chosen a smaller scale, and the person has absorbed the room's discomfort as a fact about themselves."
    },
    {
     "kind": "Teaching",
     "text": "Recovery here is not about becoming softer. It is about refusing the label. Not by arguing — by living at the person's actual size and letting the room adjust. Some rooms will not. Some rooms cannot. This is information about the rooms, not about the person."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to say one direct sentence today without the small laugh at the front of it. Not because the laugh is wrong. Because seeing what the laugh was for is the whole work."
    }
   ]
  },
  {
   "id": "m10",
   "label": "10 · When Someone Takes the Space You Left",
   "items": [
    {
     "kind": "Teaching",
     "text": "The power frequency creates a specific kind of vacuum. When a person consistently takes less than their share, someone else takes more. Not maliciously — because space, attention, and presence are always being allocated, and if one person steps back, another steps forward to fill the room."
    },
    {
     "kind": "Teaching",
     "text": "In many families, partnerships, and teams, this is precisely the pattern. One person shrinks. Another expands. Neither is aware of the exchange. Both are running their frequencies. The room is the result of the two together."
    },
    {
     "kind": "Anecdote",
     "text": "A man realises, in therapy, that he has been the shrinking one in a marriage of thirty years. His wife, in the same sessions, realises she has been the expanding one. Neither of them designed this. Both have been running a frequency that arrived before either of them met. The marriage has been shaped by two inherited broadcasts, and neither was chosen."
    },
    {
     "kind": "Teaching",
     "text": "The realisation usually arrives with some pain. The shrinking person may feel resentment — sometimes justified, sometimes not — towards the person who took the space they left. The expanding person may feel exposed, as if they have been taking something they did not know was on offer."
    },
    {
     "kind": "Teaching",
     "text": "Neither is at fault. The pattern is a frequency, and the frequency arrived in both of them. The pattern can change — but not by one person changing alone. It changes when one person stops shrinking and the other becomes aware of the space that has just been freed."
    },
    {
     "kind": "Teaching",
     "text": "Some relationships cannot survive this shift. If the expanding person needs the shrinking person to stay small, the relationship is running on the shrinking, and will have to redefine itself or end. This is not a failure. It is one of the honest consequences of the frequency finally being seen."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is not to reclaim space by force. It is to notice the shape of the room, and to see whether the shape is actually yours. If it is not, the noticing alone will begin to change it."
    }
   ]
  },
  {
   "id": "m11",
   "label": "11 · Recognising the Shrinking",
   "items": [
    {
     "kind": "Teaching",
     "text": "The power frequency has a signature. A small pull-in before you take a seat. A tightening at the front of your body when someone looks at you for longer than a second. A quiet sense of relief when attention passes to someone else. That relief is one of the frequency's clearest signatures — the welcome of the spotlight moving away."
    },
    {
     "kind": "Teaching",
     "text": "Learn the signature. Not to fight it, not yet. Just to see it. The frequency cannot run a person for their whole life once it has been noticed. Once noticed, it becomes one voice among several, no longer the one running the room."
    },
    {
     "kind": "Anecdote",
     "text": "A woman begins to notice, over a year, that she has a specific breath pattern when she enters a crowded room. A half-inhale, then a hold. She has done this all her life. She thought it was just how she breathed. It is the frequency, preparing her to take up less space than she was about to."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is loudest in the moments just before being seen. Before a speech. Before entering a room. Before making a request. Before saying something in a meeting. Those are the moments the frequency runs fastest, because those are the moments the natural size is most likely to appear."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is also visible in the moments just after being seen. The rush to deflect a compliment. The immediate redirect to someone else's contribution. The small joke to cover the exposure. Those are the frequency's second acts — its way of undoing the fact that the person's natural size was briefly visible."
    },
    {
     "kind": "Teaching",
     "text": "You will know you are recognising the frequency rather than being run by it when you can observe the shrinking without immediately doing it. The moment of observation is small. It is also the whole of the work."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one moment today when the frequency prepared you to be smaller. You do not have to move differently. You only have to have seen the preparation."
    }
   ]
  },
  {
   "id": "m12",
   "label": "12 · Recalibrating",
   "items": [
    {
     "kind": "Teaching",
     "text": "The recalibration of the power frequency is not the achievement of an imposing presence. It is not the cultivation of a louder voice, a firmer handshake, a larger walk. It is the slow, patient practice of not making yourself smaller than you are — and of letting the world adjust to the size you actually occupy."
    },
    {
     "kind": "Teaching",
     "text": "The frequency does not disappear overnight. It has been running since early childhood. It will return in the presence of the people who installed it, in the rooms that never quite held it, and in the moments of high stakes. What changes is that the person can see it happening. That is the whole shift."
    },
    {
     "kind": "Anecdote",
     "text": "Two women reach their fifties in the same profession. One has spent the whole of her life adjusting to the size of the rooms she was in. The other has spent her life at her own size, and simply left the rooms that could not hold her. From the outside they have similar careers. From the inside, one is exhausted and one is settled. Neither can explain precisely what happened, because neither was tracking the frequency, only its absence or its constant pressure."
    },
    {
     "kind": "Teaching",
     "text": "You will know the frequency is shifting when you can enter a room without the pull-in. When someone looks at you for longer than a second and nothing tightens. When a compliment lands and you do not immediately deflect. When being seen is not automatically a cost."
    },
    {
     "kind": "Teaching",
     "text": "The power frequency is one of the deepest of all the sectors in this course, because it is bound up with the person's sense of their own right to exist at the size they are. It was installed early, it has run silently, and its loosening is often one of the most visible shifts in a person's whole life — not because they become louder, but because they stop being quieter than they are."
    },
    {
     "kind": "Teaching",
     "text": "You were not born with a smaller size. You were given one. The giving was not malicious — it was sometimes a kindness, sometimes a consequence of the giver's own shrinking, sometimes the only shape the room would hold. But it is not yours by nature. The natural size is still there, waiting to be recognised."
    },
    {
     "kind": "Recalibration",
     "text": "The same room. The same moment. Two different sizes. You have just read an entire sector about the space between them. That space is the whole of this course — and, in power, it is the space where you finally take up the amount of presence that was always yours."
    }
   ]
  }
 ]
};
