window.FREQ_SECTOR={
 "key": "belief",
 "title": "Belief",
 "glyph": "✶",
 "blurb": "The truths you were told were truths. Religion, culture, class, education — how a pattern gets installed and then mistaken for the nature of reality.",
 "philTitle": "Belief · The Fear Frequency & The Reversal",
 "philText": "Belief is not the problem. The problem is believing that what you were taught is the shape of reality. This sector is not about religion or politics — it is about the assumptions running underneath your life that you have never thought to question, because they arrived before you could, and because they have always been presented to you as the truth. It is about the moment a belief becomes a question.",
 "modules": [
  {
   "id": "m01",
   "label": "1 · The Truths You Never Questioned",
   "items": [
    {
     "kind": "Teaching",
     "text": "There is a set of assumptions running underneath your life that you have never thought to question — because they do not present themselves as assumptions. They present themselves as reality. They arrive in the form of sentences that begin with 'that is just how it is', or 'everyone knows', or 'obviously'."
    },
    {
     "kind": "Teaching",
     "text": "These are the installed truths. They are the assumptions that were given to you before you could question them, by people who were also given them before they could question theirs. They feel not like beliefs but like the furniture of the world — things that were simply always there."
    },
    {
     "kind": "Anecdote",
     "text": "A woman reaches her forties before she realises she has always believed that ambition is unattractive. Not because anyone said so directly. Because every woman in her family who was ambitious had been quietly described as difficult. The belief had been installed not by a sentence but by a tone, repeated for decades."
    },
    {
     "kind": "Teaching",
     "text": "The most powerful beliefs are not the ones you argue for. They are the ones you never notice you are holding. A belief you defend is already somewhat conscious. A belief that lives behind your arguments is the one that is actually running the show."
    },
    {
     "kind": "Teaching",
     "text": "The installed truths are not necessarily wrong. Some of them are true, some are partly true, and some are simply one culture's opinion about how life should be lived. The point is not to replace them. The point is to notice which ones are actually yours."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise an installed truth by the resistance it produces when questioned. Not the resistance of a good argument — the resistance of the body. A slight tightening. A flicker of discomfort. A sense that something is being threatened that should not be threatened. That flicker is the tell."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal begins with one question, asked quietly about something ordinary: what do I actually believe about this, apart from what I was told? You do not need to answer it fully. You only need to notice that the question is available."
    }
   ]
  },
  {
   "id": "m02",
   "label": "2 · The Certainties You Were Born Into",
   "items": [
    {
     "kind": "Teaching",
     "text": "Every child is born into a set of certainties. Not just ideas — certainties. The child does not choose them, does not evaluate them, does not even notice them as they arrive. They are simply present, the way air is present, the way gravity is present, the way the language the child will speak is present before the child has spoken a word."
    },
    {
     "kind": "Teaching",
     "text": "Some of these certainties are about the world. What is safe, what is dangerous, what is possible. Some are about people. What kind of person deserves respect, who can be trusted, what love looks like, what work is for. Some are about the child themselves — what the child is allowed to be, what they must hide, what they must prove."
    },
    {
     "kind": "Anecdote",
     "text": "A man grows up certain that the world is a place where you have to be alert. He cannot say where the certainty came from. His family never told him this directly. But somewhere in his earliest years, the assumption took root — perhaps in a raised voice, a slammed door, a mother's worried face. He is fifty. The world still feels slightly dangerous."
    },
    {
     "kind": "Teaching",
     "text": "The certainties of childhood are not the same as beliefs held lightly. They are structural. They are load-bearing. They shape what a person can even imagine noticing. Trying to argue someone out of a childhood certainty rarely works — the certainty is not a position, it is the ground the position stands on."
    },
    {
     "kind": "Teaching",
     "text": "This is why two people can look at the same evidence and reach opposite conclusions. They are not disagreeing about the evidence. They are running different certainties underneath it. The evidence is the same. The ground is different."
    },
    {
     "kind": "Teaching",
     "text": "You cannot remove the certainties of childhood entirely. They are as deep as language. But you can begin to notice them — and once noticed, they stop being the air you breathe and become something you can see."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal begins with a small experiment: think of one thing you consider obvious about how the world works, and try to remember the first time you heard it. If you cannot remember — if the certainty feels like it was always there — that is the ground. That is where the work begins."
    }
   ]
  },
  {
   "id": "m03",
   "label": "3 · How Belief Is Inherited",
   "items": [
    {
     "kind": "Teaching",
     "text": "Belief is not transmitted by teaching alone. In fact the most powerful beliefs are transmitted silently — by what adults do without thinking, by what they avoid, by the tone in which certain subjects are discussed, by the particular things that are never mentioned in the house."
    },
    {
     "kind": "Teaching",
     "text": "A child learns what is safe to want by what the parent is willing to say out loud. Learns what is dangerous to want by what the parent goes quiet about. Learns what is realistic by what the parent allows themselves to imagine. All of it is received before the child can form a sentence about it."
    },
    {
     "kind": "Anecdote",
     "text": "A man spends his life believing that money is not for people like him. He cannot find where the belief came from. His family was poor, but no one ever said money was not for them. What he does find, eventually, is that his father had turned down two opportunities in his life — not because he couldn't take them, but because he couldn't imagine himself taking them. The belief had been in the turning-down, not in the words."
    },
    {
     "kind": "Teaching",
     "text": "Belief is also inherited through what is celebrated. A child who is praised only for obedience learns that obedience is safe. A child who is praised only for achievement learns that achievement is the price of love. The belief is not taught. The belief is modelled — consistently, quietly, for years."
    },
    {
     "kind": "Teaching",
     "text": "Some beliefs are inherited from a family that has moved. Migration carries a particular kind of inherited belief — the belief that the world is elsewhere, that the present is temporary, that safety is somewhere other than here. The child grows up with an instinct to leave that the parent never intended to install."
    },
    {
     "kind": "Teaching",
     "text": "You can read a family's beliefs by its thresholds. The moment a subject is changed. The moment a voice shifts. The moment a laugh arrives slightly too quickly, covering something. Those thresholds are where the beliefs live."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one inherited belief and to ask: is this mine, or did I absorb it? You do not have to change it. You only have to see where it came from."
    }
   ]
  },
  {
   "id": "m04",
   "label": "4 · What Everyone Knows",
   "items": [
    {
     "kind": "Teaching",
     "text": "Some of the most powerful installed truths announce themselves with the phrase 'everyone knows'. Everyone knows that money changes people. Everyone knows that you cannot trust strangers. Everyone knows that life is hard. Everyone knows — as if the phrase itself were proof."
    },
    {
     "kind": "Teaching",
     "text": "'Everyone knows' is a signal, not an argument. It says: this belief is so deep in the culture that questioning it would be absurd. It works by making the questioning feel eccentric rather than philosophical."
    },
    {
     "kind": "Anecdote",
     "text": "A woman moves to a new country and discovers, over several years, that several things 'everyone knew' in her original country are considered odd in the new one. She is not naive — she knows the new country has its own 'everyone knows' items. But the shock of discovering that one of hers was local has never quite left her."
    },
    {
     "kind": "Teaching",
     "text": "The contents of 'everyone knows' vary enormously across cultures and generations. What is 'obvious' in one country is strange in the next. What is 'obvious' to one generation becomes questionable to the next. The certainty is not a fact about the world. The certainty is a fact about the community that repeats it."
    },
    {
     "kind": "Teaching",
     "text": "'Everyone knows' is not always wrong. Many things 'everyone knows' are genuinely true and useful. But the phrase is doing two things at once: it is stating a belief, and it is preventing you from examining it. The second is the point of this module."
    },
    {
     "kind": "Teaching",
     "text": "You can often tell a belief is culturally installed by how quickly it defends itself. A belief that is genuinely yours can be argued with and revised. A belief that was culturally installed reacts to questioning as if it were being attacked — because, in a sense, it is. The community is being questioned through you."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal begins with a small practice: notice one sentence you could say today that begins with 'everyone knows', and finish it. Then ask yourself — do I know this, or do I know that people around me say it? The two are not the same."
    }
   ]
  },
  {
   "id": "m05",
   "label": "5 · The Belief You Are Paid To Have",
   "items": [
    {
     "kind": "Teaching",
     "text": "Some installed beliefs are reinforced by reward. You are paid to have them — not necessarily in money, but in approval, in belonging, in promotion, in the warmth of a community that agrees with you. The belief becomes a currency. To question it costs you something."
    },
    {
     "kind": "Teaching",
     "text": "This is not corruption. It is human. Every group offers belonging in exchange for agreement with its beliefs. The person who questions is not usually punished dramatically. They are just — quietly, slowly — cooled. The warmth goes out of the welcome. The invitations become less frequent."
    },
    {
     "kind": "Anecdote",
     "text": "A man in his industry has always agreed with a widely-held belief about how the work should be done. When new evidence emerges that challenges the belief, he does not update. He cannot. His entire standing in the industry depends on the belief being true. To question it would cost him more than he is willing to pay."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise a paid belief by the shape of your resistance to questioning it. Not the resistance of a good argument — the resistance of a cost. A sense that if you questioned this, you would lose something you do not want to lose."
    },
    {
     "kind": "Teaching",
     "text": "This is not only true of large political or religious beliefs. It is true of small professional beliefs, family beliefs, friendship-group beliefs, the shared opinions of any community you belong to. Every community has its certainties, and every community pays for agreement."
    },
    {
     "kind": "Teaching",
     "text": "The cost of leaving a paid belief is real. It is not a thought experiment. Sometimes the price is worth it. Sometimes it is not. What matters is that the price is seen clearly rather than paid unknowingly. A belief that has been chosen despite the cost is a different thing from a belief that has never been examined."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal begins with one question asked gently: which of my beliefs would cost me something to question? You do not need to question them yet. You only need to know which ones are carrying a price."
    }
   ]
  },
  {
   "id": "m06",
   "label": "6 · The Belief Beneath the Belief",
   "items": [
    {
     "kind": "Teaching",
     "text": "Behind most beliefs there is another belief. Behind 'money is not for people like us' is 'I am not someone who gets things'. Behind 'life is hard' is 'I am not supposed to enjoy this'. Behind 'you cannot trust anyone' is 'I am alone in this'. The surface belief is often a defence for something deeper."
    },
    {
     "kind": "Teaching",
     "text": "This is why arguing at the surface rarely changes anything. You can disprove the surface belief and leave the deeper one untouched. The deeper belief then simply finds a new surface. The person is not holding a position. The person is protecting a wound."
    },
    {
     "kind": "Anecdote",
     "text": "A man argues for years that ambition is dangerous. He has read widely on it, has examples, has a philosophy. Eventually, in a quiet moment, he says something different: he does not believe he is capable of achieving anything. The philosophy had been a way of making that belief sound respectable."
    },
    {
     "kind": "Teaching",
     "text": "You can find the belief beneath a belief by asking: what would I have to admit about myself if this belief were false? The deeper belief is usually about who you are, not about how the world works."
    },
    {
     "kind": "Teaching",
     "text": "Once the deeper belief is seen, the surface belief often falls away on its own. It does not have to be argued with. It was only ever the outer skin of something else — and the something else is what actually needs to be seen."
    },
    {
     "kind": "Teaching",
     "text": "This is the work of module six. Not to change your beliefs, but to look one layer deeper than the beliefs you can name. The layer below the beliefs you can argue is usually the layer that has been running the show."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal begins with one belief that you hold firmly, and one question asked slowly: what would I have to believe about myself for this belief to make sense? The answer is often more revealing than the belief itself."
    }
   ]
  },
  {
   "id": "m07",
   "label": "7 · When the Belief Stops Fitting",
   "items": [
    {
     "kind": "Teaching",
     "text": "There comes a moment in most lives when a belief that has always fit stops fitting. The evidence is the same. The belief is the same. But something in you has shifted, and the belief no longer lands the way it used to."
    },
    {
     "kind": "Teaching",
     "text": "This is often uncomfortable. The person may not have a new belief ready. They simply know that the old one no longer fits. They are, for a period, without the certainty that had been holding them up. This is not a failure. It is the natural process of belief updating itself."
    },
    {
     "kind": "Anecdote",
     "text": "A woman who has spent her whole life believing that hard work pays off, in a specific and reliable way, begins to see around her that it does not always — and that sometimes the ones who work the hardest are the ones who get the least. She does not immediately adopt a new belief. She simply stops being able to hold the old one without a small, private flinch."
    },
    {
     "kind": "Teaching",
     "text": "The discomfort of losing a belief is often confused with losing truth itself. It is not. It is losing an assumption you had mistaken for truth. Something is being lost, but it was never what it seemed to be."
    },
    {
     "kind": "Teaching",
     "text": "Some people meet this moment by defending the belief harder. Others by abandoning all beliefs and becoming cynical. Both are attempts to avoid the middle ground — the ground of holding beliefs lightly, updating them as evidence arrives, and being willing to be, for a while, without a settled answer."
    },
    {
     "kind": "Teaching",
     "text": "The person who can tolerate the gap between beliefs is the person who can update. The person who cannot tolerate the gap defends, or abandons, or becomes fixed. The whole capacity for change lives in that gap."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is not to force a new belief too quickly. It is to let the old one rest, unfinished, for a while. To be comfortable with not yet knowing. That comfort is the ground of all real belief change."
    }
   ]
  },
  {
   "id": "m08",
   "label": "8 · The Belief You Were Told Was Humility",
   "items": [
    {
     "kind": "Teaching",
     "text": "Some of the most difficult installed beliefs do not present themselves as beliefs. They present themselves as virtues. Especially the belief that you should not think too much of yourself. This arrives disguised as humility."
    },
    {
     "kind": "Teaching",
     "text": "Humility, in its real form, is the opposite of arrogance — a clear-eyed view of one's own strengths and weaknesses. But the version installed in many homes and schools is different. It is the belief that any positive view of yourself is dangerous. That self-love must be guarded against, or hidden, or quickly retracted."
    },
    {
     "kind": "Anecdote",
     "text": "A woman wins an award and receives compliments for a week. Every time, she deflects. Eventually, in a private moment, she notices something: she deflects not because she is humble, but because the small positive moment feels, in her chest, like danger. She has been taught that feeling good about herself is a trap."
    },
    {
     "kind": "Teaching",
     "text": "The installed humility often shows up in a particular reflex: the immediate shrinking when praised. The deflecting laugh. The self-deprecating joke. These are not modesty. They are a specific frequency — the belief that any light you allow in will draw something worse."
    },
    {
     "kind": "Teaching",
     "text": "This belief is often transmitted by well-meaning people who were themselves afraid of pride. A parent who was told their self-worth was dangerous will instinctively, quietly, transmit the same belief. The child receives it as a virtue and carries it for a lifetime."
    },
    {
     "kind": "Teaching",
     "text": "The undoing of this belief is often the beginning of a person's ability to receive — praise, love, opportunity, success. Until it is seen, the receiving is impossible, because the receiving feels like a violation of something sacred."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to receive one compliment today without deflecting. Not with pride. Not with performance. Just with a quiet 'thank you'. The discomfort in that moment is the belief, still running. Let it be there."
    }
   ]
  },
  {
   "id": "m09",
   "label": "9 · The World That Contradicts It",
   "items": [
    {
     "kind": "Teaching",
     "text": "A moment often arrives when life itself contradicts an installed belief. The evidence that does not fit. The person who is kind despite the belief that everyone is selfish. The success that arrives despite the belief that it cannot. The love that survives despite the belief that love does not last."
    },
    {
     "kind": "Teaching",
     "text": "When the world contradicts a belief, the belief does not usually update immediately. It resists. It explains the contradiction away. It reframes. The person holding it may not even notice they have done this — the belief is doing the noticing for them."
    },
    {
     "kind": "Anecdote",
     "text": "A man who has always believed that nobody helps anyone for free is helped, sincerely, by a stranger. He accepts the help and, on the way home, decides the stranger must have had some agenda after all. It is only years later that he notices the reflex — the way the contradiction had been quietly refused."
    },
    {
     "kind": "Teaching",
     "text": "This is one of the clearest ways to see a belief you have been holding without knowing. The belief is visible in how quickly you dismiss the evidence that contradicts it. The speed of the dismissal is the tell."
    },
    {
     "kind": "Teaching",
     "text": "Contradiction is uncomfortable because the belief is doing work. It is holding a piece of the self in place. To accept the contradiction would be to loosen that piece — and the piece may have been holding something the person is not ready to look at."
    },
    {
     "kind": "Teaching",
     "text": "The work of this module is not to force belief change. It is to notice the moments of contradiction, and to sit with them, without immediately reframing. The refusal to reframe is the whole of the practice."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal begins with one recent contradiction you have been quietly filing away. Not to change the belief yet. Just to look at the contradiction clearly, without deciding it must have an explanation that preserves the belief."
    }
   ]
  },
  {
   "id": "m10",
   "label": "10 · Beliefs You Would Not Choose Now",
   "items": [
    {
     "kind": "Teaching",
     "text": "There is a strange moment in the work of seeing beliefs clearly. It is the moment you notice a belief that is still running your life, that you would not, if you were choosing today, choose to hold. The belief is not a mystery. You can name it. You simply cannot yet stop running it."
    },
    {
     "kind": "Teaching",
     "text": "This is not a failure. It is one of the most common — and most uncomfortable — stages in the whole process. The belief has been installed. You have seen it. You do not endorse it. It is still there, still active, still shaping your reactions."
    },
    {
     "kind": "Anecdote",
     "text": "A woman realises, in her sixties, that she has always believed people like her are not supposed to be in charge. She does not believe this consciously. She would defend the opposite opinion. But in every room where she is the most senior, she still positions herself slightly to one side — a habit that arrived with the belief, and that outlives the belief's conscious endorsement."
    },
    {
     "kind": "Teaching",
     "text": "The belief you would not choose now is not your failing. It is your inheritance. It came in before you could choose it. It has been running for decades. It will not leave simply because you have noticed it. What will change, over time, is the depth of its control."
    },
    {
     "kind": "Teaching",
     "text": "The single biggest error in this stage is to try to argue yourself out of the belief. You cannot. The belief does not live in the thinking mind — it lives in the body, in the reflexes, in the small unnoticed choices. To change it, you have to notice it in action, repeatedly, without judgement."
    },
    {
     "kind": "Teaching",
     "text": "Notice is the whole work. Noticing the belief in the moment it runs. Noticing the reflex. Noticing the position you take in the room before you have decided to take it. Each noticing loosens something. It does not loosen everything. But it loosens something."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to be patient with a belief you have already seen. It is still running. That is expected. Your job is not to force it out. Your job is to keep noticing it, gently, without the belief that noticing should be enough."
    }
   ]
  },
  {
   "id": "m11",
   "label": "11 · Recognising the Installed Belief",
   "items": [
    {
     "kind": "Teaching",
     "text": "By now you have met a number of installed beliefs — in the abstract, and, if you have been reading carefully, in yourself. The work of module eleven is to recognise them quickly — to spot them while they are still running, before they have shaped the whole hour."
    },
    {
     "kind": "Teaching",
     "text": "The installed belief has a signature. It arrives before the thinking does. It arrives as an assumption, not a thought. It arrives complete, as if it did not need to be formed. When something arrives in your mind already finished, and feels obviously true, the belief is likely running."
    },
    {
     "kind": "Anecdote",
     "text": "A man begins to notice that certain opinions arrive in him fully formed, with a slight feeling of rightness, before he has thought about the topic. He starts keeping a small list of these. The list, over a year, has become a portrait of his installed beliefs."
    },
    {
     "kind": "Teaching",
     "text": "The installed belief is loudest in moments of pressure. In a hurry. In an argument. In the seconds before sleep. Those are the moments when the belief runs the fastest, because there is no time for the person to think their own thoughts."
    },
    {
     "kind": "Teaching",
     "text": "Learn to notice the pause. The moment before you take a position on something. If the position arrives instantly, with no work, the belief has arrived with it. If the position arrives slowly, after thought, it might be genuinely yours."
    },
    {
     "kind": "Teaching",
     "text": "You will also recognise the installed belief by the company it keeps. Installed beliefs travel in sets. The belief that money is dangerous often travels with the belief that pleasure is suspect and that visible success attracts misfortune. Seeing one often reveals the others."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is small. Once a day, notice one opinion that arrived already finished. You do not need to change it. You only need to see that it arrived from somewhere."
    }
   ]
  },
  {
   "id": "m12",
   "label": "12 · Recalibrating",
   "items": [
    {
     "kind": "Teaching",
     "text": "The recalibration of belief is not the adoption of new beliefs. It is not the replacement of a set of certainties with a better set. It is the slow, patient development of the capacity to hold beliefs lightly — to be able to say 'this is what I currently think', rather than 'this is what is true'."
    },
    {
     "kind": "Teaching",
     "text": "The person who can hold beliefs lightly is not weaker. They are, in a specific and quiet way, stronger. They can update. They can be wrong. They can notice, halfway through a certainty, that the certainty is not quite theirs. They can, in fact, change."
    },
    {
     "kind": "Anecdote",
     "text": "Two people grow up with similar installed beliefs. One spends a lifetime defending the beliefs whenever they are questioned. The other begins, in her thirties, the slow work of examining them. Thirty years later the first is certain about many things and anxious about most. The second is uncertain about many things and at peace about most."
    },
    {
     "kind": "Teaching",
     "text": "The reversal does not feel like being right. It feels like being free. The person who has loosened the grip of installed belief does not need every question to have an answer. They can live in the middle of not knowing — and find, in that middle, a kind of ground that the beliefs never provided."
    },
    {
     "kind": "Teaching",
     "text": "You will know the recalibration is working when a belief you have held for years is questioned, and your first response is curiosity rather than defence. Not agreement — just curiosity. That shift is one of the clearest signs that the frequency is releasing."
    },
    {
     "kind": "Teaching",
     "text": "The installed beliefs do not leave. They were too deep for that. What leaves is their authority. They become one voice among many — a voice from your past, often worth listening to, no longer running the room. That is enough. That is the work."
    },
    {
     "kind": "Recalibration",
     "text": "The same world. The same facts. Two different beliefs running underneath them. You have just read an entire sector about the space between them. That space is the whole of this course — and, in belief, it is the space where the truth stops being what you were told and starts being something you can actually see."
    }
   ]
  }
 ]
};
