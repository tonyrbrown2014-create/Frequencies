window.FREQ_SECTOR={
 "key": "desire",
 "title": "Desire",
 "glyph": "☾",
 "blurb": "The wanting you were taught to distrust. Hunger, appetite, longing — the frequency that decides whether wanting is safe, and the reversal that lets you want what you actually want.",
 "philTitle": "Desire · The Fear Frequency & The Reversal",
 "philText": "Desire is not the problem. The frequency that decides whether wanting is allowed is the problem. This sector is not about appetite or restraint — it is about the quiet assumption, installed long before the first wanting, that desire is suspect: that the wanting itself is evidence of something wrong. It is about the moment the person can want what they want, without the wanting needing to be defended.",
 "modules": [
  {
   "id": "m01",
   "label": "1 · The Wanting You Do Not Trust",
   "items": [
    {
     "kind": "Teaching",
     "text": "Everyone wants. This is not a moral fact, or a psychological one — it is an ordinary fact about being alive. The body wants food, warmth, rest, sex, movement. The mind wants company, ideas, beauty, the specific things that make an individual a person. Some people trust the wanting. Many do not. Many have learned, in a way they cannot quite remember learning, that wanting itself is not safe."
    },
    {
     "kind": "Teaching",
     "text": "The desire frequency is not the wanting. The wanting arrives on its own. The frequency is the review the wanting has to pass through before it is permitted to be a fact about the person. In some bodies, wanting is reviewed and permitted. In others, the review is so hostile that the wanting barely reaches consciousness before it is dismissed."
    },
    {
     "kind": "Anecdote",
     "text": "A woman, at a restaurant, is asked what she would like. She pauses. She looks at the menu. She glances at the person she is with. She asks what they are having. She says she thinks she will have the same. She is not an indecisive person. She has simply not been asked, in a way that landed, what she actually wanted, for the whole of her adult life."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is invisible to the person because it never speaks as a veto. It speaks as a preference for the other person's preference. It says: I am easy. It says: I don't mind. It says: whatever you want. These sentences are not lies. They are the frequency, running the review, and quietly deciding that the person's wanting is not the wanting the situation is asking for."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is often installed by a household where the person's wants were either ignored, or corrected, or treated as evidence of selfishness. A child who is told what to want, or told that wanting is greed, or told that others come first, learns that wanting arrives with a problem. The wanting is the same in the adult. The problem has simply become invisible."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of the person's answers. Not the answers to big questions. The answers to small ones. What do you want to eat. What do you want to do this weekend. Where do you want to go. The frequency is more visible in the small questions, because the small questions are the ones the person has practised deflecting the most."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal begins with one small noticing: when did you last want something — anything, small or large — and let the wanting be a fact, without immediately reaching for someone else's preference? Not to act on it. Just to notice that the wanting was permitted to exist."
    }
   ]
  },
  {
   "id": "m02",
   "label": "2 · The Wanting That Was Taught to Be Greed",
   "items": [
    {
     "kind": "Teaching",
     "text": "There is a specific moral training that some households give their children: that wanting is a form of greed, and that the correct posture toward wanting is gratitude for what is already there. This training is often delivered with love. It is often delivered by people who were themselves trained the same way. It is still, in its effect, a decision about what wanting is."
    },
    {
     "kind": "Teaching",
     "text": "The child who receives this training does not stop wanting. The child simply learns that wanting is not something to express. It is something to have and to hide. The adult who emerges from this training is often generous, kind, and quietly resentful in a way they cannot explain."
    },
    {
     "kind": "Anecdote",
     "text": "A man has, for twenty years, bought his wife thoughtful gifts. He is very good at it. He is also, quietly, unable to tell her what he would like. If she asks, he says he doesn't need anything. He does need things. He wants things. But the wanting has been covered by a lifetime of being told that wanting was a small failing, and that the correct thing to want was nothing."
    },
    {
     "kind": "Teaching",
     "text": "The frequency does not just suppress the wanting. It reassigns it. The wanting becomes a posture of giving. The person becomes the one who gives to others, the one who is generous, the one who does not need. The giving is real. The giving is also a place where the wanting has gone to hide."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is not always connected to money. It is connected to any resource the person might want for themselves. Time. Attention. Care. Space. Pleasure. Rest. The training is the same: what you want for yourself is a small taking from someone else."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of the person's generosity. The person gives more than the situation calls for. They give before anyone asks. They give in ways that would embarrass the person receiving, if the receiving were fully noticed. The generosity is real. The frequency is in the excess."
    },
    {
     "kind": "Teaching",
     "text": "The reversal, in this module, is not to stop being generous. It is to notice whether the generosity is flowing from a place of choice, or from a place where the wanting was taught to hide. The two feel the same from the outside. They are very different from the inside."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to want one thing for yourself this week, without immediately giving it to someone else. Not a big thing. Just something you would enjoy, that is yours, that no one else has to share or approve."
    }
   ]
  },
  {
   "id": "m03",
   "label": "3 · The Wanting That Is Not Permitted to Be Named",
   "items": [
    {
     "kind": "Teaching",
     "text": "Some wants are permitted. Food, when hungry. Rest, when tired. Kindness, when asked. Other wants are less permitted. Sexual desire in some bodies, in some contexts. Ambition. Physical pleasure for its own sake. Wanting to be looked at. Wanting to be alone. Wanting to have more than the family had."
    },
    {
     "kind": "Teaching",
     "text": "The frequency in these cases is specific. It is not that the person cannot want at all. It is that certain wants arrive with a small internal flinch. The want is felt, and then the want is immediately reviewed, and the review includes the possibility that the want is shameful. The flinch is the frequency."
    },
    {
     "kind": "Anecdote",
     "text": "A man notices, in his forties, that he can want anything except leisure. Food, work, love, ambition — all of it is permitted. Only rest is not. When he tries to sit down with no purpose, the frequency arrives with a critique. He is being lazy. He is avoiding something. He should be doing. He is not aware of having decided this. He is aware only of the flinch, which arrives the moment the sitting begins."
    },
    {
     "kind": "Teaching",
     "text": "The unnameable wants are often the wants that were most specifically criticised in the household. A parent who was uncomfortable with the child's sexual curiosity. A father who mocked his son's tenderness. A mother who made clear that ambition in a girl was not becoming. The child learns that this specific wanting is not to be permitted, and the adult inherits the prohibition."
    },
    {
     "kind": "Teaching",
     "text": "The frequency in these cases is often accompanied by a substitution. The person develops a want that is adjacent to the prohibited want, and permitted. The wanting for rest becomes a wanting for useful rest. The wanting for sexual pleasure becomes a wanting for connection. The wanting for ambition becomes a wanting for care. The substitutions are not failures. They are the frequency's method."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of the person's exceptions. Almost every want has a version the person can permit, and a version they cannot. The prohibited version is usually the more direct one. The version the person can permit has been softened into something the household would recognise."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to name, quietly, one want you have that you do not say out loud. Not to the person it concerns. Not to anyone. Just to yourself. The naming is the beginning of the want being permitted to be what it is."
    }
   ]
  },
  {
   "id": "m04",
   "label": "4 · The Wanting That Becomes Someone Else’s",
   "items": [
    {
     "kind": "Teaching",
     "text": "One of the frequency's quieter moves is to blur the boundaries of wanting. The person who cannot want for themselves often develops a talent for wanting on behalf of others. They can tell you exactly what their partner wants, what their child wants, what their friend needs. They cannot tell you the same about themselves."
    },
    {
     "kind": "Teaching",
     "text": "The frequency uses this talent as a solution. If the person cannot want for themselves, they can at least want for others, and the wanting-for-others is permitted. The person builds a life of anticipating the wants of everyone around them, and the anticipation is real, and the anticipation is also the place the person's own wanting has gone."
    },
    {
     "kind": "Anecdote",
     "text": "A woman is extraordinarily good at knowing what her friends need. She remembers preferences, notices moods, brings the right thing at the right time. She is the person everyone calls when they are in trouble. When asked, one evening, what she herself would like, she cannot answer. Not because she does not want. Because the machinery that notices wanting has been pointing outward for so long that it has forgotten how to point in."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is not selfishness redirected. It is the self displaced. The person is present in the room, but the wanting self is elsewhere — in the friend, the partner, the child. The person's own wants are still there, but they have been assigned to other people to hold."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of the person's exhaustion. The person is not tired from giving. They are tired from giving without a wanting that belongs to them. The giving is unconditional. The condition that has been removed is the person's own presence in the giving."
    },
    {
     "kind": "Teaching",
     "text": "The reversal, in this module, is not to stop giving. It is to begin to notice what the person wants, even while giving. Not to withdraw from the room. To re-enter it as someone with a wanting, not only as someone with an awareness of others' wanting."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice, once this week, a moment when you knew what someone else wanted and did not know what you wanted. Not to change the moment. To see that the knowing is running in only one direction."
    }
   ]
  },
  {
   "id": "m05",
   "label": "5 · The Wanting That Arrives as Anger",
   "items": [
    {
     "kind": "Teaching",
     "text": "When the desire frequency is very strong, the wanting does not stay a wanting. It becomes anger. Not the anger of the moment. The anger underneath — the anger of someone whose wanting has been suppressed for so long that it can only emerge as irritation, as criticism, as a heat that arrives in the presence of anyone who is allowing themselves to want."
    },
    {
     "kind": "Teaching",
     "text": "The person running the frequency often does not connect the anger to the wanting. They experience the anger as a reaction to a situation. They are annoyed by a partner who wants too much. They are frustrated by a friend who cannot be satisfied. They are irritated by a colleague who asks for what they want. The anger is not about the other person. The anger is about the wanting that the person has not permitted."
    },
    {
     "kind": "Anecdote",
     "text": "A woman notices that she is most irritated by the people in her life who know what they want. She has a friend who is clear, direct, unafraid to ask. The woman finds her exhausting. The woman does not understand why. In her fifties, she realises: the friend is exhausting because the friend's wanting is a mirror. The woman has not permitted her own."
    },
    {
     "kind": "Teaching",
     "text": "The frequency does not simply suppress the wanting. It turns the wanting against the wanting itself, in the form of anger at other people's wanting. The person becomes an unwitting enforcer of the same prohibition in the room — not through cruelty, through the shape of their irritation."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of the person's irritations. What kind of people annoy them most? If it is people who are clear about their wants, or people who take pleasure seriously, or people who ask for what they need — the frequency is running, and the anger is its messenger."
    },
    {
     "kind": "Teaching",
     "text": "The reversal is not to stop feeling the anger. It is to see the anger as information about the person's own wanting, not as a fact about the person they are angry at. The anger is the wanting, in a form that the person has learned to permit."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one person whose wanting irritates you, and to ask, quietly, what they are allowing themselves that you are not. The question does not need an answer. The question is the beginning."
    }
   ]
  },
  {
   "id": "m06",
   "label": "6 · The Wanting That Only Arrives After the Drink",
   "items": [
    {
     "kind": "Teaching",
     "text": "Many people running the desire frequency notice that their wanting is more available in specific conditions. After a drink. Late at night. When tired. When alone. In a foreign city. The frequency, which is otherwise quite effective at suppressing the wanting, does not run as strongly in these states, and the person finds themselves wanting things they did not know they wanted."
    },
    {
     "kind": "Teaching",
     "text": "These states are often misread. The person assumes the wanting is less real, because it only arrives when they are not themselves. The reverse is true. The wanting is more real. The states in which it arrives are the states in which the frequency has briefly loosened its grip."
    },
    {
     "kind": "Anecdote",
     "text": "A man notices that he only ever wants to dance after a few drinks. He is embarrassed by this. He assumes the dancing is something false in him, brought out by alcohol. Then, one evening, sober, at a wedding, he catches himself wanting to dance. He does not. But he wants to. He realises: the dancing was never about the drink. The drink was simply the only condition in which the wanting was permitted to arrive."
    },
    {
     "kind": "Teaching",
     "text": "The frequency uses the cover of altered states to permit wants it otherwise suppresses. The person is not becoming someone different. The person is becoming someone who is, for a moment, not under the frequency's review. The wanting that arrives in these states is not a lesser wanting. It is the ordinary wanting, and the frequency has temporarily stepped away."
    },
    {
     "kind": "Teaching",
     "text": "This is why some people are drawn to altered states in a way that puzzles them. They are not seeking oblivion. They are seeking the version of themselves who is allowed to want. The frequency has made the wanting so difficult to access that the person seeks a state in which it can arrive."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of the person's surprises. What wanting arrived, in one of these states, that they did not know was there? The wanting was not the state's invention. The wanting was simply the frequency, briefly set down."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one wanting that only ever arrives in a particular state — tiredness, night, travel, drink — and to see that the wanting is not the state's. The wanting is the person's. The state simply allowed it."
    }
   ]
  },
  {
   "id": "m07",
   "label": "7 · The Wanting That Is Not Held",
   "items": [
    {
     "kind": "Teaching",
     "text": "One of the frequency's subtler moves is to permit the wanting but never to permit the wanting to be held. The person can feel the wanting, notice it, even express it. What they cannot do is rest in it. The wanting arrives, and the person immediately does something with it. They act on it, or they repress it, or they turn it into a plan, or they turn it into guilt. The wanting is never simply held."
    },
    {
     "kind": "Teaching",
     "text": "Held wanting is the state of wanting something and letting the wanting be, without resolving it. Not acting on it, not suppressing it, just letting it sit in the body. Held wanting is where the person learns what they actually want, as opposed to what they are willing to notice wanting."
    },
    {
     "kind": "Anecdote",
     "text": "A woman notices that she wants to travel to a specific country. She notices the wanting, and within a week she has booked a flight, planned an itinerary, and started a spreadsheet. The wanting had not been permitted to be a wanting. The wanting had been converted immediately into a plan. In fact she did not know, in the middle of the planning, whether she actually wanted to go, or whether she had simply wanted to want to go."
    },
    {
     "kind": "Teaching",
     "text": "The frequency in these cases is not suppression. It is over-activity. The person's mind will not let the wanting be still. It must move the wanting into something else — action, or guilt, or anticipation. The willingness to let the wanting rest in the body, without resolution, is the thing the frequency prevents."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of the person's calendar. When the person wants something, how long does it take to become a plan? If the wanting almost immediately becomes a plan, the wanting has not been permitted to be a wanting. It has been permitted only as a task."
    },
    {
     "kind": "Teaching",
     "text": "The reversal is to want something, once this week, and to not do anything about it. Not forever. Just for a few days. Let the wanting be in the body without moving. See what the wanting does when it is not immediately converted."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one want that has been turned into a plan too quickly, and to unschedule it — not to abandon the want, just to let it be a want for a few days before it is a plan."
    }
   ]
  },
  {
   "id": "m08",
   "label": "8 · The Wanting You Stopped Knowing You Had",
   "items": [
    {
     "kind": "Teaching",
     "text": "The desire frequency, when it has been running for long enough, does not just suppress the wanting. It erases the record. The person does not experience the wanting and then prevent it. They do not experience it at all. The wanting has been removed from the person's list of available feelings, and the person no longer knows it was there."
    },
    {
     "kind": "Teaching",
     "text": "This is one of the frequency's deepest installs. The person has not just learned to hide their wanting. They have learned to not have it. The wanting still exists — the body still wants — but the wanting no longer arrives as a felt state. It arrives as a vague emptiness, or a low-grade dissatisfaction, or nothing at all."
    },
    {
     "kind": "Anecdote",
     "text": "A man, in his late fifties, is asked by a doctor what he enjoys. He pauses. He cannot answer. He is not depressed. He has interests. He reads. He walks. He works. But the question 'what do you enjoy' does not have a real answer. He has not thought of enjoyment as a category of his own wanting for decades. He has thought of it as a thing other people do."
    },
    {
     "kind": "Teaching",
     "text": "The frequency in these cases is loosened by small experiments. The person is asked: if you had a completely free afternoon, no obligations, no one to please, what would you do? The first answer is often generic — sleep, read, walk. The person is asked again. Not the first thing. The second. The fifth. The wanting is still there. It has just not been asked, in a way that landed, for a long time."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of the person's answers to preference questions. Not the answers about work or ethics. The answers about small pleasures. Coffee or tea. Lake or sea. Saturday or Sunday. The person often does not have a preference. The lack of preference is not the person's nature. It is the frequency's record."
    },
    {
     "kind": "Teaching",
     "text": "The reversal, in this module, is patient. The person does not recover their wanting by deciding to. They recover it by giving the wanting, over months, small repeated opportunities to arrive. The wanting does not come back in one moment. It comes back, slowly, like a limb waking up."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to answer one small preference question this week with a real answer, not the easy answer. Coffee or tea. Not 'either'. One of them. The wanting can start that small."
    }
   ]
  },
  {
   "id": "m09",
   "label": "9 · The Wanting That Was Called Needy",
   "items": [
    {
     "kind": "Teaching",
     "text": "There is a specific accusation that many people received in childhood, in adolescence, or in an early relationship: that they were too much, too wanting, too needy. This accusation did its work. The wanting, which was ordinary, was placed under suspicion. And the person, who was simply wanting what any person wants, learned to be embarrassed by the wanting itself."
    },
    {
     "kind": "Teaching",
     "text": "The frequency in these cases is close to the surface. The person often knows they have a wanting. They simply cannot permit it to be seen, because the original accusation is still in the room. Any expression of the wanting feels, in the body, like the original moment of being called too much."
    },
    {
     "kind": "Anecdote",
     "text": "A woman, in a new relationship, notices that she cannot say what she wants from the partner. Not because the partner is difficult — the partner is generous and kind. The woman simply cannot ask. Every request feels like a confession of neediness. She has brought an old accusation into a new room. The partner has never accused her of anything."
    },
    {
     "kind": "Teaching",
     "text": "The frequency uses the accusation as evidence. It tells the person that the wanting is the problem, and the person, having received this verdict, does not question it. The person has been running the accusation as if it were true — as if wanting anything from anyone were the neediness that was named."
    },
    {
     "kind": "Teaching",
     "text": "The reversal does not happen in an argument with the accusation. It happens in the slow accumulation of small experiences in which the person wants something, asks for it, and is met — not with irritation, but with the ordinary kindness of an ordinary person who is happy to give."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of the person's asking. They ask too quietly. They ask as if it were a question rather than a request. They frame the request as something the other person might like to do, rather than something the person wants. The framing is the frequency."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to ask for one thing this week in a way that acknowledges it is a request. Not as a question. Not as a suggestion. As a request. Notice whether the room accepts it — the room almost always does."
    }
   ]
  },
  {
   "id": "m10",
   "label": "10 · The Wanting That Has an Age",
   "items": [
    {
     "kind": "Teaching",
     "text": "Some wanting has an age. It arrives from a specific moment, often in childhood, and it has not been updated. The person, in their forties, wants something with the appetite of a nine-year-old. The wanting is real, and the wanting is also slightly younger than the person. It does not fit the current body, or the current life, because it was shaped in a body and a life that are no longer here."
    },
    {
     "kind": "Teaching",
     "text": "The frequency often uses the age of the wanting as evidence that the wanting is invalid. It says: this is childish. It says: you should have grown out of this. The frequency uses the age to disqualify the wanting, and the person, hearing this, does not pursue it."
    },
    {
     "kind": "Anecdote",
     "text": "A man wants, all his life, to be looked after. Not cared for in a partnership sense — looked after, the way a parent looks after a small child. He is ashamed of this. It has never quite made sense to him. In his fifties he realises: the wanting is not about his adult life. It is about a specific period in his childhood when he was not looked after, in a way that was never quite repaired. The wanting has his own age attached. It is a wanting that was never met, and it is still waiting."
    },
    {
     "kind": "Teaching",
     "text": "The wanting with an age is often the wanting that the frequency is most effective at suppressing. The person cannot pursue it because it does not fit. And it does not fit because it was shaped in a time that is not now. The frequency uses this mismatch as proof that the wanting should not be pursued."
    },
    {
     "kind": "Teaching",
     "text": "The reversal is not to pursue the wanting in its original form. It is to see that the wanting is real, that it has an age, and that it can be met — differently, in the present. Not the same as it would have been. But met, now, in a way that the nine-year-old could not have been."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the wanting with an age by the shape of the person's embarrassment. The wanting feels slightly too young for the person. That youth is not evidence against the wanting. It is the shape of the want, and the shape is part of the fact."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one want that feels slightly younger than you, and to let it be a valid want, without requiring it to become adult-sized first. The want has an age. The want is still yours."
    }
   ]
  },
  {
   "id": "m11",
   "label": "11 · The Wanting That Is Finally Held",
   "items": [
    {
     "kind": "Teaching",
     "text": "There comes a moment in the loosening of the desire frequency when the person simply knows what they want. Not always. Not about everything. But in a room, in a specific moment, they want something and they know it and they let the wanting be theirs. The wanting does not require a defence. It simply is."
    },
    {
     "kind": "Teaching",
     "text": "This is the reversal. It is not the ending of the wanting. It is the ending of the review. The wanting continues to arrive as it always did. What has changed is that the wanting is no longer accompanied by a small inspection before it is permitted to be felt."
    },
    {
     "kind": "Anecdote",
     "text": "A woman is in a café with a friend. The friend asks what she would like. The woman answers immediately: the lemon cake. She does not glance at the friend. She does not ask what the friend is having. She does not frame it as a question. She says the lemon cake. It is a small moment. The frequency, which has been running since childhood, is not in the room."
    },
    {
     "kind": "Teaching",
     "text": "The holding is not a technique. It is a state the person drifts in and out of. Some days the frequency returns, and the wanting is reviewed again, and the person notices. Other days the wanting simply arrives and is felt and is theirs. The two states alternate. The person is not trying to be in the first."
    },
    {
     "kind": "Teaching",
     "text": "You will know the frequency is loosening when the person's small answers are true. Coffee, not tea. The window seat. The blue one. Yes, I would like that. The person has not become demanding. They have simply stopped translating their wanting into a version that takes up no room."
    },
    {
     "kind": "Teaching",
     "text": "The wanting that is finally held is not a triumph. It is quiet. It arrives in the middle of ordinary life — the café, the restaurant, the shop, the kitchen. The person does not feel that something has been reclaimed. They simply answer the question and get what they wanted."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to say, once this week, what you actually want, in the first answer, without checking the room first. Not loudly. Not insistently. Just as the truth of your wanting."
    }
   ]
  },
  {
   "id": "m12",
   "label": "12 · Recalibrating",
   "items": [
    {
     "kind": "Teaching",
     "text": "The recalibration of the desire frequency is not the achievement of a person who gets everything they want. It is not the cultivation of selfishness, or the abandonment of generosity, or the arrival at a life of pure self-interest. It is the slow, patient practice of letting the wanting be a fact about the person — without the wanting needing to pass a review before it is permitted to exist."
    },
    {
     "kind": "Teaching",
     "text": "The desire frequency does not disappear. It has been installed early, in a household, in a culture, in a set of assumptions about what wanting is. It will return in the presence of the people who installed it, in the rooms where the original rules were written. What changes is that the person can see the frequency running, and can let the wanting through anyway."
    },
    {
     "kind": "Anecdote",
     "text": "Two people with the same upbringing, the same household, the same small history of wanting being quietly discouraged. One spends her life generous, kind, and slightly absent from her own preferences — giving, always giving, never quite able to answer what she would like. The other, in her thirties, begins to notice her wanting, and to say it, sometimes, in small ways. Thirty years later, they are both kind. They are both generous. One of them is in the room. The other has never quite been."
    },
    {
     "kind": "Teaching",
     "text": "You will know the frequency is shifting when the person's small preferences become real. When coffee is coffee, not either. When the seat chosen is the seat wanted. When the wanting, small and ordinary, arrives without the review."
    },
    {
     "kind": "Teaching",
     "text": "The desire frequency is one of the deepest sectors in this course, because the wanting is not separate from the person. The person who cannot want is the person who has been quietly removed from their own life — present in the room, but not at the centre of it. The reversal is not the arrival of a new appetite. It is the return of a person to their own table."
    },
    {
     "kind": "Teaching",
     "text": "You were not born not wanting. You were taught not to want. The people who taught you were taught the same lesson, by people who were taught it before them, back through a long chain of wanting that was not permitted. The chain can be loosened. Not by wanting loudly, but by noticing, once, that the wanting was never the problem."
    },
    {
     "kind": "Recalibration",
     "text": "The same question. The same small preference. Two different permissions. You have just read an entire sector about the space between them. That space is the whole of this course — and, in desire, it is the space where the person returns to wanting what they want."
    }
   ]
  }
 ]
};
