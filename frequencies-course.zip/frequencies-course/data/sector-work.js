window.FREQ_SECTOR={
 "key": "work",
 "title": "Work",
 "glyph": "✦",
 "blurb": "Unworthiness at the desk, comparison in the corridor, the belief that rest must be earned. And the quiet frequency of someone who knows they belong in the room.",
 "philTitle": "Work · The Fear Frequency & The Reversal",
 "philText": "Work is not the frequency. The fear of not being enough is. This sector is not about productivity — it is about the signal that runs underneath a working life: the belief that you must prove yourself to deserve your place, the constant comparison, the exhaustion that comes not from the work but from the broadcast. It is about the moment work stops being a case for the defence and becomes something a person can simply do.",
 "modules": [
  {
   "id": "m01",
   "label": "1 · The Proving Frequency",
   "items": [
    {
     "kind": "Teaching",
     "text": "Somewhere in many working lives, a shift happens so quietly it is never named. Work stops being what you do, and becomes what you are proving. The day's labour is no longer the point. The point is the case you are building, quietly, in every room you enter."
    },
    {
     "kind": "Teaching",
     "text": "The proving frequency is not ambition. Ambition wants to build something. Proving wants to be enough. Ambition moves toward a goal. Proving moves away from a verdict. From the inside, they feel similar. From the outside, they produce very different lives."
    },
    {
     "kind": "Anecdote",
     "text": "A man delivers a strong presentation to his team. It is well received. On the walk home he is quiet, going over the two sentences he could have said better. His colleague, who presented worse, feels pleased with her day. The difference was not the performance. It was what each of them was carrying underneath it."
    },
    {
     "kind": "Teaching",
     "text": "The proving frequency believes there is a test being run. That somewhere, unseen, someone is keeping a record. That today's work is the latest entry, and that the verdict is still pending. The person running the frequency never feels secure, because the verdict never arrives."
    },
    {
     "kind": "Teaching",
     "text": "The proving frequency is one of the most productive forces in a working life. It gets things done. It arrives early. It stays late. That is exactly why it is so hard to notice — the person running it looks, from the outside, like someone who is committed. Only they know how tired they are."
    },
    {
     "kind": "Recalibration",
     "text": "Notice one moment today when you finished something and immediately looked outward for a verdict. A message, a word, a small signal of approval. You do not need to change the seeking. You only need to notice that the seeking was there."
    }
   ]
  },
  {
   "id": "m02",
   "label": "2 · Where the Proving Begins",
   "items": [
    {
     "kind": "Teaching",
     "text": "Nobody is born proving themselves. The proving frequency is installed — usually early, usually by someone whose own frequency was already running the proof. A parent who was never quite satisfied, a school that ranked, a culture that made belonging conditional on achievement."
    },
    {
     "kind": "Teaching",
     "text": "The child does not learn that they must prove themselves. The child learns that they are being evaluated. The evaluation is quiet, constant, and it feels like a fact about the world. The adult who emerges from that childhood continues the evaluation on their own behalf, long after the original evaluator has gone."
    },
    {
     "kind": "Anecdote",
     "text": "A woman remembers being five and putting her painting on the fridge. Her mother said it was beautiful, and then reached for the blue to fix a corner. She is forty-one. She still cannot finish a piece of work without imagining someone reaching for the blue."
    },
    {
     "kind": "Teaching",
     "text": "The proving frequency is often inherited from a parent who was also proving. The parent is not cruel. The parent is transmitting a frequency they do not know they are carrying. The child receives it the way they receive language — as the shape of the world."
    },
    {
     "kind": "Teaching",
     "text": "Some frequencies are installed by praise. A child praised only for outcomes, never for presence, learns that outcomes are the only currency. Their later life is one long attempt to keep the praise flowing, and to survive the silence when it stops."
    },
    {
     "kind": "Teaching",
     "text": "This matters because it means the proving frequency is not a personal defect. It is an installation. The person running it did not choose it. They received it, from someone who received it, from someone who received it. The chain is old and the chain is quiet."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal begins with a single sentence, spoken to yourself: 'this was given to me.' Not to blame the giver. Just to see the proof as a transmission rather than the truth about you."
    }
   ]
  },
  {
   "id": "m03",
   "label": "3 · The Comparison Machine",
   "items": [
    {
     "kind": "Teaching",
     "text": "The proving frequency runs on comparison. It cannot measure itself directly, so it measures against others. The colleague who got the promotion. The school friend who is doing better. The stranger on a screen who seems to have arrived."
    },
    {
     "kind": "Teaching",
     "text": "Comparison is not a character flaw. It is how the frequency gathers evidence. It needs a reference point to know whether the proof is holding. The comparison never settles, because there is always someone further up the slope — and the frequency will always find them."
    },
    {
     "kind": "Anecdote",
     "text": "Two people in the same company, same salary, same role. One is content. The other is quietly tormented. Nothing about their work explains the difference. What explains it is that the second one has begun measuring himself against someone three levels above, and treats the gap as a personal failing."
    },
    {
     "kind": "Teaching",
     "text": "The comparison machine gets more efficient with time. In early careers it compares to people nearby. In later careers it has a much larger pool — everyone you ever met, everyone you ever read about, everyone the algorithms decide to show you. The pool grows. The gap grows with it."
    },
    {
     "kind": "Teaching",
     "text": "One of the quiet cruelties of the frequency is that comparison often runs hardest against the people closest to you. A stranger's success can be enjoyed. A friend's success can be complicated. This is not a moral failure — it is the frequency processing evidence."
    },
    {
     "kind": "Teaching",
     "text": "The comparison machine is sometimes called motivation. It is not. Motivation moves toward something. Comparison moves away from the sense of being less. The two are structurally different, and the energy of the second runs out in a different way — colder, more exhausted, and usually alone."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is not to stop noticing others. It is to notice what the noticing does to you. Some comparison expands. Some contracts. Learning the difference is the whole of this module."
    }
   ]
  },
  {
   "id": "m04",
   "label": "4 · The Exhaustion That Isn’t From the Work",
   "items": [
    {
     "kind": "Teaching",
     "text": "People running the proving frequency are often tired in a way that sleep does not fix. They can rest for a weekend and come back with the same weight. The tiredness is not in the body. The tiredness is in the ongoing act of holding the broadcast."
    },
    {
     "kind": "Teaching",
     "text": "Holding the broadcast takes energy. Every room entered requires a small recalculation of how to be seen. Every conversation is a small production. Every silence is a small question about whether the last performance landed. The body carries all of this, all day, without the person having chosen to pick it up."
    },
    {
     "kind": "Anecdote",
     "text": "A man takes a two-week holiday. He returns to work on a Monday and by Wednesday is as tired as he was before he left. Nothing has happened. Nothing needs to have. The frequency was on holiday with him."
    },
    {
     "kind": "Teaching",
     "text": "This is the exhaustion people mistake for burnout. Real burnout is usually the body saying no to something. The proving exhaustion is the frequency saying yes to everything, in order to keep the case alive. The two can look identical from the outside. From the inside, they are very different."
    },
    {
     "kind": "Teaching",
     "text": "The exhaustion is not proportionate to the work. Two people with the same workload can be at completely different levels of depletion. The difference is not willpower. It is the broadcast that accompanies the work."
    },
    {
     "kind": "Teaching",
     "text": "The body pays the invoice for the frequency long before the career does. Sleep, digestion, patience, appetite, the ability to enjoy small things. None of these are on a CV. All of them are the true ledger."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is not to work less. It is to notice the moments you are holding the broadcast, and to let one of them go. Not all of them. Just one. The body will register the difference before the mind does."
    }
   ]
  },
  {
   "id": "m05",
   "label": "5 · The Promotion That Doesn’t Settle It",
   "items": [
    {
     "kind": "Teaching",
     "text": "The proving frequency believes that the next milestone will finally conclude the case. The promotion, the title, the raise, the project, the recognition. It promises, in advance, that the milestone will be enough. It has never yet been enough, and it will not start being enough now."
    },
    {
     "kind": "Teaching",
     "text": "This is one of the frequency's clearest signatures: it moves the goalpost as you approach it. Not maliciously. Structurally. The frequency does not want a verdict. It wants a case that is always ongoing. A verdict would end it."
    },
    {
     "kind": "Anecdote",
     "text": "A woman is promoted to the role she spent four years aiming for. For a week she is light. Then the frequency finds a new reference point, higher up, and within a month she is quietly as anxious as she was before. The promotion changed the evidence. It did not change the case."
    },
    {
     "kind": "Teaching",
     "text": "People running the frequency often believe that they are simply ambitious. They are not. Ambition has a horizon. The proving frequency has none, because the goal is not to arrive — the goal is to keep proving, because proving is the safest thing the frequency knows how to do."
    },
    {
     "kind": "Teaching",
     "text": "The people who do not have the frequency are often less outwardly impressive in the early years and more settled in the later ones. They build, they rest, they build again. The person running the frequency often produces spectacular early results and pays a long, quiet bill in the middle of their life."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to ask honestly: what would be enough? Not as a challenge. As a real question. Most people running the frequency have never answered it. When you try, you will notice that you cannot — and that noticing is the door."
    }
   ]
  },
  {
   "id": "m06",
   "label": "6 · When Rest Feels Like Failure",
   "items": [
    {
     "kind": "Teaching",
     "text": "The proving frequency does not allow real rest. Not because it is cruel, but because rest is where the case is quiet. In activity, the frequency has evidence to gather. In rest, it has only itself — and itself is not a comfortable thing to sit with."
    },
    {
     "kind": "Teaching",
     "text": "This is why so many high-functioning people report feeling worse on holiday than at work. Nothing is wrong. The frequency is simply being given space. And a frequency that has been running all year does not stop when the calendar says it can."
    },
    {
     "kind": "Anecdote",
     "text": "A man cannot enjoy a Saturday. He sits with his family, physically present, mentally reviewing the week. By Sunday evening he is defeated and cannot say why. He has not rested. He has rehearsed."
    },
    {
     "kind": "Teaching",
     "text": "The proving frequency often converts rest into preparation. A walk becomes a chance to think through a meeting. A bath becomes a planning session. Reading becomes research. The body is still, but the frequency is working, and the person who wanted rest does not receive it."
    },
    {
     "kind": "Teaching",
     "text": "Real rest is not the absence of activity. It is the absence of the broadcast. Two people can sit quietly in the same room and only one of them is resting. The other is holding the case."
    },
    {
     "kind": "Teaching",
     "text": "Learning to rest is often the very first work of reversing the frequency — before any productivity changes, before any career decision. The body needs to know that rest is safe. Until it does, none of the other work will hold."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal begins with one real rest. Not earned, not productive, not in service of tomorrow. Just rest. The frequency will protest. Let it. The body is already learning that it can."
    }
   ]
  },
  {
   "id": "m07",
   "label": "7 · The Colleague as a Mirror",
   "items": [
    {
     "kind": "Teaching",
     "text": "Work is a room full of frequencies, and the proving frequency is unusually sensitive to them. Every colleague becomes a mirror, and the frequency reads itself against each one. The confident colleague, the relaxed colleague, the one who does not seem to need the approval — each of them shows the proving frequency something it cannot look at directly."
    },
    {
     "kind": "Teaching",
     "text": "This is why some people running the frequency find certain colleagues unbearable. The unbearable colleague is usually someone who is not running the case — or is running it at a much lower volume. Their ease feels like an accusation. The frequency reads it as one."
    },
    {
     "kind": "Anecdote",
     "text": "A man cannot stand a particular colleague for years and never works out why. She is competent, kind, easy to be around. Only at the end of a long period of reflection does he realise she reminded him of something he was not — someone who did not need to prove. Her presence was the mirror the case could not bear."
    },
    {
     "kind": "Teaching",
     "text": "The colleague who irritates the frequency most is often carrying the exact quality the frequency most wants and cannot have. This is not a coincidence. It is the mirror's job. The frequency resists because the reflection is uncomfortable, not because the reflection is wrong."
    },
    {
     "kind": "Teaching",
     "text": "The proving frequency usually plays out across a team. Two people running it in the same team push each other higher. One person running it, and another not, creates tension the person running it cannot name. The team becomes a study in frequencies that no one is looking at."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice which colleague gives you the strongest reaction, and to ask, honestly, what quality they are carrying that the frequency cannot."
    }
   ]
  },
  {
   "id": "m08",
   "label": "8 · The Room That Never Relaxes",
   "items": [
    {
     "kind": "Teaching",
     "text": "There is a room inside a person that never quite relaxes when the proving frequency is running. Not a physical room — a state. It is the small, continuous vigilance that sits behind even the good days. It is the reason a person can win an award and still, at some point that evening, feel unsure."
    },
    {
     "kind": "Teaching",
     "text": "This inner room is the reason so many successful people describe their own success as fragile. They are not being modest. They are being accurate. The inner room has not changed, and the frequency does not let them forget it."
    },
    {
     "kind": "Anecdote",
     "text": "A woman gives a speech that moves a room of three hundred people to tears. She leaves the stage, and by the time she reaches the car park she is thinking about the one sentence she could have delivered better. Nothing has gone wrong. The room is doing exactly what it does."
    },
    {
     "kind": "Teaching",
     "text": "The inner room is often harder to describe than the frequency itself, because there is no external event that produces it. It is simply there. A quiet background hum — not quite anxiety, not quite vigilance, something in between. The person who has never lived without it does not know it has a name."
    },
    {
     "kind": "Teaching",
     "text": "You can tell the inner room has softened when you notice something without immediately evaluating it. A good day. A warm conversation. A piece of work you enjoyed making. The softening is not the absence of a verdict. It is the absence of a required one."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is not to relax the room by force. It is to notice it. Every time you catch the hum, you have already stepped outside it, at least by a centimetre. That centimetre is the whole of the work."
    }
   ]
  },
  {
   "id": "m09",
   "label": "9 · Work That Feels Like Yours",
   "items": [
    {
     "kind": "Teaching",
     "text": "When the proving frequency steps back, something unexpected happens to work itself. It becomes available again. Not easier — available. There is suddenly a version of the day that is not a case, a version of the project that is not a performance, a version of the career that is simply what the person is doing with their time."
    },
    {
     "kind": "Teaching",
     "text": "People who have made this shift often describe the same thing: work became quieter and, quietly, better. Not because the person worked less or harder, but because the frequency stopped spending its energy on the case and left the energy available for the work."
    },
    {
     "kind": "Anecdote",
     "text": "A man spends fifteen years building an impressive career he did not want. He makes a change — smaller role, better life. His first three months are uncomfortable, and then, for the first time he can remember, he starts enjoying Monday mornings. Nothing changed except the frequency in which Monday morning was being experienced."
    },
    {
     "kind": "Teaching",
     "text": "Work that feels like yours is not a particular career, or a particular role, or a particular industry. It is a particular frequency in which work is done. Two architects, two doctors, two cleaners — one is running the case, and one is not. You can usually tell which is which within minutes of meeting them."
    },
    {
     "kind": "Teaching",
     "text": "The frequency wants to make this about career choice. It does not want to make it about the broadcast. The frequency would rather you change jobs ten times than change the broadcast once."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one small thing about your work today that you actually enjoyed, that the frequency does not usually acknowledge. Not a milestone. A moment. The frequency will want to dismiss it. Let it be there anyway."
    }
   ]
  },
  {
   "id": "m10",
   "label": "10 · Saying No",
   "items": [
    {
     "kind": "Teaching",
     "text": "One of the proving frequency's most reliable tell-tales is the inability to say no. Not because the person is too weak — because the frequency believes every yes is a new piece of evidence. Every no is a risk. The case cannot afford risks."
    },
    {
     "kind": "Teaching",
     "text": "The proving frequency says yes to the extra project, the late call, the task that is not theirs, the invitation they do not want. The yes arrives before the thinking does. From the inside, it does not feel like a choice. It feels like the only thing that could be done."
    },
    {
     "kind": "Anecdote",
     "text": "A woman begins practising saying no to one small request a week. The first week feels unbearable. The second week, uncomfortable. By the third month, she has begun to notice something unexpected: the people around her trust her more. Not less."
    },
    {
     "kind": "Teaching",
     "text": "The proving frequency predicts that saying no will cost the person relationships, opportunities, standing. The prediction is almost always wrong. What actually costs relationships is the quiet resentment of the yes that was never really meant."
    },
    {
     "kind": "Teaching",
     "text": "The first no is the whole exercise. It does not need to be a good no — it can be clumsy, brief, unexplained. The frequency will spend hours afterwards building the case against it. Let it. The no has been said. Something has already changed."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is one no. Not a policy. Not a lifestyle. One. Choose something small, this week, and let the no stand, even as the frequency writes its defence."
    }
   ]
  },
  {
   "id": "m11",
   "label": "11 · Recognising the Frequency",
   "items": [
    {
     "kind": "Teaching",
     "text": "The proving frequency has a signature. A slight lean-in before you answer a question. A rehearsed pause before you take credit. A quiet check of the room after you have said something you are not sure landed. That is the frequency in miniature, and it happens hundreds of times a day."
    },
    {
     "kind": "Teaching",
     "text": "Learn to hear the signature. Not to change it — not yet. Just to hear it. The person who can hear the frequency has already stopped being run by it, because they are no longer inside it looking out. They are outside it, listening in."
    },
    {
     "kind": "Anecdote",
     "text": "A man begins noticing that every time he walks into a meeting room he checks where the senior people are sitting, and arranges himself relative to them. He has done this for twenty years. He thought it was professionalism. It was the frequency, taking his temperature."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is loudest in the moments you are most proud, and in the moments you are most threatened. Both produce the same underlying reflex — the quick scan outward for the verdict. Recognising the scan is the whole of module eleven."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency most clearly in the moments after a win. If the win does not settle you, if within an hour you are already thinking about the next thing, if a good morning is followed by a slightly heavy afternoon — that is the frequency. Wins do not change it. Only seeing it does."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is a small pause on the tell. Not to stop it. Not to fix it. Just to see it. In that pause, the frequency has already lost some of its invisibility. The rest follows."
    }
   ]
  },
  {
   "id": "m12",
   "label": "12 · Recalibrating",
   "items": [
    {
     "kind": "Teaching",
     "text": "The recalibration of the work frequency is not a career move. It is not a sabbatical, a reboot, a fresh start, or the perfect role. It is the slow, patient practice of noticing the case each time you open it, and letting it stay closed a little longer than before."
    },
    {
     "kind": "Teaching",
     "text": "The reversal does not feel like victory. It feels like a working life, without the sound of a court in the background. The person who has stepped out of the frequency does not feel confident. They feel unremarkable — in the best sense. They simply do their work and go home."
    },
    {
     "kind": "Anecdote",
     "text": "Two colleagues, same output, same years, same seniority. One is exhausted and successful. The other is not exhausted and, by most measures, just as successful. The difference is not the work. The difference is the broadcast that has been running underneath it."
    },
    {
     "kind": "Teaching",
     "text": "You will know the frequency is shifting when a Monday no longer feels like an opening statement in a long trial. When a good piece of work does not require an audience. When a slow day does not become a personal report card. When the room you carry around inside you has stopped keeping score."
    },
    {
     "kind": "Teaching",
     "text": "The work frequency is one of the deepest in modern life. It was installed by schools, by parents, by a culture that made productivity the price of belonging. It will not leave on request. But it can be recognised, and once recognised, it stops running the working day from the shadows."
    },
    {
     "kind": "Teaching",
     "text": "You were not born with a verdict pending over your head. Someone, somewhere, decided there was one. The person who decided was also told there was one, by someone who was told the same. The chain is old. It does not have to be yours to keep."
    },
    {
     "kind": "Recalibration",
     "text": "The same work. The same day. Two different broadcasts. You have just read an entire sector about the space between them. That space is the whole of this course — and, in work, it is the space where the case finally closes and something else can begin."
    }
   ]
  }
 ]
};
