window.FREQ_SECTOR={
 "key": "voice",
 "title": "Voice",
 "glyph": "◉",
 "blurb": "Being heard, being silenced, the fear of speaking up. How the frequency of \"not my place\" keeps a person quiet for decades — and the shift that changes everything.",
 "philTitle": "Voice · The Fear Frequency & The Reversal",
 "philText": "The voice is not the sound. The voice is the signal a person sends when they say what they actually think, want, feel, or know. This sector is not about public speaking — it is about the frequency that arrives when your voice is about to be heard, and the quieter frequency that arrives when it has been silenced. It is about the moment you stop translating yourself into something smaller than what you mean.",
 "modules": [
  {
   "id": "m01",
   "label": "1 · The Signal You Learned to Mute",
   "items": [
    {
     "kind": "Teaching",
     "text": "Every person is born with a signal. A voice — not a literal sound, but the impulse to say what is actually true for them. A child of two or three has this completely. They say what they see, what they want, what is funny, what is wrong. There is no gap between the inner signal and the outward broadcast."
    },
    {
     "kind": "Teaching",
     "text": "Somewhere in the growing up, the gap appears. The signal is still there — it always is. But a filter arrives between the signal and the sentence. The signal is measured before it is spoken. Sometimes it is edited. Sometimes it is withdrawn. Sometimes it is translated into something safer."
    },
    {
     "kind": "Anecdote",
     "text": "A woman remembers, at eight, saying something at the dinner table that made the room go quiet. She was not being rude. She had simply said what she noticed. She never quite worked out what she had done wrong. From that day she began to check, before she spoke, whether what she was about to say would make the room go quiet. She is forty-two. She still checks."
    },
    {
     "kind": "Teaching",
     "text": "The mute is often installed in a single moment. A laugh in the wrong place. A look from a parent. A teacher's sharp reply. The child receives the signal that this particular voice — this particular honesty — is not wanted here. And the child complies. Not consciously. The nervous system does it for them."
    },
    {
     "kind": "Teaching",
     "text": "The mute is not the same as shyness. Shyness is a temperament. The mute is an instruction — a specific set of frequencies that were installed and that now run underneath the voice, deciding, hundreds of times a day, whether to speak. The mute is what happens when the signal meets the filter and the filter wins."
    },
    {
     "kind": "Teaching",
     "text": "Most people running the mute believe they are being tactful, or professional, or considerate. They are not. They are being supervised by an old frequency. The tact is real. The instinct behind it is not tact — it is the avoidance of an old consequence."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal begins with a small noticing: how often does the sentence that was about to be said not get said? You do not have to say it yet. You only have to notice the moment the filter is deciding for you."
    }
   ]
  },
  {
   "id": "m02",
   "label": "2 · Where the Silence Was Taught",
   "items": [
    {
     "kind": "Teaching",
     "text": "The voice frequency is unusual among the sectors, because it is almost always installed by a specific moment or a specific message. Not a slow transmission, like belief. Not a family climate, like Family. A moment. Sometimes a single one. The message arrives, the signal registers it, and the mute begins."
    },
    {
     "kind": "Teaching",
     "text": "The message can arrive in many forms. It can be a shouted instruction — 'don't talk back'. It can be a quiet one — 'not now, darling'. It can be a look. It can be an absence — no one ever asked what the child thought, and the child drew the natural conclusion."
    },
    {
     "kind": "Anecdote",
     "text": "A man grows up in a family where the eldest sibling speaks and everyone else is quiet. He becomes a listener — a good one, respected for it. But somewhere in his twenties, in a meeting where he had something important to say, he noticed that his body would not let him speak. The frequency had been installed not by anyone telling him to be quiet, but by no one ever turning to him and asking."
    },
    {
     "kind": "Teaching",
     "text": "The voice frequency is not always installed by cruelty. It is often installed by love, or exhaustion, or habit. A parent who was themselves silenced, who passes it on without knowing. A culture that gives certain voices more room than others. The transmitter does not have to be at fault for the transmission to be real."
    },
    {
     "kind": "Teaching",
     "text": "The most difficult installers to see are the ones who were loving. A parent who said 'not now, sweetheart' every single time, kindly, for years — that parent was loving. The message was still received. The signal still registered that its timing was always wrong."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the original installation by the shape of the discomfort that arrives when you are about to speak. If the discomfort feels like danger, the installation was harsh. If the discomfort feels like being a nuisance, the installation was gentle but consistent. Both are the same frequency. Both are running."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is not to blame the installer. It is to see them. When you know who taught you to be quiet, you have already half-stopped being taught."
    }
   ]
  },
  {
   "id": "m03",
   "label": "3 · The Translation You Do Before Speaking",
   "items": [
    {
     "kind": "Teaching",
     "text": "The voice frequency does not usually silence a person completely. That would be too visible. What it does instead is more sophisticated: it translates. The person speaks, but always through a filter. What they said is a version of what they meant — softer, safer, more agreeable, and slightly less true."
    },
    {
     "kind": "Teaching",
     "text": "The translation is not lying. It is softening. The sentence is delivered as a question when it should be a statement. A strong opinion is offered as a light one. A difficult truth is wrapped in three caveats. The person has said something. They have not said what they meant."
    },
    {
     "kind": "Anecdote",
     "text": "A woman is asked for her honest opinion on a proposal at work. She has a serious concern. What she says is: 'I think it's really interesting, though I wonder if we might just consider...'. She has said the concern. She has also made it sound optional, and the proposal moves forward. The translation was skilful. It was also a small defeat."
    },
    {
     "kind": "Teaching",
     "text": "The translation is often invisible to the person doing it. From the inside, it does not feel like editing. It feels like being thoughtful. The person does not experience themselves as unable to say what they think. They experience themselves as someone who prefers to be diplomatic."
    },
    {
     "kind": "Teaching",
     "text": "The translation has real costs. It costs the person's actual opinion. It costs the room's ability to benefit from it. And, over years, it costs the person's own sense of what they actually think — because when you translate everything, you lose track of the untranslated version."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the translation by the small lag before you speak. Not a thinking lag — a converting lag. The thought is already complete. The lag is the translation passing through the filter before it is released."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to say one sentence today without the translation. Not a rude sentence — just an untranslated one. Say what you mean, once, in a small moment. That single act is the whole work of module three."
    }
   ]
  },
  {
   "id": "m04",
   "label": "4 · Being Heard Without Being Asked To Be",
   "items": [
    {
     "kind": "Teaching",
     "text": "Some people in a room are heard without effort. They speak, and the room turns. Others speak and the room continues. This is not about volume. It is about whether the room has already decided, before the sentence begins, that this voice is worth listening to."
    },
    {
     "kind": "Teaching",
     "text": "The voice frequency, when running, tells the person that they are in the second category. And, crucially, the person behaves accordingly. They hesitate slightly. They look at the room before they speak. They ask for permission with their tone. The room reads this and treats the voice as expected."
    },
    {
     "kind": "Anecdote",
     "text": "A woman is in a meeting with five men and two women. She notices that when one of the men starts to speak, the others stop. When she starts to speak, they do not. She is not being ignored. She is being spoken over. There is a difference. She begins to experiment — speaking slightly louder, slightly later, without asking permission with her tone. The room reads the change before she has decided what it means."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is a two-way loop. The person broadcasts 'my voice may not be important'. The room receives the broadcast. The room responds accordingly. The person receives the response and confirms that their original broadcast was correct. The loop is complete, and it can run for decades without anyone noticing."
    },
    {
     "kind": "Teaching",
     "text": "This is one of the reasons the voice frequency is so hard to shift on your own. The loop involves other people, and the other people are responding to the broadcast, not to the person. Change the broadcast, and the responses change. It takes time, and it takes repetition, but it can be done."
    },
    {
     "kind": "Teaching",
     "text": "You will notice the loop most clearly in the moments you say something worth hearing and it is not heard. Not because the room disagreed — because the room did not fully register it. The sentence entered, was polite, and left. That disappearance is the frequency."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is not to become louder. It is to stop asking permission with your tone. Say one thing today without the slight leaning-in, without the small apologetic rise at the end. Say it as if you expected it to be heard. You do not need to believe this yet. You only need to do it once."
    }
   ]
  },
  {
   "id": "m05",
   "label": "5 · The Voice That Is Silent With Certain People",
   "items": [
    {
     "kind": "Teaching",
     "text": "The voice frequency is not uniform. It moves. It is present with some people and absent with others. There are rooms where the person speaks easily and rooms where they go quiet. There are people with whom they are talkative, and people with whom they become someone else entirely."
    },
    {
     "kind": "Teaching",
     "text": "This variation is one of the clearest windows into the frequency. If the frequency were a fixed personality trait, it would be consistent everywhere. But because it is a frequency, it responds to the frequencies around it. The mute is not universal. It is specific."
    },
    {
     "kind": "Anecdote",
     "text": "A man is confident at work and quiet in his extended family. Same person. Same voice. Different room. He is not aware of making a choice to be quiet in one and confident in the other. But with his family, he becomes, in the space of a few minutes, a version of himself that his colleagues would not recognise."
    },
    {
     "kind": "Teaching",
     "text": "You can find the origin of the voice frequency by looking at the people in front of whom the voice disappears. The frequency was often installed by someone with the same qualities as those people. A sharp uncle. A dismissive teacher. A family member whose tone did not permit contradiction."
    },
    {
     "kind": "Teaching",
     "text": "The voice frequency also shows up around the people who are supposed to be closest to the person. Partners, parents, siblings. The rooms where the person should be most at ease are often the rooms where the mute is strongest. This is not a coincidence. Closeness installs its own frequencies."
    },
    {
     "kind": "Teaching",
     "text": "Sometimes the person has been avoiding this for years — has built a life of confident voice in every other context, and quietly cannot speak in one specific place. This is one of the most costly parts of the voice frequency. The person does not need to be silent anywhere. But they are, in the one place they most want to be heard."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal begins with a map. Write down the places and people with whom the voice disappears. You do not need to say anything yet. The map alone will tell you more than any thought about the frequency ever could."
    }
   ]
  },
  {
   "id": "m06",
   "label": "6 · When Silence Was the Only Safe Option",
   "items": [
    {
     "kind": "Teaching",
     "text": "In some lives, the voice frequency was not installed by tone or habit. It was installed by danger. The child learned, correctly, that speaking could lead to consequences. The consequence might have been a slap, a shouting, an hours-long silence, a parental withdrawal of love. Whatever it was, the child's nervous system recorded the same instruction: speaking is not safe here."
    },
    {
     "kind": "Teaching",
     "text": "This module is not a metaphor. It is a real thing that happened to real children, in real homes, in every country, in every class. The voice frequency is one of the deepest and most justified of all the frequencies in this course, because the person who received it was not confused. They were correct."
    },
    {
     "kind": "Anecdote",
     "text": "A man, in his late fifties, is asked why he never disagrees with anyone. He says he does not know. Later, in a private moment, he remembers that his father used to go completely silent for days when contradicted. The silence was worse than shouting. He learned, as a small child, to never contradict his father. He is still doing it. His father has been dead for twenty years."
    },
    {
     "kind": "Teaching",
     "text": "This is the hardest of the voice frequencies to work with, because it was correct. The child was not being foolish. The child was being adaptive. To speak would have been dangerous, and the mute kept the child safe. The mute deserves respect. It was, at the time, wise."
    },
    {
     "kind": "Teaching",
     "text": "The work is not to blame the mute for still being present. The work is to notice that the conditions have changed, and that the mute is no longer saving the person from anything. In most cases, they are now safe. In some, they are not. The difference matters enormously, and it is not the same for everyone."
    },
    {
     "kind": "Teaching",
     "text": "For those who are genuinely no longer in danger, the frequency can soften with time and conscious work. For those who are still in an unsafe situation, the mute may still be necessary, and the whole of this sector may not apply until safety arrives. This is not a weakness. It is a fact about safety and about the body's honest assessment of it."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal here is slow and careful. If you are safe, notice one small moment where the old danger is not actually present, and let one quiet sentence out. Not more. Just one. The voice frequency changes by small steps, and each step is significant."
    }
   ]
  },
  {
   "id": "m07",
   "label": "7 · The Voice That Surprises You",
   "items": [
    {
     "kind": "Teaching",
     "text": "There comes a moment in the softening of the voice frequency when the person hears something unexpected come out of themselves. A sentence that was not planned. A disagreement that arrived before the translation. A piece of honesty that the person did not know they were carrying."
    },
    {
     "kind": "Teaching",
     "text": "This is not a technique. It is a signal. The original voice, unedited, arriving through the filter before the filter has had time to be polite. It is often surprising, sometimes embarrassing, occasionally life-changing."
    },
    {
     "kind": "Anecdote",
     "text": "A woman is in a meeting where a decision is being made that she disagrees with. She has been quiet for years in this room. And then she hears herself say, plainly, without heat: 'I don't think that's the right call, and here's why.' She does not remember deciding to say it. The room falls quiet. The decision is reconsidered. She spends the rest of the day in a strange state — not triumph. Surprise."
    },
    {
     "kind": "Teaching",
     "text": "The voice, once it has been heard, is not always welcomed by the person who said it. Often there is a wave of guilt, or anxiety, or a wish to take it back. This is the frequency responding to the disruption of its own quiet. The guilt is not a sign that the person said something wrong. It is a sign that the frequency noticed."
    },
    {
     "kind": "Teaching",
     "text": "These moments tend to arrive when the person is tired, or in a moment of unusual safety, or in a conversation where the stakes are unexpectedly low. The frequency is bypassed for a second. What comes out is what the person actually thinks — and often what they had forgotten they thought."
    },
    {
     "kind": "Teaching",
     "text": "The voice that surprises you is one of the most valuable signals in the whole sector. It tells you that the original signal is still alive underneath. It has not been erased. It has only been muted. The mute can be released. The voice has been waiting."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to not apologise for the surprising sentence. It is to sit with it, and notice that it landed — that the room did not collapse, and that the person is still here. The voice survived being heard. The frequency's prediction was wrong."
    }
   ]
  },
  {
   "id": "m08",
   "label": "8 · When Someone Else’s Voice Is Being Silenced",
   "items": [
    {
     "kind": "Teaching",
     "text": "Once a person begins to see their own voice frequency, they almost always begin to see it in others. The colleague who never speaks in meetings. The friend who agrees with everything. The child who goes quiet when a certain person enters the room. The frequency becomes visible everywhere, once you have seen it in yourself."
    },
    {
     "kind": "Teaching",
     "text": "This creates a specific challenge. What is the correct response when you see someone running the frequency you have just spent a lifetime recognising? The instinct is often to help — to encourage, to invite, to make space. The instinct is kind. It is not always useful."
    },
    {
     "kind": "Anecdote",
     "text": "A woman spends years gently encouraging a quieter colleague to speak in meetings. She sees the mute clearly. She makes space. She asks direct questions. It takes her a long time to realise that her encouragement is not landing — because the colleague does not need an invitation. She needs someone who will not make an event of her speaking when she does."
    },
    {
     "kind": "Teaching",
     "text": "The voice frequency does not respond well to being made visible by others. The person running it is often already aware that they are quiet. Making that visible — even kindly — adds a new pressure on top of the existing one. The voice is now asked to arrive on cue."
    },
    {
     "kind": "Teaching",
     "text": "What helps is not the invitation, but the absence of the frequency that installed the mute. A room where the person is not treated as expected to be quiet. A group where another person disagrees without consequence. A moment where the person is answered at normal volume, treated as an ordinary participant, not as a guest who has been invited to try."
    },
    {
     "kind": "Teaching",
     "text": "You cannot uninstall someone else's mute. You can only stop reinforcing it. This is quiet work. It does not show up on any scorecard. But it is one of the truest forms of help available, and it is the shape that the voice frequency, at its most developed, tends to take."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal, in this module, is not for you — it is for someone else. Notice one person running the voice frequency today, and offer the one thing that costs nothing: treat their next sentence as completely ordinary."
    }
   ]
  },
  {
   "id": "m09",
   "label": "9 · The Voice in the Room You Do Not Speak",
   "items": [
    {
     "kind": "Teaching",
     "text": "Most people have one room in their life where the voice frequency is strongest. It is usually not the room you would guess. Not the boardroom. Not the stage. It is the room where the person is most known, or most expected, or most obligated. Often, it is family."
    },
    {
     "kind": "Teaching",
     "text": "The voice in that room is doing the whole of the frequency's work. It is running the original installation, the original translation, the original mute. Everything the person has unlearned elsewhere is still present there, at full strength."
    },
    {
     "kind": "Anecdote",
     "text": "A woman is direct and unafraid in her professional life. She has left one marriage for reasons she could explain clearly. She has, in the last decade, learned to say difficult things to friends. But when she is in the room with her mother, she becomes silent, agreeable, and always slightly behind the moment. She notices this now. She cannot yet change it."
    },
    {
     "kind": "Teaching",
     "text": "The room you do not speak in is a diagnostic. It is where the frequency lives, still intact, after all the other work. It is also, usually, the last room to shift. The person often finds that they can speak everywhere else before they can speak here, and that the difference is not about skill or courage — it is about which frequency is being received."
    },
    {
     "kind": "Teaching",
     "text": "You will know you are in this room by the specific texture of your silence. It is not the silence of thinking. It is the silence of standing in an older version of yourself. You are still here, still the age you were when the frequency was installed."
    },
    {
     "kind": "Teaching",
     "text": "The voice in this room can change, but rarely quickly. It requires the person to notice the older version of themselves in the moment of its arrival, and to stay present through the discomfort. Sometimes the shift is one sentence. Sometimes it takes a decade. Both are real shifts, and both matter."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal begins with one sentence, said quietly, in the room that has never heard you. Not a big sentence. Not the confrontation of the century. One ordinary sentence delivered as if it were ordinary. That is the beginning."
    }
   ]
  },
  {
   "id": "m10",
   "label": "10 · The Voice That Says What You Used to Think",
   "items": [
    {
     "kind": "Teaching",
     "text": "The voice frequency, once loosened, often leaves behind a residue of old opinions. A person who has spent years translating will sometimes notice that even when they speak freely, they speak in a slightly older voice. The sentences are not translations, but they are also not quite current. They are the residue of years of filtering."
    },
    {
     "kind": "Teaching",
     "text": "This is most visible in opinions. Old political views. Old social habits. Old jokes. Old tolerances. The person's opinions have changed in private — but their public voice still delivers the older positions, because those were the ones the frequency permitted."
    },
    {
     "kind": "Anecdote",
     "text": "A man in his forties has spent the last decade quietly revising his views on several subjects. In conversation with his old friends, he still expresses the old views — not because he holds them, but because speaking them costs nothing, and speaking the new ones would require an awkward change of subject. His voice is now lagging behind his thinking by about ten years."
    },
    {
     "kind": "Teaching",
     "text": "The voice frequency does not only silence. It also preserves. It preserves what was said before, because speaking what is currently believed would have required a risk that the frequency was not willing to take."
    },
    {
     "kind": "Teaching",
     "text": "This creates a strange discomfort for the person themselves. They hear themselves say something they no longer believe. They notice it as they are saying it. They do not stop — the sentence is already in the air — but they notice."
    },
    {
     "kind": "Teaching",
     "text": "The voice that says what you used to think is a sign of progress. It means the thinking has already moved, and only the delivery is behind. The delivery will catch up, but only if the person is willing to say the new thing out loud, even once, in a room where the old thing was expected."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one moment today where the voice delivered an older version of yourself. You do not have to correct it. You only have to notice that it is not quite what you currently think."
    }
   ]
  },
  {
   "id": "m11",
   "label": "11 · Recognising the Mute",
   "items": [
    {
     "kind": "Teaching",
     "text": "The voice frequency has a signature. A small delay before the answer. A slightly quieter tone at the end of a sentence. A quick glance at the room after saying something you are not sure about. That is the frequency in miniature, and it happens dozens of times a day."
    },
    {
     "kind": "Teaching",
     "text": "Learn the signature. Learn the moment the sentence was about to arrive and instead did not. The noticing itself is the whole of the practice. You are not trying to change the frequency yet. You are simply becoming able to see it."
    },
    {
     "kind": "Anecdote",
     "text": "A woman begins to notice that there is a specific half-second before she speaks where she checks something. She has done this for as long as she can remember. She had never known it was a check. She thought it was just the way she thought before she spoke. The noticing arrives at forty. She spends the next year watching the half-second."
    },
    {
     "kind": "Teaching",
     "text": "The voice frequency is loudest in the moments the person is being asked to take a position. Not a strong position — a quiet one. A slight preference. A small opinion. Those are the moments the mute most reliably intervenes, because they are the moments the person is invited to be heard."
    },
    {
     "kind": "Teaching",
     "text": "You will also recognise the mute in the moments after speaking. A small internal review. A small anxiety about how the sentence landed. That reviewing is the frequency, arriving after the fact to enforce the old rule."
    },
    {
     "kind": "Teaching",
     "text": "The mute does not need to be argued with. Argued with, it grows stronger. It needs to be heard, named, and left. Over time, the naming changes the relationship. The mute stops being the whole of your speaking life and becomes one part of it — a part you can see."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice the half-second. Not to eliminate it. Just to notice it. In noticing the pause, you have already begun to stand outside the frequency that produced it."
    }
   ]
  },
  {
   "id": "m12",
   "label": "12 · Recalibrating",
   "items": [
    {
     "kind": "Teaching",
     "text": "The recalibration of the voice frequency is not the achievement of a loud, confident self. It is not the elimination of doubt, or hesitation, or the small flicker of checking. It is the slow, patient practice of letting the signal arrive without translation, most of the time, in most rooms."
    },
    {
     "kind": "Teaching",
     "text": "The voice frequency does not need to be destroyed. It was, at some point, protective. It may still be, in some rooms. What changes is that it stops being the only voice the person can access. It becomes one option among many — available when it is genuinely needed, and no longer running the whole of the person's speaking life."
    },
    {
     "kind": "Anecdote",
     "text": "Two women spend their whole lives in the same profession. One is famous for her clarity, her directness, her willingness to say the difficult thing. The other, more privately, is equally clear and equally direct. From the outside, they are different. From the inside, they arrived in the same place — one by temperament, one by slow, patient work on a frequency that had kept her silent for thirty years."
    },
    {
     "kind": "Teaching",
     "text": "You will know the frequency is shifting when you stop rehearsing sentences that never got said. When a small disagreement leaves you intact. When you notice, after a good meeting, that you said most of what you actually thought, and that the room did not collapse."
    },
    {
     "kind": "Teaching",
     "text": "The voice frequency is one of the deepest of all the sectors in this course, because it is bound up with who a person is allowed to be in the presence of others. It was installed early, usually by people who did not know they were installing it, and it has been running quietly for most of the person's life. It will not leave on request. But it can be loosened. And the loosening is often one of the most visible signs in a person's whole life that the frequency is finally changing."
    },
    {
     "kind": "Teaching",
     "text": "You were not born with a muted voice. You were given one. The giving was not malicious — it was often well-intended, sometimes necessary, occasionally protective. But it is not yours by nature. The original voice is still there, underneath, waiting to be allowed back into rooms it was once asked to leave."
    },
    {
     "kind": "Recalibration",
     "text": "The same thought. The same room. Two different voices. You have just read an entire sector about the space between them. That space is the whole of this course — and, in voice, it is the space where what you meant finally arrives without translation."
    }
   ]
  }
 ]
};
