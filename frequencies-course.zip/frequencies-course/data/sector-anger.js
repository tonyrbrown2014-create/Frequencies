window.FREQ_SECTOR={
 "key": "anger",
 "title": "Anger",
 "glyph": "◒",
 "blurb": "The emotion you were taught to hide, or the one you were never allowed to feel at all. The frequency of what is permitted to move through you, and where the rest of it goes.",
 "philTitle": "Anger · The Fear Frequency & The Reversal",
 "philText": "Anger is not the problem. The frequency that decides what is allowed to move through you is the problem. This sector is not about managing anger, or suppressing it, or expressing it more skilfully — it is about the quiet assumption, installed long before you could question it, that some of what you feel is permitted and some of it is not. It is about the moment the permitted version of you stops being the only version available.",
 "modules": [
  {
   "id": "m01",
   "label": "1 · What Was Permitted to Move",
   "items": [
    {
     "kind": "Teaching",
     "text": "Every person has a set of rules about what is allowed to move through them. Not a moral code — something quieter. A felt sense of what may be expressed and what may not. Some people can cry but not shout. Some can shout but not cry. Some can be sad but not angry, or angry but not afraid. The rules are old, and they were installed before the person could argue with them."
    },
    {
     "kind": "Teaching",
     "text": "The anger frequency is the shape of those rules. It is not the anger itself. The anger is the raw movement — the surge that arrives when something matters and something is wrong. The frequency is the gate the anger has to pass through, and the gate's decision about whether this particular anger is permitted to exist in this particular body."
    },
    {
     "kind": "Anecdote",
     "text": "A woman notices, in her fifties, that she has never once raised her voice at her husband in twenty-seven years of marriage. She is not a quiet person. She shouts at the television, at drivers, at her brother. But in this one room, her voice does not exist. She had not decided this. Something older than her had."
    },
    {
     "kind": "Teaching",
     "text": "The permitted anger is usually the anger that was safe to have as a child. Whatever was met with acceptance — or at least with survival — became the shape of the person's adult anger. The anger that was punished, or met with withdrawal, or simply erased, does not have a door in the adult body. It has never been given one."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is not cruelty. It was a solution. The child discovered which angers kept them safe and which angers did not, and the body has been running that solution ever since. The solution was correct at the time. It is not necessarily correct now."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of what does not arrive. Not by what the person feels — by what the person never feels. The anger that would be proportionate to a situation, and simply is not there. The frequency has decided in advance that this anger does not get to exist."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal begins with one small noticing: of all the things you have felt this week, which one did not make it to the surface? Not to express it — just to notice that a gate exists, and that something was turned away at it."
    }
   ]
  },
  {
   "id": "m02",
   "label": "2 · The Anger That Arrives Late",
   "items": [
    {
     "kind": "Teaching",
     "text": "When the permitted anger is narrow, the unpermitted anger does not disappear. It is delayed. It arrives hours or days later, when the room is safe and the person is alone. The person who cannot be angry in the meeting is furious in the car park. The person who cannot be angry at their partner is angry at the traffic on the way home."
    },
    {
     "kind": "Teaching",
     "text": "The late anger is one of the clearest signatures of the frequency. The person often experiences it as a mystery. They cannot understand why they are so angry about something so small. The small thing was not the cause. The small thing was the door that the delayed anger finally found."
    },
    {
     "kind": "Anecdote",
     "text": "A man loses his temper at a supermarket checkout over a delay of thirty seconds. He is not a person who loses his temper. The cashier apologises. He apologises too, and is disturbed by himself for the rest of the day. That evening, he remembers a meeting in the morning where something had been said. He had not responded at the time. He had not even felt angry at the time. The anger had been in storage."
    },
    {
     "kind": "Teaching",
     "text": "The late anger is not the person's true anger arriving finally. It is the person's true anger arriving late. There is a difference. The anger that arrived in the car park is the anger that should have arrived in the meeting. The delay does not make it cleaner. It makes it aimless."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is also visible in the way late anger attaches to whatever is nearest. It does not seek the true target. It seeks the first available door. The traffic, the untidy kitchen, the small mistake of a child. The door that opens first gets the whole thing."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the disproportion. When the person's reaction is larger than the situation calls for, something older is arriving through a door that should have been used hours or years ago."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one moment of disproportionate anger this week and to ask, quietly, what earlier moment it might actually belong to. Not to redirect it. Just to see that it was not about what it appeared to be about."
    }
   ]
  },
  {
   "id": "m03",
   "label": "3 · The Anger That Was Never Yours",
   "items": [
    {
     "kind": "Teaching",
     "text": "Not every anger in the body belongs to the person carrying it. Anger is transmitted. A parent's unexpressed rage becomes a child's unexplained irritability. A household with a cold, dangerous silence produces adults who are angry at nothing they can name. The anger was inherited before the person had anything to be angry about."
    },
    {
     "kind": "Teaching",
     "text": "Inherited anger is different from personal anger. It does not have a specific object. It has no memory attached to it. The person simply feels a heat that has no source. The frequency runs the anger anyway, because that is what it was given."
    },
    {
     "kind": "Anecdote",
     "text": "A woman in her thirties notices that she feels a low, continuous irritation whenever she is alone with her mother. She loves her mother. Nothing is said. But there is a heat in the room that she cannot explain and does not put into words. Years later, through a family story, she learns that her grandmother — her mother's mother — had been a difficult, angry woman, and that her mother had spent her childhood absorbing it and never speaking of it. The heat in the room has been there for three generations."
    },
    {
     "kind": "Teaching",
     "text": "Inherited anger is often mistaken for personality. The person thinks of themselves as slightly quick to temper, or slightly tense, or a person who has a short fuse. They do not think of themselves as carrying something. But the anger they carry is not theirs, and this is often the reason it does not respond to the usual things — rest, exercise, self-talk. The usual things address the person's own anger. This anger is not the person's own."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is loosened by naming. When the person can say — silently, quietly — 'this is not mine', the anger begins to have a location it did not have before. It is a houseguest, not a resident. That recognition is the beginning of a different relationship with it."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise inherited anger by its age. The person feels a heat that is older than their own memory. It arrives without context, without a specific event, and often in the presence of specific family members, or specific kinds of rooms, or specific tones of voice."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to consider, once, whether the anger you feel most often might be older than you. Not to solve it. Just to wonder where it came from."
    }
   ]
  },
  {
   "id": "m04",
   "label": "4 · The Anger at the Wrong Person",
   "items": [
    {
     "kind": "Teaching",
     "text": "When anger cannot reach its true target, it seeks substitutes. The employee who cannot be angry at the boss is angry at their partner. The child who cannot be angry at a parent is angry at their own children. The person who cannot be angry at their life is angry at the person closest to them, because the closest person is the safest person to be angry at."
    },
    {
     "kind": "Teaching",
     "text": "The frequency does not plan this. It simply redirects. Anger that cannot move in its true direction moves in the nearest available direction. The person often does not notice the redirect. They experience the anger as being about the partner, the child, the friend. The frequency is not telling them otherwise."
    },
    {
     "kind": "Anecdote",
     "text": "A man is patient, kind, and rarely angry at work. At home, he is short, critical, and easily frustrated. His wife has, over the years, come to believe that this is who he is. Then, one weekend, he goes on a work retreat and comes back different. Something in the room where the anger was permitted had changed. He is a different person to his family for six months. The anger had been arriving from the office the whole time, delivered to the wrong address."
    },
    {
     "kind": "Teaching",
     "text": "The substitute target is almost always someone the person is safe with. Someone who will not leave, or will not retaliate, or will not remember in the morning. The frequency does not want the anger to arrive where it might cost something. It wants the anger to be delivered to a door where it will not be answered."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is also visible in the shape of the person's guilt. They feel bad about being angry at the person they are angry at — because some part of them knows the anger does not belong there. The guilt is a signal, not a failing. It is the frequency's misdelivery being faintly perceived."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the pattern by the shape of the disproportion again — but this time it is not a small event that produced a large reaction, but a large reaction that produces no change. The person gets angry, the anger clears nothing, and the same anger returns the next week. Because the anger was never about the thing it was aimed at."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one moment this week when you were angry at someone who was not the actual source. Not to stop it. Just to see the misdelivery."
    }
   ]
  },
  {
   "id": "m05",
   "label": "5 · The Anger That Became Something Else",
   "items": [
    {
     "kind": "Teaching",
     "text": "When anger is not permitted, it does not stay anger. It transforms. It becomes anxiety, depression, exhaustion, a low-grade bitterness, an obsessive mind, a body that aches. The frequency does not erase the anger. It reroutes it into forms the person can tolerate."
    },
    {
     "kind": "Teaching",
     "text": "This is one of the most costly moves of the frequency. The person who cannot be angry often becomes the person who is anxious, or tired, or quietly sad. The anxiety is often the anger, running in the body without a name. The depression is often the anger, turned inward and lost. The exhaustion is the cost of holding the anger in place."
    },
    {
     "kind": "Anecdote",
     "text": "A woman has been depressed since her early twenties. She has been treated for it, and the treatment has helped, but it has never touched the bottom of it. In her forties, during a difficult period, she begins to feel an anger she has never felt before. Nothing has changed in her life. What has changed is that a permission has finally arrived. Within a year, the depression lifts. It had not been a depression. It had been a suppressed anger wearing depression's clothes."
    },
    {
     "kind": "Teaching",
     "text": "The frequency often prefers the transformed anger to the anger itself. Anxiety, depression, and exhaustion are permitted in ways that anger is not. They can be discussed, treated, sympathised with. The anger cannot. So the frequency feeds the anger into a form that gets help."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the pattern by the shape of what happens when the transformed form is addressed. The anxiety treatment helps a little. The depression treatment helps a little. The tiredness never quite lifts. The treatment is addressing the symptom. The source is the anger that has never been allowed to be itself."
    },
    {
     "kind": "Teaching",
     "text": "This does not mean that every depression is suppressed anger. It means that some are. The frequency is one of the reasons the person may never have considered the possibility — because the anger itself has never been permitted enough to become visible."
    },
    {
     "kind": "Teaching",
     "text": "The reversal, in this module, is not to swap depression for anger, or anxiety for shouting. It is to notice whether the depression or the anxiety or the tiredness has an anger shape underneath it. That noticing does not require action. It only requires permission to wonder."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to ask, once, of one feeling you have carried for a long time: if this were anger, who would it be aimed at? You do not need an answer. You only need to have asked."
    }
   ]
  },
  {
   "id": "m06",
   "label": "6 · The Anger That Was Never Allowed to Arrive",
   "items": [
    {
     "kind": "Teaching",
     "text": "There is a specific moment in many lives when anger arrived and was met with something that ended it. Not with violence — with something subtler. A parent's silence. A partner's withdrawal of warmth. A room's sudden quiet. The anger arrived and was not just refused — it was punished in a way the person has never quite recovered from."
    },
    {
     "kind": "Teaching",
     "text": "The result is not just an unexpressed anger. It is a specific fear of the anger itself. The person experiences their own anger as a danger to be avoided at all costs. The anger does not frighten others. It frightens the person. That is the frequency's deepest install."
    },
    {
     "kind": "Anecdote",
     "text": "A man has never once, in forty-three years, been properly angry at anyone he loves. He is kind, gentle, reliable. He is also, he admits quietly, tired all the time. In therapy, he remembers being nine, telling his father he was angry about something, and watching his father simply leave the room and not speak to him for the rest of the day. He has never been angry at someone he loves since. The fear is not of what they will do. The fear is of what they will not."
    },
    {
     "kind": "Teaching",
     "text": "The frequency's install is complete and elegant. The anger was not just suppressed. The anger was taught that its own arrival produces abandonment. The person now defends against the anger without being asked to. The frequency runs the defence automatically, from the moment the anger first appears in the body."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is not wrong to be afraid. Something real did happen the first time. The child was abandoned in response to their anger. The fear is not irrational. It is the correct memory of a specific room, and the frequency is still running the memory."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of the person's relationship to their own strength. They are often strong people. They are often capable, clear-headed, and calm under pressure. The only thing they cannot do is be angry at someone they love. That is the one doorway that was closed."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal, in this module, is to notice whether your own anger feels dangerous to you — not to others, to you. If it does, the danger is a memory. The memory does not have to be corrected. It only has to be seen."
    }
   ]
  },
  {
   "id": "m07",
   "label": "7 · The Anger That Was Considered Unbecoming",
   "items": [
    {
     "kind": "Teaching",
     "text": "Some anger is unpermitted for reasons that are not personal. They are cultural. Women are often taught that anger makes them unattractive, unlikeable, difficult. Men are often taught that anger is permitted but only in certain forms — never tears, never helplessness, never the anger that admits hurt. Race, class, generation: every category carries its own rules about which angers are allowed."
    },
    {
     "kind": "Teaching",
     "text": "The person absorbs these rules along with all the others. By the time they are an adult, they do not experience the rules as external. They experience them as taste, as temperament, as what they are like. The rules have become the shape of the person's own permission."
    },
    {
     "kind": "Anecdote",
     "text": "A woman is told, in her forties, that she is the calmest person her friend knows. She is not calm. She is constantly furious. She has been furious for decades. But she learned, very young, that her anger was unattractive — she has a specific memory of a relative saying, of a girl at a party, that no man would want to be married to that. The woman is not calm. She is quiet in a specific way, because somewhere beneath her, a girl at a party is still being criticised."
    },
    {
     "kind": "Teaching",
     "text": "The frequency uses cultural codes as evidence. It tells the person that their anger is not just a personal failing — it is a failing of the category they belong to. The anger is not just inconvenient. It is unbecoming. The word is deliberate. The frequency does not say the anger is wrong. It says the anger does not fit the person's shape."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of the shame. The person is not embarrassed that they were angry. They are embarrassed that they were angry in a way that showed. The showing is the problem. The frequency permits the anger. It does not permit the visibility."
    },
    {
     "kind": "Teaching",
     "text": "The reversal, in this module, is not to become visibly angry in every room. It is to notice the shame that arrives about the visibility — and to ask whose shame it is. Often it is a rule from somewhere far away, running in a body that has never been consulted about whether the rule is welcome."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one moment this week when a cultural rule about your anger ran through you. Not to break the rule. Just to see that it is a rule, not your temperament."
    }
   ]
  },
  {
   "id": "m08",
   "label": "8 · The Anger That Belonged to Someone Else",
   "items": [
    {
     "kind": "Teaching",
     "text": "Sometimes the anger a person feels is not theirs at all. It is the anger their family needed someone to carry. A child becomes the one who is angry — the difficult one, the one who fights — because the family could not be angry and the anger had to go somewhere. The child did not choose this. The child was assigned."
    },
    {
     "kind": "Teaching",
     "text": "The person carrying assigned anger often spends their adult life confused by it. They feel an anger that does not match their life. They are angry at institutions that have not hurt them, at people who are not to blame, at themselves for no reason they can identify. The anger is real. It is just not personal."
    },
    {
     "kind": "Anecdote",
     "text": "A man has always been the angry one in his family. His siblings are calm and pleasant. He is the difficult one, the one who fights at the dinner table, the one who calls out what everyone else pretends not to see. As a young man he was ashamed of this. In his fifties he realises: someone in his family had to be the one who saw. The others were calm because he was angry. He was not the difficult one. He was the one who did the feeling for everyone else."
    },
    {
     "kind": "Teaching",
     "text": "The assigned anger is loosened, not by getting rid of it, but by naming it. The person can say — quietly, to themselves — 'this anger is not mine'. Not the whole of it. Some of it, often, is theirs. But some of it is a role they took on at an age they cannot remember, for a family that needed the role filled."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the assigned anger by the shape of the room it arrives in. The person is calm in every context except one — a family gathering, a specific parental home, a particular sibling's presence. The anger arrives in that room and in almost no other. The room is where the role was assigned, and the role is still being run."
    },
    {
     "kind": "Teaching",
     "text": "The reversal is not to stop being the angry one. It is to see that the anger arrived from a system, not from the person. Once that is seen, the person can choose whether they still wish to carry the role, or whether the family can, at last, be angry for itself."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one room in your life where you are reliably a different person — angrier, or quieter, or more careful, or more small. Not to change it. Just to see that the room has a role for you, and that the role is not entirely yours."
    }
   ]
  },
  {
   "id": "m09",
   "label": "9 · The Anger That Was Told to Be Love",
   "items": [
    {
     "kind": "Teaching",
     "text": "Some anger is delivered as love. A parent who is angry but says it comes from care. A partner whose criticism is said to be concern. A household where the loudest voice was said to be the one that cared most. The child learns to feel the anger as love, and to expect love to arrive with a sting."
    },
    {
     "kind": "Teaching",
     "text": "The person carrying this frequency often seeks anger in their adult relationships without knowing it. They experience warmth as too quiet, too flat, too absent. They look for the sharpness. The frequency has taught them that love has a certain temperature, and the temperature is hot."
    },
    {
     "kind": "Anecdote",
     "text": "A woman leaves a gentle partner, and cannot explain to herself why. He is kind, he is present, he is attentive. There is no friction in the relationship at all. It is only years later that she understands: she had not known what to do with a love that did not also contain anger. She had been waiting, for the whole of the relationship, for the moment the love would turn into something with teeth. Because that was the love she recognised."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is not a moral problem. It is a shape. The person is not seeking cruelty. The person is seeking a specific form of intensity that was the only love they knew. The frequency does not say 'look for anger'. It says 'this is what love feels like'."
    },
    {
     "kind": "Teaching",
     "text": "The loosening of this frequency is often the beginning of the person's ability to receive a quieter love. It arrives slowly. At first, the quieter love feels wrong, even suspicious. Over time, the person begins to notice the absence of the sting — not as a missing ingredient, but as a relief."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise this frequency by the shape of the person's language about their early relationships. The love was real. It arrived with anger. The person is not remembering the anger as abuse. They are remembering it as intensity. The frequency does not require an abuser. It requires only that love and anger came in the same room."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one moment this week where you experienced a quiet love as slightly wrong. Not to correct it. Just to see that the wrongness is a frequency, not a fact about the love."
    }
   ]
  },
  {
   "id": "m10",
   "label": "10 · The Anger You Have Been Taught to Apologise For",
   "items": [
    {
     "kind": "Teaching",
     "text": "Many people running the anger frequency apologise for the anger the moment it arrives. Sometimes before it arrives. They feel the surge, and they begin preparing the apology in the same breath. The anger is not just suppressed or redirected — it is immediately retracted, before it has had time to be itself."
    },
    {
     "kind": "Teaching",
     "text": "The apology is not for a specific wrong. It is for the anger's existence. The person is apologising for having felt something. The frequency has taught them that the feeling itself is the transgression. The apology is the tax the frequency charges for feeling anything real."
    },
    {
     "kind": "Anecdote",
     "text": "A woman catches herself, mid-sentence, saying 'sorry' to her partner. She has said nothing wrong. She was about to say something honest, something slightly difficult, and the 'sorry' came out first, as if to preempt the sentence. She stops. She does not know why the apology arrived. The sentence had not yet been spoken. The frequency had decided the sentence would need one."
    },
    {
     "kind": "Teaching",
     "text": "The apology is often the most visible mark of the frequency. The person apologises for their anger in ways that surprise even them. They apologise for opinions, for preferences, for taking up space, for the small irritations that any human being feels in an ordinary day. The frequency tells them all of it is a fault."
    },
    {
     "kind": "Teaching",
     "text": "The loosening of this frequency is quiet. The person begins to notice the apology arriving — and to let it pass without acting on it. They do not stop apologising. The apology still comes. But something behind it is beginning to see itself, and that seeing is the shift."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of what would happen if you did not apologise. Not the social consequence — the internal one. If you said one honest, slightly angry thing in a room without preempting it, what would arrive in your own body? The discomfort is the frequency. It is not the anger."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice, once this week, an apology arriving before the anger. Not to withhold the apology. Just to notice that the apology and the anger came in the same moment, and that the anger had not yet had a chance to exist."
    }
   ]
  },
  {
   "id": "m11",
   "label": "11 · The Anger You Are Still Carrying",
   "items": [
    {
     "kind": "Teaching",
     "text": "There comes a moment in the loosening of the anger frequency when the person realises, quietly, that they are carrying anger they did not know was there. Not one incident — a set of them. A decade of small angers that were never permitted, layered underneath the person's calm. The calm was real. So was the layer beneath it."
    },
    {
     "kind": "Teaching",
     "text": "This is the moment the frequency most resists. The person has built an entire identity on not being angry. The realisation that they have been angry the whole time — quietly, continuously, underneath — can feel like a betrayal of the self they thought they were."
    },
    {
     "kind": "Anecdote",
     "text": "A man of sixty, gentle and mild, begins, in one therapy session, to weep — not from sadness, but from an anger so old it has no words. He sits with it for a long time. When it passes, he says: I did not know I had been angry for forty years. He is not broken by the discovery. He is, strangely, relieved. The thing he had spent forty years not being had been with him the whole time."
    },
    {
     "kind": "Teaching",
     "text": "The anger you are still carrying is not a moral fact about you. It is a fact about what was permitted. The frequency did not eliminate the anger. It simply moved it somewhere you could not see it, and gave you a life that ran, more or less, without it."
    },
    {
     "kind": "Teaching",
     "text": "The revealing of this anger is not usually dramatic. It arrives in a moment of safety — a therapy session, a long walk, a quiet evening. It arrives as a feeling, not as a memory. What the person discovers is not the anger's cause. It is the anger's size. It has been larger than they knew, and there for longer than they thought."
    },
    {
     "kind": "Teaching",
     "text": "The revealing is also not the fixing. Many people believe that once the anger is felt, the work is done. The feeling is the beginning. The work is the slow integration of the anger into a life that had been running without it — a process that can take years, and that has no endpoint in the ordinary sense."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to sit, once, with the possibility that you are carrying anger you have never fully felt. Not to find it. Not to express it. Just to allow the possibility that it is there."
    }
   ]
  },
  {
   "id": "m12",
   "label": "12 · Recalibrating",
   "items": [
    {
     "kind": "Teaching",
     "text": "The recalibration of the anger frequency is not the achievement of healthy anger expression. It is not the development of good boundaries, or the capacity to assert oneself, or the perfect tone of voice. It is the slow, patient practice of letting the anger be what it is — without the frequency deciding in advance what it is permitted to be."
    },
    {
     "kind": "Teaching",
     "text": "The anger frequency does not disappear. It has been installed since childhood, by a specific household, in a specific culture, at a specific moment in history. It will return in the presence of the people who installed it, in the rooms where the original rules were written. What changes is that the person can see the gate, and can choose — sometimes — to walk through it."
    },
    {
     "kind": "Anecdote",
     "text": "Two siblings grow up in the same household. Both learn that anger is not permitted. One spends her life calm, capable, and quietly exhausted — the anger never named, never felt, carried as a low, continuous weight. The other, in her thirties, begins the slow work of feeling what was never permitted. She is not visibly different from her sister by the time they reach fifty. She is simply, at last, a whole person. The anger did not ruin her. The anger, allowed to arrive, made her more herself, not less."
    },
    {
     "kind": "Teaching",
     "text": "You will know the frequency is shifting when the anger arrives and does not automatically require an apology. When the anger arrives in a meeting and is present in the room rather than in the car park three hours later. When the anger at a small thing is no longer larger than the small thing. When the anger, finally, is able to be what it is."
    },
    {
     "kind": "Teaching",
     "text": "The anger frequency is one of the deepest sectors in this course, because the anger is not the emotion most people think it is. It is the load-bearing emotion — the one that carries the truth about what a person cannot tolerate, and the one most often rewritten, redirected, inherited, or suppressed by the frequency that was installed to manage it."
    },
    {
     "kind": "Teaching",
     "text": "You were not born with a gate. You were given one. The people who gave it to you were given one before that, by people who were told that their anger was dangerous, unbecoming, or love. The gate is a chain. It can be set down — not by becoming angry at the people who installed it, but by noticing that the gate was never yours."
    },
    {
     "kind": "Recalibration",
     "text": "The same anger. The same room. Two different permissions. You have just read an entire sector about the space between them. That space is the whole of this course — and, in anger, it is the space where what was never permitted to move finally begins to move."
    }
   ]
  }
 ]
};
