window.FREQ_SECTOR={
 "key": "status",
 "title": "Status",
 "glyph": "❂",
 "blurb": "Where you sit, and where you think you sit. The frequency of comparison, position, and being evaluated — and the reversal that lets a person simply be, without a rank.",
 "philTitle": "Status · The Fear Frequency & The Reversal",
 "philText": "Status is not the problem. The frequency that has decided you are being ranked, always, and that the ranking matters, is the problem. This sector is not about ambition or class or achievement — it is about the quiet assumption, installed long before any career, that a person's place in the world is being evaluated, at every moment, against everyone else. It is about the moment the person can simply be where they are, without a rank.",
 "modules": [
  {
   "id": "m01",
   "label": "1 · The Rank That Is Always Running",
   "items": [
    {
     "kind": "Teaching",
     "text": "Somewhere in most modern lives there is a quiet ranking system that has been running since childhood. It measures where the person sits — against siblings, against classmates, against colleagues, against strangers on a screen. The ranking is rarely conscious. It is a background process. It is running whether the person is at work or at home, in a meeting or alone."
    },
    {
     "kind": "Teaching",
     "text": "The status frequency is not the ranking itself. Everyone notices positions in groups; it is human. The frequency is what the ranking means. In some people, the ranking is a piece of information. In others, the ranking is a verdict — a fact about who they are. The second is the frequency."
    },
    {
     "kind": "Anecdote",
     "text": "A woman is at a wedding. She is happy for the couple. She is enjoying the evening. At some point in the night, she notices that she has been categorising the room — who has done well, who has done less well, where she sits among them. She is not being unkind. She is not even aware of doing it. The ranking has simply been running the whole evening, underneath the celebration, as it does most evenings."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is installed early, usually by a household that was itself running the ranking. A family that measured children against each other. A school that published positions. A culture that decided, in a thousand small ways, whose life was worth admiring. The child receives the ranking before they have anything to rank."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is often invisible because it presents itself as realism. Everyone knows some people do better than others. The frequency uses this truth as cover. It says: this is just how the world works. The person accepts it, because it is true as far as it goes. What is not true is the meaning the frequency attaches to it."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of the person's attention when they walk into a room. Not the room itself. The scan. The small, automatic registration of who is present, and where the person sits among them. The scan is the frequency, arriving before the person has decided anything."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal begins with one small noticing: in the last room you walked into, did a small ranking run? Not to stop it. Just to see that it ran, and to see that it ran whether or not you asked it to."
    }
   ]
  },
  {
   "id": "m02",
   "label": "2 · The Room That Taught You Where You Sit",
   "items": [
    {
     "kind": "Teaching",
     "text": "The status frequency has an origin, and the origin is almost always a specific household. Not a household that told the child where they sat — that would be too obvious. A household that showed them. The way the parents spoke about other families. The way the parents spoke about their own position. The way success and failure were discussed at the table."
    },
    {
     "kind": "Teaching",
     "text": "The child absorbs the position along with everything else. They learn, without being told, that the family is one of the families that does well, or the family that has struggled, or the family that is respectable but not quite at the top. The child, watching the parents, learns where they sit before they have any achievements of their own to sit on."
    },
    {
     "kind": "Anecdote",
     "text": "A man is in his fifties before he realises that he has spent his entire life in a competition he cannot remember entering. He has always worked hard, always aimed slightly higher, always been slightly anxious about his position. In a family gathering, his uncle mentions, casually, that the man's grandfather had been the same — always worried about where the family stood. The man has been running his grandfather's ranking. He has never met him."
    },
    {
     "kind": "Teaching",
     "text": "The household origin is often class-shaped, but not only class-shaped. A household that had money and lost it teaches a different ranking than one that never had it. A household that was first-generation professional teaches a different one than a household that was third-generation. The frequency in each is precise, and the person carries the precision without knowing where it came from."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the origin by the shape of the person's anxiety. Not the general worry about the future. The specific worry about where they sit. The worry that they are behind. The worry that someone they know has overtaken them. The worry has an age, and the age usually points to the household."
    },
    {
     "kind": "Teaching",
     "text": "The reversal is not to reject the household. It is to see the household as a specific arrangement, at a specific time, with a specific anxiety, and to notice that the arrangement has been running in the person's adult life as if it were the shape of the world."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice, once, where your household sat, and to see that the sitting was a fact about a specific time and place. The ranking has an address. The address is not universal."
    }
   ]
  },
  {
   "id": "m03",
   "label": "3 · The Status You Are Trying Not to Lose",
   "items": [
    {
     "kind": "Teaching",
     "text": "For some people, the frequency is not about gaining status. It is about not losing what has already been acquired. The person is established. They have a place. And underneath the place, the frequency is running the fear of falling."
    },
    {
     "kind": "Teaching",
     "text": "This is a different flavour of the frequency. It is quieter, more respectable, and often more invisible than the climb. The person who is climbing is visibly anxious. The person who is trying not to fall is invisibly anxious. They are more careful, more measured, more reserved. They avoid certain rooms and certain people. They do not take the risks that could cost them the place."
    },
    {
     "kind": "Anecdote",
     "text": "A man has, by any measure, arrived. He is respected, he is comfortable, he is where he intended to be. And yet he finds, increasingly, that he declines things. The conference. The dinner. The old friend who has not done as well. He does not want to be seen, exactly, though he could not say why. He has been protecting a position he already has."
    },
    {
     "kind": "Teaching",
     "text": "The fear of falling is often more restrictive than the climb. The climber is reaching. The faller is guarding. The guard requires constant attention. Every room is a room to be evaluated, every conversation a potential exposure. The frequency, in this mode, converts the whole adult life into a fence that must be maintained."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise this version by the shape of the person's refusals. The opportunities declined. The people not seen. The rooms not entered. When asked why, the person usually has a plausible reason. The reason is not the reason."
    },
    {
     "kind": "Teaching",
     "text": "The reversal is not to throw the position away. It is to see that the position is being guarded as if it could be lost. Once the guarding is seen, the position can be held, or not held, without the constant maintenance."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one thing you have declined in the last month, and to ask whether you declined it because you did not want it, or because you were protecting something. The answer is usually both. The second half is the frequency."
    }
   ]
  },
  {
   "id": "m04",
   "label": "4 · The Status That Is Compared, Not Measured",
   "items": [
    {
     "kind": "Teaching",
     "text": "The status frequency does not measure the person's life. It compares it. This is not the same thing. A person can live a good life — a life they would, if asked honestly, say they wanted — and still be anxious, because someone they know is doing slightly better by some external measure."
    },
    {
     "kind": "Teaching",
     "text": "The comparison is almost never with people who are further away. It is with people who are close. The sibling. The school friend. The colleague in the next office. The comparison uses proximity as its fuel. The frequency does not worry about the world's richest people. It worries about the person's sister."
    },
    {
     "kind": "Anecdote",
     "text": "A man is content with his job, his flat, his life. He would not change any of it. And then a friend of his — same age, same background, same starting point — buys a house. For a month, the man cannot feel settled. Nothing about his own life has changed. The frequency has simply found a new reference point, closer to home."
    },
    {
     "kind": "Teaching",
     "text": "The frequency chooses the comparison, and the choice is not random. It picks the person most likely to produce discomfort. It picks the person the person loves and slightly resents. It picks the person who reminds the person of the version of themselves they have not become."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of the person's reading, watching, and scrolling. What content are they consuming? Whose lives are they looking at? The frequency has a preference for material that makes the person feel slightly behind, and the person, without knowing why, keeps consuming it."
    },
    {
     "kind": "Teaching",
     "text": "The reversal is not to stop noticing others. It is to notice that the comparison is not a measurement. The other person's house does not say anything about the person's life. The comparison is a frequency, and it has its own arithmetic."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one comparison you made this week — with someone close to you — and to see that the comparison did not measure your life. It compared it. The two are not the same."
    }
   ]
  },
  {
   "id": "m05",
   "label": "5 · The Status That Arrives as Class",
   "items": [
    {
     "kind": "Teaching",
     "text": "The status frequency is not only psychological. It is also social and cultural. It is inscribed in the person's accent, education, tastes, habits, and the way they move through the world. The person has been ranked from the outside, all their life, whether they wanted it or not."
    },
    {
     "kind": "Teaching",
     "text": "The frequency in these cases is not invented by the person's mind. It is the correct reading of a world that has, in fact, been ranking them. Class is real. Caste is real. Racism is real. The frequency in these lives is not a distortion. It is the internalised version of a real-world verdict."
    },
    {
     "kind": "Anecdote",
     "text": "A woman is the first in her family to attend university. She arrives at twenty, excited, ready. Within a term, she has learned new words, new habits, new ways of holding a fork. She has also learned, quietly, that she does not quite belong. She has been running the frequency ever since. It is not a distortion. It is a report of what happened."
    },
    {
     "kind": "Teaching",
     "text": "The frequency in these lives has two layers. The first is the historical frequency that arrived in childhood — the family's sense of its own position. The second is the current, live frequency — the accurate reading of a world that is still ranking the person. Both are real. Both are running."
    },
    {
     "kind": "Teaching",
     "text": "The work in these lives is not to pretend that the ranking is not happening. It is. The work is to notice that the person's worth is not contingent on the ranking. The world may continue to rank. The person does not have to live inside the ranking."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the difference between the two layers by the shape of the person's ease. When the person is with people from their own class background, the frequency is often absent. When the person is with people from a different background, the frequency arrives. The frequency is not the person's invention. It is the room's assessment, arriving early."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal, in this module, is not to feel that you belong in every room. It is to notice that the ranking of some rooms is real, and that the ranking is not the whole of your life."
    }
   ]
  },
  {
   "id": "m06",
   "label": "6 · The Status That Was Called Motivation",
   "items": [
    {
     "kind": "Teaching",
     "text": "The status frequency is often mistaken for ambition. The person who is always working, always improving, always pushing, is described as driven. But ambition and the status frequency are not the same. Ambition wants the thing. The frequency wants the position. The two can look similar, and only one of them can be rested."
    },
    {
     "kind": "Teaching",
     "text": "The person running the status frequency does not experience themselves as chasing rank. They experience themselves as doing their best. The frequency has taken the shape of a personal standard. The standard rises with each achievement. The achievement does not satisfy, because the standard is a moving comparison, not a fixed goal."
    },
    {
     "kind": "Anecdote",
     "text": "A man is asked, in his fifties, what he would do if he knew he would never advance further. He pauses. He cannot quite imagine the question. All of his plans, in some way, involve moving up. He is not sure he would have anything to do if the moving up were taken off the table. He had believed he loved the work. He is beginning to wonder whether he loved the position."
    },
    {
     "kind": "Teaching",
     "text": "The frequency uses the language of growth to do its work. It says: keep improving. It says: never be complacent. It says: stay ahead. All three are respectable. All three, if unchecked, are the frequency's mantras."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of what happens when the person stops. Not for a day — for a season. If the stopping produces discomfort disproportionate to the stopping, the frequency is running. The person is not resting. They are between things."
    },
    {
     "kind": "Teaching",
     "text": "The reversal is not to become lazy. It is to notice whether the momentum is coming from a genuine appetite for the work, or from a rank that has not yet been secured. The two produce different kinds of tiredness."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one achievement in your life that did not settle the way you expected it to. You got the thing. The settling did not arrive. That non-settling is the frequency, refusing to be resolved."
    }
   ]
  },
  {
   "id": "m07",
   "label": "7 · The Status That Is Only Ever Visible to Others",
   "items": [
    {
     "kind": "Teaching",
     "text": "There is a strange fact about the status frequency. The person running it rarely feels their own status. They feel the status of others. Their own status is invisible to them, because they are inside it, and because the frequency has told them that their own position is always slightly less than it appears."
    },
    {
     "kind": "Teaching",
     "text": "This means the person is often perceived as more established, more secure, more successful than they feel. Other people see them as arrived. They see themselves as still climbing. The frequency does not let the person see the view from outside."
    },
    {
     "kind": "Anecdote",
     "text": "A man is told, at a dinner, by an old friend, that he is the person they all look up to. He does not believe it. He is not being modest. He genuinely does not believe it. He knows, privately, that he is still behind. He has been running the frequency for so long that he cannot see what is visible from outside. His friend is not lying. He is simply reporting what the room sees."
    },
    {
     "kind": "Teaching",
     "text": "The frequency in these cases is loosened, not by self-congratulation, but by curiosity. What do other people see? Not to believe them immediately. To at least ask, because the person's own view has been managed by the frequency for decades."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of the person's response to praise. They deflect. They explain it away. They point to the people ahead of them. The deflection is not modesty. It is the frequency, refusing to accept the view from outside."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to ask one person you trust, honestly, how they see your position. Not to believe them all at once. Just to hear the view from outside, and to notice how different it is from the view from inside."
    }
   ]
  },
  {
   "id": "m08",
   "label": "8 · The Status That Was Handed Down",
   "items": [
    {
     "kind": "Teaching",
     "text": "Some status frequencies are inherited. The person is not carrying their own ranking. They are carrying their parent's. A father who never quite made it. A mother who was always second. A family that was once higher and has slipped. The child is carrying an unfinished business, and the business is not theirs."
    },
    {
     "kind": "Teaching",
     "text": "Inherited status is often more driven than personal status. The person is pushing not for their own position but for a position the family did not achieve. The push is quieter than the family's, but it is more relentless, because it is being run on behalf of someone who is no longer in the room."
    },
    {
     "kind": "Anecdote",
     "text": "A woman realises, in her forties, that every achievement she has chased has been shaped by her father's disappointment. He was, in his own mind, never quite what he should have been. He never said this. But the woman grew up inside a house that was always slightly disappointed, and she has spent her adult life trying to lift the house out of its disappointment. Her father has been dead for ten years. She is still lifting."
    },
    {
     "kind": "Teaching",
     "text": "The inherited status is loosened, not by failing, but by separating. The person does not have to reject the parent. They simply have to notice that the ranking they have been chasing is the parent's ranking, not theirs. Once separated, the person can choose. Some choose to keep chasing. Some choose to stop. Both are possible only after the separation."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the inherited version by the shape of the person's ambitions. Are they in the shape of the person's own life, or in the shape of a life that someone else needed them to have? The two feel the same from inside. They feel very different from the perspective of a decade."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one ambition of yours that might be someone else's. Not to abandon it. Just to see whether it fits the shape of your life, or of another's."
    }
   ]
  },
  {
   "id": "m09",
   "label": "9 · The Status That Cannot Be Shared",
   "items": [
    {
     "kind": "Teaching",
     "text": "One of the frequency's quieter cruelties is that it makes status unshareable. The person who has achieved something cannot enjoy it fully, because the frequency is already comparing it. The person who has not achieved something cannot be comforted, because the comfort would be a further loss of position. Status, by its nature, is individual. It cannot be given away or held in common."
    },
    {
     "kind": "Teaching",
     "text": "This is the deepest cost of the frequency. The person has been running the ranking for so long that they have lost the ability to simply be glad with others. A friend's success becomes an occasion for the frequency. A family's joy becomes a comparison. The frequency has privatised what should be communal."
    },
    {
     "kind": "Anecdote",
     "text": "A man notices, at his daughter's graduation, that he cannot be fully present. The day is hers. He is proud of her. And underneath the pride, the frequency is running — evaluating the other families, comparing his daughter's university to others, tracking the room. He loves her. He is not fully at her graduation. The frequency has taken part of the day."
    },
    {
     "kind": "Teaching",
     "text": "The frequency cannot be solved by achieving more. The achievement has already been tried, and the frequency has simply found a new reference point. The frequency is loosened only when the person can notice the ranking running, and can choose not to follow it into the moment."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of the person's celebrations. When they are happy for another person, how long does the happiness last before the comparison arrives? A minute. An hour. Sometimes less. The frequency uses the moment after the happiness as its entry point."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one moment this week where another person's good news produced, briefly, a comparison in you. Not to stop the comparison. To notice how quickly the frequency arrived, and to see that the good news was real before the frequency."
    }
   ]
  },
  {
   "id": "m10",
   "label": "10 · The Status That Arrives Without the Person",
   "items": [
    {
     "kind": "Teaching",
     "text": "Some people notice, in the loosening of the frequency, that their status has continued without them. They have stopped chasing. The rank has not fallen. It has been held by others, in their absence, as if they were still there. The frequency has been telling them that their position requires constant maintenance. The position required none."
    },
    {
     "kind": "Teaching",
     "text": "This is often the moment the frequency becomes visible as a frequency. The person can see, clearly, that the maintenance was not keeping the rank. The maintenance was keeping the frequency. The rank was being kept by things the person had done years ago and had forgotten about."
    },
    {
     "kind": "Anecdote",
     "text": "A man takes a year off work. He is nervous about this. The frequency is very loud in the first months. And then, at some point, he notices that nothing has changed. His position at work, his standing among friends, his place in the family — all of it has been held without him. He has not been maintaining. The maintenance had been an illusion."
    },
    {
     "kind": "Teaching",
     "text": "The loosening of the status frequency often happens, not through meditation or reflection, but through absence. The person steps out, for a while, and finds that the position they were guarding did not need guarding. The finding is quiet. It is not a breakthrough. It is a demotion of the frequency."
    },
    {
     "kind": "Teaching",
     "text": "You will know the frequency is loosening when the person stops doing the small maintenance actions. The strategic email. The careful presence at events. The slightly above-average gift. The frequency, which required the maintenance, does not notice the maintenance missing. Only the frequency required the maintenance."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to take a small absence this month — a weekend, a fortnight, a month — and to notice that the position holds itself. The frequency will not believe it until the absence has been tried."
    }
   ]
  },
  {
   "id": "m11",
   "label": "11 · The Status You Are Still Chasing",
   "items": [
    {
     "kind": "Teaching",
     "text": "There comes a moment in the loosening of the status frequency when the person realises, quietly, that they are still chasing. Not visibly. Not in the old way. But there is still a rank somewhere in the future. Still a version of themselves they have not yet reached. Still a room they have not yet been admitted to."
    },
    {
     "kind": "Teaching",
     "text": "This is not a failure of the work. It is the recognition that the frequency is deep, and installed early, and will not simply dissolve. The person can see the chasing now. The chasing continues. What has changed is that the person is no longer inside the chase without knowing it."
    },
    {
     "kind": "Anecdote",
     "text": "A woman in her sixties, at the end of a long and good career, notices one evening that she is still thinking about the next thing. She has no reason to. She has done well. The frequency is running a future that does not need to be run. She laughs. It is not a bitter laugh. It is the laugh of someone who has caught the frequency in the act, and knows there is nothing left to do but notice."
    },
    {
     "kind": "Teaching",
     "text": "The chase that continues is not the problem. The chase that continues without the person knowing it is. Once the person can see the chase, the chase is theirs to keep or set down, project by project, year by year. The frequency has not been removed. The frequency has been seen."
    },
    {
     "kind": "Teaching",
     "text": "You will know the frequency is shifting when the person can have a good year, or a bad year, and it does not change the person's view of their own worth. The year is the year. The person is the person. The frequency is a visitor, arriving when it arrives."
    },
    {
     "kind": "Teaching",
     "text": "The status frequency is one of the deepest of the modern frequencies in this course, because the world the person lives in is itself running the ranking. Loosening the frequency does not remove the world's ranking. It removes the frequency's internalisation of the ranking — the small voice that keeps the person in the queue long after the queue has stopped mattering."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one rank you are still chasing, and to let it be a rank, not a fact about your worth. Not to abandon the chase. To see that the chase and the worth are two different things."
    }
   ]
  },
  {
   "id": "m12",
   "label": "12 · Recalibrating",
   "items": [
    {
     "kind": "Teaching",
     "text": "The recalibration of the status frequency is not the achievement of a person who no longer cares about position. It is not the abandonment of ambition, or the cultivation of indifference, or the arrival at a state of equal regard for all outcomes. It is the slow, patient practice of noticing the ranking when it runs, and letting it be a ranking rather than a verdict."
    },
    {
     "kind": "Teaching",
     "text": "The status frequency does not disappear. It has been installed early, and reinforced by a world that is, itself, running the ranking. It will return in certain rooms, in the presence of certain people, in the moments when the person is tired or uncertain. What changes is that the person can see it running, and can choose whether to believe it."
    },
    {
     "kind": "Anecdote",
     "text": "Two people from the same school, same class background, same professional world. One spends the following decades climbing, watching, adjusting, comparing. The other does much the same work, in much the same place, but with a different relationship to the ranking. Thirty years later, the first is respected, comfortable, and slightly tired. The second is respected, comfortable, and slightly free. Neither has more or less of the world's markers. One has stopped believing the score."
    },
    {
     "kind": "Teaching",
     "text": "You will know the frequency is shifting when the person can walk into a room and not scan. Or can scan and notice the scan, without taking it as truth. When another person's success does not produce the small contraction in the chest. When the person can simply be where they are, without the ranking updating in real time."
    },
    {
     "kind": "Teaching",
     "text": "The status frequency is one of the deepest sectors in this course, because it is not only psychological. It is built into the structure of the world the person lives in. The person is genuinely being ranked. The frequency is genuinely accurate, in the narrow sense. What the frequency cannot tell the person is that being ranked and being worth something are not the same thing."
    },
    {
     "kind": "Teaching",
     "text": "You were not born with a rank. You were given one, and the world has been updating it ever since. The update is real. The update is not the person. The difference is small, and the difference is the whole of the sector."
    },
    {
     "kind": "Recalibration",
     "text": "The same room. The same person. Two different relationships to where they sit. You have just read an entire sector about the space between them. That space is the whole of this course — and, in status, it is the space where the person can finally be where they are."
    }
   ]
  }
 ]
};
