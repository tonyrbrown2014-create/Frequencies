window.FREQ_SECTOR={
 "key": "grief",
 "title": "Grief",
 "glyph": "◑",
 "blurb": "The loss that keeps arriving, and the culture that keeps telling you it should be over. How the frequency of \"I should be past this\" keeps a person from simply carrying what they lost.",
 "philTitle": "Grief · The Fear Frequency & The Reversal",
 "philText": "Grief is not the problem. The frequency that tries to make grief into a problem is the problem. This sector is not about loss itself — it is about what happens after the loss, when a person is quietly told, by a culture and by their own protective mind, that grief has a timeline, a correct form, and an appropriate end. It is about the moment grief stops being managed and starts being carried.",
 "modules": [
  {
   "id": "m01",
   "label": "1 · The Frequency Beneath the Loss",
   "items": [
    {
     "kind": "Teaching",
     "text": "Every loss arrives with a grief frequency already attached. Not just the person, the place, the version of the life that has ended — but a set of assumptions, quiet and old, about how grief is supposed to go. What it is supposed to look like. How long it is supposed to last. What it is and is not supposed to become."
    },
    {
     "kind": "Teaching",
     "text": "These assumptions were installed long before the loss. They arrived in childhood, from a household, a school, a culture. The child learned, without anyone saying it aloud, that grief is a thing one moves through, and that there is a correct way to do it. By the time the actual loss arrives, the assumptions are already there, waiting."
    },
    {
     "kind": "Anecdote",
     "text": "A woman's mother dies when she is thirty-four. For the first three months she weeps at odd moments. In the fourth month, a friend says, gently, that she seems to be doing so well. Something in her body goes quiet. She does not cry again for eight months. She had not decided to stop. The frequency had decided for her."
    },
    {
     "kind": "Teaching",
     "text": "The grief frequency is not the grief. The grief is the ache, the missing, the ongoing presence of an absence. The frequency is the running commentary underneath the grief — the voice that says this is too much, this is too long, this should be further along, other people are handling this better."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is often inherited. A parent who never grieved a loss of their own transmits the unspoken rule: grief is not entered, it is endured quietly. The child receives it the way they receive all frequencies — as the shape of the world."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of your own narration. When you catch yourself describing your grief as if reporting on a project — six months in, doing okay, nearly through — the frequency is running the account. The grief is the ache. The report is the frequency."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal begins with one small noticing: at some point today, is the grief yours, or is it being assessed? You do not need to change the assessment yet. Just to notice that it is running."
    }
   ]
  },
  {
   "id": "m02",
   "label": "2 · The Timeline That Was Never Yours",
   "items": [
    {
     "kind": "Teaching",
     "text": "There is a timeline attached to grief that most people never chose. It arrives in phrases: 'a year is usually enough.' 'By six months it should be easier.' 'It's been two years now.' These sentences are not observations. They are instructions. They are the frequency, spoken by the people around the grieving person."
    },
    {
     "kind": "Teaching",
     "text": "The timeline is a fiction. Grief does not follow one. It arrives in waves. It softens unevenly. It comes back on the most ordinary afternoons. It does not resolve. It does not end. It becomes something the person carries, not something the person completes."
    },
    {
     "kind": "Anecdote",
     "text": "A man's father died when he was twelve. He is sixty now. He still catches himself picking up the phone to tell his father something, once or twice a year, at the exact moment he forgets. He is not still grieving. He is still carrying. The two are not the same, and the timeline was never able to tell them apart."
    },
    {
     "kind": "Teaching",
     "text": "The timeline is not malicious. It is a kindness that has gone wrong. People offer it because they want the person to be okay, and they do not know how to say 'there is no end to this', so they say something that makes the present moment feel provisional instead."
    },
    {
     "kind": "Teaching",
     "text": "The frequency feeds on the timeline. Every time the person notices they are still grieving past the expected point, the frequency registers failure. It does not say the loss is unfinished. It says the person is unfinished, which is a different and much crueller thing."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency in the moments you catch yourself performing a shorter grief than the one you actually have. In the answer 'I'm doing well' given to a question that was sincere. In the laugh that arrives a beat too quickly at a memory that still hurts."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one moment where the timeline pressed. Not to refuse it out loud — just to see that the pressure is coming from somewhere outside the grief. The grief itself has no schedule. The pressure does."
    }
   ]
  },
  {
   "id": "m03",
   "label": "3 · The Grief You Were Never Allowed to Name",
   "items": [
    {
     "kind": "Teaching",
     "text": "Not all grief is permitted. Every culture — every family, every workplace, every friendship group — has a scale of losses that are recognised and losses that are not. A parent, a partner, a child: permitted. A pet, a friendship, a job, a city, a version of yourself, a pregnancy that did not continue, a relationship that ended without ceremony: often not."
    },
    {
     "kind": "Teaching",
     "text": "The unpermitted grief is one of the deepest frequencies in modern life. The person is grieving something real, and the world around them has quietly decided the grief is disproportionate. The person learns to hide the grief so it does not have to be defended."
    },
    {
     "kind": "Anecdote",
     "text": "A woman is in her early forties. She has never told anyone that she still grieves a friendship that ended twelve years ago, over nothing, in a way neither of them could explain. Her father has died since, and she has grieved him openly and properly. The friendship still has no name in her life. It is the only thing she has never been able to mention."
    },
    {
     "kind": "Teaching",
     "text": "The frequency of unpermitted grief is not the same as disenfranchised grief in the clinical sense, though it is close. It is the felt rule that this particular loss does not deserve what it is producing. The person is not being told to stop. The person is being told, silently, that they were never supposed to have started."
    },
    {
     "kind": "Teaching",
     "text": "Smaller losses, unpermitted, accumulate. A dozen tiny deaths, none of them marked, none of them given room. The person does not feel a single heavy grief. They feel a diffuse weight — a low-grade sadness underneath everything, that has no obvious cause and cannot be explained to anyone."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of the lists. When someone asks what you have lost, is there a name that arrives and then immediately gets moved aside? That movement is the frequency. The name was not permitted. The frequency made the decision before you could."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to name one unpermitted loss, silently, in your own mind, without arguing for its legitimacy. Not to grieve it openly. Just to stop pretending it is not on the list."
    }
   ]
  },
  {
   "id": "m04",
   "label": "4 · When the World Moves On",
   "items": [
    {
     "kind": "Teaching",
     "text": "There comes a point in every grief when the world moves on around the person. The cards stop arriving. The casseroles stop. The friends stop checking in. The loss continues, but the acknowledgement of the loss does not. The person is left holding something that the room has agreed to set down."
    },
    {
     "kind": "Teaching",
     "text": "The frequency treats this moment as evidence. It says: see, everyone else has moved on. It has been long enough. You should be past this. The frequency uses the silence of others as proof that the grief is now disproportionate — even though the silence of others is not about the grief at all. It is about the limits of human attention."
    },
    {
     "kind": "Anecdote",
     "text": "A man loses his wife after forty years. The first three months, he is not alone for a single day. The fourth month, the calls slow. The sixth month, he goes a full week without speaking to anyone about her. He is not abandoned. He is simply, for the first time, alone with the grief. The frequency tells him the loneliness is proof that he has been slow. He has not been slow. He has been beginning."
    },
    {
     "kind": "Teaching",
     "text": "The world moving on is not a betrayal. It is a rhythm. The people around the grieving person have lives that continue, and their attention flows back into those lives, not out of malice, and not out of judgment. The person's own attention is the only attention that has to stay."
    },
    {
     "kind": "Teaching",
     "text": "This is the moment the frequency most often wins. In the months when the world has quieted, the person is alone with the grief and with the running commentary about the grief. The commentary is louder now, because there is nothing else in the room."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency in the sharp disappointment when a friend does not mention the loss. The loss was not mentioned because the friend was busy, or careful, or unsure. The frequency reads the silence as a verdict. The verdict was never given."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one moment where the world's quiet was read as the world's verdict. Not to correct it. To see that the quiet and the verdict are two different things."
    }
   ]
  },
  {
   "id": "m05",
   "label": "5 · The Forms Grief Takes",
   "items": [
    {
     "kind": "Teaching",
     "text": "The frequency also has assumptions about the form grief is allowed to take. Tears are permitted. Silence is permitted, up to a point. Anger is usually not. Numbness is usually not. Laughter is usually not. Keeping the belongings is usually not. Letting them go is usually not."
    },
    {
     "kind": "Teaching",
     "text": "The form the grief actually takes is usually different from the form the frequency permits. A person who has not cried does not necessarily feel less. A person who cannot stop talking about the loss is not necessarily unable to move on. A person who is angry is not necessarily failing to grieve. The form and the frequency are two different things."
    },
    {
     "kind": "Anecdote",
     "text": "A woman loses her brother. She does not cry at the funeral, or the wake, or the following week. Her family begins to worry, gently, in the way families do. She is fine. Six months later, driving home from work, she hears a song on the radio and has to pull the car over. The grief had been waiting for a form it could arrive in. Tears at the funeral would not have been the form. The song was."
    },
    {
     "kind": "Teaching",
     "text": "The frequency also has assumptions about what the person should be doing with the grief. Journaling. Therapy. Talking. Not talking. Taking time. Returning to work. Travelling. Not travelling. The frequency never settles on one answer, and every answer has a person ready to say it is the wrong one."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency in the shape of the guilt. Not the guilt of having done something wrong — the guilt of having grieved in a form that was not the expected one. The guilt is not about the grief. The guilt is about the departure from the permitted form."
    },
    {
     "kind": "Teaching",
     "text": "The form the grief takes is not a moral fact. It is what the person's particular nervous system, in this particular loss, at this particular age, is able to do. There is no correct form. There is only the form the grief chooses."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one moment where the form of your grief did not match the form you believed it should take. Not to change the form. To see that the mismatch was a frequency, not a failure."
    }
   ]
  },
  {
   "id": "m06",
   "label": "6 · The Grief That Arrives in the Body",
   "items": [
    {
     "kind": "Teaching",
     "text": "Grief is not only an emotional event. It is a bodily one too. It lives in the chest, the throat, the shoulders. It changes the breath. It changes sleep. It can affect appetite, energy and the body's resilience. The body that is grieving is doing something real, and it is doing it whether or not the person is aware of it."
    },
    {
     "kind": "Teaching",
     "text": "The frequency often treats the body's grief as a separate problem. The person notices they are exhausted, and the frequency treats the exhaustion as a failing — as if the grief were something that could be carried without the body being affected. The body is not a distraction from the grief. The body is the grief, in a form that can be felt."
    },
    {
     "kind": "Anecdote",
     "text": "A man's mother dies. For months, he has trouble breathing deeply. He assumes it is the stress. Then, one afternoon, sitting quietly, he notices that the sensation in his chest is exactly the sensation he had as a child when he was crying hard — that same tightness, that same half-breath. His body has been crying without him. It has been doing the thing he could not."
    },
    {
     "kind": "Teaching",
     "text": "The body knows how to grieve. It does not need to be told. When the person lets the body grieve — with rest, with sleep, with tears, with ordinary slowness — the grief moves through it differently than when the person forces the body to keep going."
    },
    {
     "kind": "Teaching",
     "text": "The frequency treats the body as a problem the person has to solve in order to grieve properly. The reverse is true. The body is the place the grief is happening. Care for the body is not separate from the grief. It is the grief, allowed to be physical."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency in the moments you push through the body's grief. The meeting you attend when you should have stayed in bed. The conversation you have when you should have been silent. The meal you eat when you should have rested. The frequency tells the person the body can wait. The body has not agreed."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one moment today when the body asked for something and the frequency overruled it. Not to give in. To see the overruling. The body had a reason for what it wanted."
    }
   ]
  },
  {
   "id": "m07",
   "label": "7 · The Grief That Was Not Yours",
   "items": [
    {
     "kind": "Teaching",
     "text": "Some grief is inherited. The person grieves a loss that happened before they were born. A parent's lost sibling. A grandparent's lost home. A family's lost country. The grief arrives already loaded, carried by the household, transmitted without a name."
    },
    {
     "kind": "Teaching",
     "text": "Inherited grief does not feel the same as personal grief. It does not have a clear object. The person feels a heaviness that has no obvious cause — a sadness about something, a missing of something, they cannot quite name. The frequency is running a grief that was never theirs to run, and the person is running it without knowing it."
    },
    {
     "kind": "Anecdote",
     "text": "A woman in her late twenties feels a persistent, low-grade grief she cannot explain. Nothing in her own life has been lost. Over time, through a family story told at a wedding, she begins to understand that her grandmother lost a young brother in a war, never spoke of it, and carried it for the rest of her life. The woman has been carrying it too. She was given it before she could refuse."
    },
    {
     "kind": "Teaching",
     "text": "The frequency in inherited grief is often the one that says: this is not yours to feel. The person senses that the grief is not about their own life, and the frequency uses that sensing as evidence that the grief should not be felt at all. But the grief is real. It is just not the person's own."
    },
    {
     "kind": "Teaching",
     "text": "Inherited grief is loosened, not by processing it, but by naming it. When the person can say 'this is my grandmother's grief, not mine' — even quietly, to themselves — the grief begins to move out of the body it has been living in."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise inherited grief by its specificity. The person's grief is about a particular kind of thing that has never actually happened to them. A fear of losing a sibling. A fear of war. A fear of an address being taken. When the loss is specific but has not happened, the grief is often inherited."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to consider whether one thing you carry might belong to someone else in your family. Not to solve it. Just to wonder where it came from."
    }
   ]
  },
  {
   "id": "m08",
   "label": "8 · The Grief of the Living",
   "items": [
    {
     "kind": "Teaching",
     "text": "Not all grief is for the dead. There is grief for the living — for the parent who is no longer themselves, the partner who has become a stranger, the child who has moved to a country that does not include you, the friendship that quietly ended without a funeral. The person is still here. The relationship is not. This grief has no public form."
    },
    {
     "kind": "Teaching",
     "text": "The grief of the living is often more difficult than the grief of the dead, because there is no ceremony. There is no card, no wake, no permission to be visibly changed. The person is still in the room, and the person's presence makes the grief feel like a betrayal — as if missing someone who is still alive were a form of ingratitude."
    },
    {
     "kind": "Anecdote",
     "text": "A man's father develops dementia in his late sixties. For eight years, the man visits every Sunday. He talks to his father. His father does not always know who he is. When his father dies, the man is quiet for a long time. Someone says, at the funeral, that at least the man has had time to prepare. The man wants to say: I started grieving eight years ago. The grief is not new. It is finishing."
    },
    {
     "kind": "Teaching",
     "text": "The frequency treats the grief of the living as premature. It says: they are still here, so you cannot grieve them. But grief for the living is not premature. It is exactly on time. The relationship ended when the person who was in it ended. The body did not. The body continued, and the grief continued, in a form the world has not yet learned to permit."
    },
    {
     "kind": "Teaching",
     "text": "The grief of the living is often the grief that arrives as anger. Anger at the illness, at the estrangement, at the distance, at the person themselves for changing. The anger is not a separate frequency. It is the grief, arriving in the only form the frequency allows it — because grief for a living person is not permitted to be grief."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise this grief by the shape of the questions people ask. When the person is asked how their parent is, how their partner is, how their estranged child is — and there is no truthful answer that fits into the space of the question. The person gives a small answer, and the grief of the living continues, unnamed."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to name, once, that you are grieving someone who is still alive. Not to the person. Not to anyone. Just to yourself. The naming does not solve anything. It simply stops the pretense."
    }
   ]
  },
  {
   "id": "m09",
   "label": "9 · The Anniversaries You Did Not Choose",
   "items": [
    {
     "kind": "Teaching",
     "text": "Grief has its own calendar. Not the calendar of the world — the calendar of the body. The person who has lost someone will find that the body knows the date before the mind does. The first of the month. The season. The hour. The song that was playing. The body keeps its own book, and it opens it on schedule."
    },
    {
     "kind": "Teaching",
     "text": "The frequency treats the anniversaries as a problem. It says: this should be easier by now. It says: it has been four years, why am I still like this in November. The frequency reads the body's calendar as evidence of failure. The body's calendar is not failure. It is memory, kept in a form that has no words."
    },
    {
     "kind": "Anecdote",
     "text": "A woman's daughter died in March. For years, every March, the woman felt a heaviness she could not explain until the date was near. Then she noticed: the early signs of March always found her first — the light changing, the daffodils, the particular cold of a Tuesday afternoon. The body was already grieving before she had remembered why. It was not a problem. It was the body remembering what the calendar only named."
    },
    {
     "kind": "Teaching",
     "text": "The anniversaries are not events the person chose. They are the shape of the loss itself. A loss has a date, a season, a weather. The body remembers the shape, and it opens the shape on schedule, sometimes without the person having noticed the day was approaching."
    },
    {
     "kind": "Teaching",
     "text": "The frequency often wants the anniversaries to stop. It reads them as unfinished business. They are not unfinished. They are the shape of a life that has been permanently changed. The date will keep returning, and the body will keep responding to it, for as long as the person lives. This is not a problem to be solved. It is a fact about love."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency in the surprise at the anniversary's arrival. The person is caught off guard by their own body's response, and then the frequency says: what is wrong with me. Nothing is wrong. The body is doing what it has always done, and what it will keep doing."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to let one anniversary arrive without turning it into a test. Not to make it beautiful. Not to make it meaningful. Just to let the date be what it is, without the frequency scoring your response."
    }
   ]
  },
  {
   "id": "m10",
   "label": "10 · When the Grief Changes Shape",
   "items": [
    {
     "kind": "Teaching",
     "text": "Grief does not stay the same. It changes shape. The early grief is often large and loud — a flood. The middle grief is quieter — a constant background. The later grief is strange — sudden, specific, arriving in the most ordinary moments, and often missing entirely for months at a time before returning without warning."
    },
    {
     "kind": "Teaching",
     "text": "The frequency does not accept the change in shape. It treats each new form as a failure of the previous work. When the flood becomes a background, the frequency says: this is not dealing with it. When the background becomes a return, the frequency says: I thought I was past this. The frequency is waiting for a final form, and the final form does not exist."
    },
    {
     "kind": "Anecdote",
     "text": "A man's wife dies when he is in his fifties. For two years, the grief is the loudest thing in his life. In the third year, it becomes quieter. In the fifth, he goes a whole month without thinking about her, and is suddenly ashamed. He mentions this to a friend who has also lost a partner. The friend says, kindly: the month is not forgetting. The month is the grief learning how to be a companion instead of a weather system."
    },
    {
     "kind": "Teaching",
     "text": "The changed grief is not the decreased grief. The changed grief is the grief that has learned to live in the person instead of on top of them. The love is unchanged. The form the love takes is different, because the life it lives in is different."
    },
    {
     "kind": "Teaching",
     "text": "The frequency also has trouble with the moments when the grief is missing. The person notices they have not thought about the loss for a week, and the frequency treats the absence as infidelity. The absence is not infidelity. The absence is the shape of the life the person is still living."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency in the impulse to summon the grief back when it has been quiet. The person does not need to summon it. The grief will return when it returns. The summoning is the frequency, insisting the grief prove its ongoing presence."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to let one quiet stretch pass without checking on the grief. Not to celebrate the quiet. Not to fear it. Just to let the quiet be what it is, without the frequency turning it into a question."
    }
   ]
  },
  {
   "id": "m11",
   "label": "11 · The Grief You Are Still In",
   "items": [
    {
     "kind": "Teaching",
     "text": "There comes a moment in the loosening of the grief frequency when the person realises, quietly, that they are still grieving. Not that they have been unable to stop. Not that they have failed to move on. Simply that the grief is still here, in whatever form it has taken, and the frequency is no longer insisting that this is a problem."
    },
    {
     "kind": "Teaching",
     "text": "This is the reversal. It is not the ending of the grief. It is the ending of the frequency's narration of the grief. The grief continues, exactly as it always was. The commentary about the grief does not."
    },
    {
     "kind": "Anecdote",
     "text": "A woman is in her late sixties. Her husband died thirty years ago. She has built a life. She has been happy. And every year, on the anniversary, she takes the day off work, walks to a particular bench, and sits there for an hour. She does not cry. She does not perform the grief. She simply sits. For thirty years. She has never once told anyone what the day means. She has never needed to. The grief is hers, and the frequency is silent."
    },
    {
     "kind": "Teaching",
     "text": "The grief that has been given room to be what it is stops being a burden and becomes a companion. It is still present. It is still sometimes heavy. But it is no longer accompanied by the running commentary that made it feel like a problem."
    },
    {
     "kind": "Teaching",
     "text": "You will know the frequency is loosening when the grief can arrive in an ordinary moment — a smell, a song, an hour of the afternoon — and the person does not immediately move into narration. The grief simply arrives, is felt, and moves on. The frequency has nothing to add."
    },
    {
     "kind": "Teaching",
     "text": "The grief does not have to be resolved. It has to be permitted. The frequency has been the thing preventing permission. When the frequency loosens, the permission arrives, and the grief becomes something a person can carry without it being something a person has to defend."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to let one moment of grief arrive without narrating it. Not to feel it less. Not to feel it more. Just to feel it, and let it move, and let the frequency stay silent."
    }
   ]
  },
  {
   "id": "m12",
   "label": "12 · Recalibrating",
   "items": [
    {
     "kind": "Teaching",
     "text": "The recalibration of the grief frequency is not the completion of grief. It is not the ending of missing, or the achievement of closure, or the arrival at a place where the loss no longer hurts. It is the slow, patient practice of letting the grief be what it is — without the frequency insisting it should be something else."
    },
    {
     "kind": "Teaching",
     "text": "The grief frequency does not disappear. It has been installed since childhood, by a culture that has a timeline and a form and an appropriate end. It will return in the moments of new loss, in the anniversaries, in the presence of someone else's grief. What changes is that the person can see it running, and can choose not to obey it."
    },
    {
     "kind": "Anecdote",
     "text": "Two people lose the same parent in the same year. One spends the following decade trying to finish the grief — reading the right books, doing the right work, arriving at the right resolution. The other, more quietly, simply keeps the parent present, keeps the grief present, keeps the love present, without a story about how any of it is supposed to go. Ten years later, the first has run out of things to do to the grief. The second has been living with it, the whole time, without needing it to be finished."
    },
    {
     "kind": "Teaching",
     "text": "You will know the frequency is loosening when the grief is no longer being watched. When the person does not check on it. When a wave of missing arrives and the first thought is not 'is this normal?' but simply the missing itself. The narration has stopped. The grief has not."
    },
    {
     "kind": "Teaching",
     "text": "The grief frequency is one of the deepest sectors in this course, because the loss is not a problem to be solved — it is a fact about the person's life that has permanently rearranged it. The frequency has been trying to make the loss into a task. The loss is not a task. The loss is a love that no longer has anywhere to land."
    },
    {
     "kind": "Teaching",
     "text": "You were not born with a timeline. You were given one. The people who gave it to you were given one before that, by people who were told that grief is something to move through, rather than something to carry. The timeline is a chain that can be set down. Not because the grief is done. Because the grief is allowed to stay."
    },
    {
     "kind": "Recalibration",
     "text": "The same loss. The same love. Two different relationships to how long it takes to feel it. You have just read an entire sector about the space between them. That space is the whole of this course — and, in grief, it is the space where the person stops managing the loss and starts simply having it."
    }
   ]
  }
 ]
};
