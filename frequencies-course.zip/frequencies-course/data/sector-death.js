window.FREQ_SECTOR={
 "key": "death",
 "title": "Death",
 "glyph": "✜",
 "blurb": "The deepest frequency, and one that quietly shapes a great deal. Not a course about dying — a course about what changes when the fear of it is seen.",
 "philTitle": "Death · The Fear Frequency & The Reversal",
 "philText": "Death is not the problem. The frequency that runs from it is the problem. This sector is not about grief, or about dying — it is about the deepest and quietest frequency of them all: the one that runs underneath every other sector, keeping a person busy, small, and slightly ahead of themselves in order to avoid the fact of their own ending. It is about the moment the fact is met — not overcome, not resolved, but met — and what opens when the running finally stops.",
 "modules": [
  {
   "id": "m01",
   "label": "1 · The One You Do Not Talk About",
   "items": [
    {
     "kind": "Teaching",
     "text": "There is a fact about every life that most modern societies have agreed, quietly, not to talk about. Not because the fact is unclear — the fact is perfectly clear — but because the conversation has been removed from ordinary life. Death, once a neighbour of the household, has become a specialist subject, discussed in hospitals, in funeral parlours, and rarely anywhere else."
    },
    {
     "kind": "Teaching",
     "text": "The removal is not an accident. It is a frequency. A society that does not talk about death is running one of the deepest frequencies there is — the frequency of distraction from the fact of ending. And every person raised inside that society absorbs it before they can question it."
    },
    {
     "kind": "Anecdote",
     "text": "A man reaches sixty and realises he has been to exactly four funerals, and each one involved someone over eighty. He has never seen a peer die. He has never sat with a dying person. The fact of death has been quietly edited out of his life by the arrangements of the world he lives in, and he is only now noticing the editing."
    },
    {
     "kind": "Teaching",
     "text": "This absence is important to name at the start of this sector, because the death frequency does not look like fear. It looks like the absence of a subject. The person is not afraid of death. The person simply never thinks about it — because the world has built a life that does not require them to."
    },
    {
     "kind": "Teaching",
     "text": "And underneath that absence, the frequency still runs. It runs in the way the person avoids the topic when it comes up. It runs in the small internal flinch at a funeral. It runs in the sudden, unexpected feeling at three in the morning, in a dark room, which the person quickly distracts themselves from. The frequency is not conscious. It does not need to be."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency by the shape of the silence. When someone in a room mentions death, what happens? A change of subject? A joke? A very quick, careful reply? That small manoeuvre is the frequency, running silently, in a room full of people who would all say, if asked, that they are not afraid."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal begins with a small honesty: when did you last think, actually think, about your own ending? Not a passing thought — an actual consideration. You do not need to answer deeply. Just notice how long it has been."
    }
   ]
  },
  {
   "id": "m02",
   "label": "2 · The Endless Deferral",
   "items": [
    {
     "kind": "Teaching",
     "text": "Most lives are organised around a quiet assumption: that the important things can be done later. The person intends to see more of their friends, to repair the estranged relationship, to visit the place they have always wanted to see, to live more slowly, to say what needs to be said. The intention is sincere. The intention is also deferred, indefinitely, without the person noticing."
    },
    {
     "kind": "Teaching",
     "text": "The deferral is the death frequency in its most ordinary form. It is not a dramatic denial. It is a small, continuous redistribution of life into the future — a redistribution the frequency requires, because if the person actually lived as though the time were finite, they would have to change a great deal of their life, immediately."
    },
    {
     "kind": "Anecdote",
     "text": "A man in his fifties has a sister he has not spoken to in eleven years, over an argument neither of them can now remember. Every year he intends to write to her. Every year he does not, because there is time. He is not aware of the assumption. He is aware only of a small, habitual postponement, which feels reasonable, and which has now lasted for a fifth of his adult life."
    },
    {
     "kind": "Teaching",
     "text": "The endless deferral is not laziness. It is a strategy — usually unconscious — for managing the discomfort of finitude. If the person believes there is enough time, they do not have to face the question of how they are actually spending it. The deferral is not the failure to act. The deferral is the way of not needing to."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the deferral by its vocabulary. 'One day.' 'Soon.' 'When things calm down.' 'When I have more time.' Each of these phrases is a small piece of the frequency, doing its work, moving the life into a future that has not been promised."
    },
    {
     "kind": "Teaching",
     "text": "The person running the frequency does not experience themselves as avoiding life. They experience themselves as busy, sensible, and responsible. The deferral is hidden inside the ordinary competence of the day. Only when the person actually stops — on a holiday, at a funeral, in an unexpected moment — do they notice what has been postponed."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is not to solve the deferral all at once. It is to name one thing you have been postponing, and to notice how long the postponement has actually been. Not to act yet. Just to see."
    }
   ]
  },
  {
   "id": "m03",
   "label": "3 · The Life You Would Live If",
   "items": [
    {
     "kind": "Teaching",
     "text": "If a person knew, with certainty, that they had one year left, they would almost always describe a life different from the one they are currently living. The differences vary, but the shape of the differences is remarkably consistent. More time with the people they love. Less time doing what they do not. Less worry. More presence. A different balance."
    },
    {
     "kind": "Teaching",
     "text": "This is one of the frequency's clearest diagnostics. The gap between the life a person is living and the life they would live if they knew the time were short is the exact shape of the death frequency. The frequency fills the gap with postponement. The actual ending would dissolve the postponement immediately."
    },
    {
     "kind": "Anecdote",
     "text": "A woman is asked, in a workshop, what she would do differently if she had a year to live. She answers without hesitation: she would quit her job, move closer to her sister, and stop worrying about money. She has known these answers for years. She has never once acted on any of them. The knowing has not been the problem. The frequency is the problem."
    },
    {
     "kind": "Teaching",
     "text": "People often hear this observation and assume it is a call to dramatic change. It is not. The point is not that the person should immediately quit their life and adopt the alternative. The point is to see that the two lives — the current life and the if-a-year life — are being kept separate by the frequency, and that the separation is not necessary."
    },
    {
     "kind": "Teaching",
     "text": "Most people cannot make the full change. But almost every person can close the gap slightly. A few more hours with the people they love. A few fewer hours doing what they do not. Slightly less worry about money. The direction is available. The frequency has simply been telling the person that the direction is not available yet."
    },
    {
     "kind": "Teaching",
     "text": "The person who has begun to loosen the death frequency often lives, in ordinary respects, much the same life as before. They still work. They still worry. They still have the same family and the same friends. The difference is that they have stopped pretending there will be a better moment to get around to the life they actually want. They are living that life slightly more, now, in the time they actually have."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is not to change your life this week. It is to write down, quietly, one thing the if-a-year version of you would do differently, and to see whether that thing can be done at 5% scale this month."
    }
   ]
  },
  {
   "id": "m04",
   "label": "4 · The Fear of Death Is Not the Only Fear",
   "items": [
    {
     "kind": "Teaching",
     "text": "When people say they are afraid of death, they are usually afraid of something more specific. Not the ending itself, which is nothing to experience, but one of a set of related fears: the fear of being forgotten, the fear of not having mattered, the fear of an unattended ending, the fear of pain, the fear of the unknown, the fear of leaving someone behind."
    },
    {
     "kind": "Teaching",
     "text": "The frequency uses the general word — death — to hide the specific fears. The specific fears are harder to look at. If a person is afraid of being forgotten, that is a specific, addressable fear. If they are simply afraid of death, that is a vague, unfocusable fear that can never be resolved. The frequency prefers the vague version."
    },
    {
     "kind": "Anecdote",
     "text": "A man realises, in his sixties, that what he calls his fear of death is actually a fear of not having been important. He has spent his whole working life trying to leave a mark, and the frequency has been telling him the mark is the way to face the ending. Once he sees this, the fear of death itself becomes much smaller. What remains is a specific concern, which can be thought about, and partly resolved, and partly made peace with."
    },
    {
     "kind": "Teaching",
     "text": "Many of the other sectors in this course are actually expressions of a specific fear inside the death frequency. Money is sometimes the fear of being unable to protect against the ending. Work is sometimes the fear of not mattering before the ending. Body is sometimes the fear that the body will give out. Time is the direct expression of the ending, filtered through a life that cannot bear to feel it."
    },
    {
     "kind": "Teaching",
     "text": "This is one of the ways the death sector differs from the others. It is not just another frequency alongside them. It is the ground beneath them. Loosening the death frequency tends to loosen the others, not because they are the same, but because they have been running on the same underlying avoidance."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the specific fear underneath by the shape of the distraction. What is the person doing, with unusual intensity, when they are most clearly not thinking about death? What are they achieving, defending, gathering, keeping? The activity is often the specific fear, looking for a solution it will not find."
    },
    {
     "kind": "Teaching",
     "text": "The specific fear does not always disappear when it is named. But it becomes smaller, more tangible, more able to be lived alongside. The person can carry a specific fear. The person cannot carry a general one, because it has no edges to hold."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to ask, quietly: if I am afraid of death, what specifically am I afraid of? Not to solve it. Just to shrink the fog into a shape that can be looked at."
    }
   ]
  },
  {
   "id": "m05",
   "label": "5 · The Deaths That Already Happened",
   "items": [
    {
     "kind": "Teaching",
     "text": "The death frequency is not only about the person's own ending. It is also about the endings that have already happened in their life. The friends, family, and loves who have died. The marriages that ended. The friendships that ended. The versions of the person themselves that have ended and cannot be returned to. All of these are deaths, and all of them run through the frequency."
    },
    {
     "kind": "Teaching",
     "text": "Modern life has a strange relationship with these deaths. It expects them to be processed, resolved, moved past. Grief is expected to have a timeline. A year. Two years. Then a return to normal. This expectation is not from human nature. It is from the frequency — the frequency of not letting endings be what they are."
    },
    {
     "kind": "Anecdote",
     "text": "A woman's father died twenty-two years ago. She has never once mentioned his name without a pause. She is not still grieving, exactly. She is still carrying something that has not had the room to be set down. The frequency has been telling her, for two decades, that there is something strange about still missing him. There is not. There is only an ending that was real, and continues to be real, and was never given the full room it needed."
    },
    {
     "kind": "Teaching",
     "text": "One of the deepest moves of the death frequency is the belief that endings must be resolved. That after a certain amount of time, the ending should have softened, and if it has not, something must be wrong. Nothing is wrong. Endings are not meant to be resolved. They are meant to be lived alongside, for as long as the person has left."
    },
    {
     "kind": "Teaching",
     "text": "This is not a sadder view of grief. It is a lighter one. It removes the pressure to have gotten over something that does not need to be gotten over. The person can miss the ending for the rest of their life, and that is not a problem. That is the shape love takes when the person loved is no longer here."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency's intrusion into grief by the presence of a low-grade guilt. The feeling that one has grieved for too long, or in the wrong way, or not enough. The guilt is not the grief. The guilt is the frequency, imposing a schedule on something that does not follow one."
    },
    {
     "kind": "Teaching",
     "text": "The smaller endings also count. The friendship that faded. The version of the person before the illness. The version of the person before the marriage. These endings rarely get marked, and are rarely given room, and yet they are a quiet constant underneath the person's life."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to name one ending that has never been given a full room — a person, a relationship, a version of yourself. Not to process it. To let it have been an ending."
    }
   ]
  },
  {
   "id": "m06",
   "label": "6 · What Death Actually Does to a Room",
   "items": [
    {
     "kind": "Teaching",
     "text": "When a death happens in a family, a friendship group, or a small community, the frequency of the group changes shape. The absence is not just a missing person. It is a live thing in the room. The remaining members often feel the person's frequency moving between them — some carrying part of it, some refusing it, some disappearing into it."
    },
    {
     "kind": "Teaching",
     "text": "The frequency of a group that has lost someone becomes a shared, unspoken broadcast. Some members quietly agree to keep the person's frequency alive in the group. Others quietly withdraw. The room re-shapes itself around an absence that is more present than the people in it."
    },
    {
     "kind": "Anecdote",
     "text": "After a family matriarch dies, the family stops having Christmas together. No one decides this. The decision is made by the frequency — the frequency that could not function without the person who had been holding the room's warmth. Two years later, one of the children begins hosting Christmas again, clumsily, without the matriarch. The room comes back into shape, different, smaller, but alive."
    },
    {
     "kind": "Teaching",
     "text": "The death frequency in a group is often harder to see than the frequency in an individual, because it hides in the ordinary arrangements. Who now does the thing the dead person used to do? Who now carries the tone? Who has been quietly missing from the gatherings? The frequency of the room answers these questions without anyone naming them."
    },
    {
     "kind": "Teaching",
     "text": "This is one of the ways the sector is different from the others. The death frequency is not only a private matter. It is also a shared one. A family, a friendship group, a workplace, a community — each of these can be running a frequency that is being organised around a loss the room has never fully acknowledged."
    },
    {
     "kind": "Teaching",
     "text": "You can often feel this as an adult when returning to a family or a group. Something in the room is being done on behalf of someone who is no longer there. Once the person notices this, they can choose whether to keep carrying the piece, or to hand it back. Both are legitimate. The choice is what matters — the noticing is what makes the choice available."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal, in this module, is not to fix the group. It is to notice that the group's frequency has been shaped by an absence — and to be able to hold that with the group rather than for it."
    }
   ]
  },
  {
   "id": "m07",
   "label": "7 · The Peace That Is Not Resignation",
   "items": [
    {
     "kind": "Teaching",
     "text": "Making peace with death is one of the most misunderstood ideas in modern life. It is often confused with resignation — with giving up, with a quiet despair, with a withdrawal from life. This is not what it is. The peace that is not resignation is a stronger, stranger, more alive state than the frequency can imagine."
    },
    {
     "kind": "Teaching",
     "text": "The person who has made peace with their ending is not less engaged with life. They are usually more engaged. They have stopped wasting energy on the small denial that the frequency requires. They have stopped hedging. They have begun to spend themselves — on the people they love, on the work they care about, on the daily texture of an actual life."
    },
    {
     "kind": "Anecdote",
     "text": "A man who has survived a serious illness describes the year afterwards as the most vivid year of his life. He had assumed it would be a year of fear. It was instead a year of detail — of noticing the taste of food, the texture of a conversation, the colour of the sky at a specific hour. He is not more brave than other people. He has simply stopped running from something, and the running had been taking a great deal of his attention."
    },
    {
     "kind": "Teaching",
     "text": "The peace with death is not a belief that death is good. It is not a philosophy that death is fine. It is the direct, lived recognition that death is — that it is a fact of the person's life, and that the fact makes the life sharper rather than softer. The sting is not removed. The sting is what makes the honey worth something."
    },
    {
     "kind": "Teaching",
     "text": "People who have made peace with the ending often describe a specific quality of presence. They are not less ambitious. They are not less committed. They are simply less likely to be somewhere else when they are somewhere. The frequency no longer needs to move them. There is nothing to run from."
    },
    {
     "kind": "Teaching",
     "text": "The peace does not arrive once and stay. It arrives, and then the frequency returns, and then it arrives again. The person who has made peace with death is not someone who is permanently at peace. They are someone who returns more quickly to the peace each time the frequency comes back."
    },
    {
     "kind": "Teaching",
     "text": "You will know this peace by its texture. It is not solemn. It is not heavy. It is not a state that asks anything of the room. It is a quietness in a person that makes the ordinary moment slightly more real, and slightly more worth attending to, than it was before."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is not to feel peaceful about death. It is to notice that the fear of death has, in fact, been shaping a great deal of your daily attention — and that the attention has somewhere else it could go."
    }
   ]
  },
  {
   "id": "m08",
   "label": "8 · The People Who Are Not Afraid",
   "items": [
    {
     "kind": "Teaching",
     "text": "Everyone running the death frequency assumes that everyone else is running it too. The frequency hides behind the appearance of universality. It says: of course everyone is afraid of death, that is simply what it is to be human. The statement is half true and half convenient."
    },
    {
     "kind": "Teaching",
     "text": "In every community, every era, every family, there have been people who were not afraid of their own ending. Not in denial, not in bravado, but in a settled, quiet sense that the ending is a fact, and that the fact is not the enemy. These people are not a different species. They are simply not running this particular frequency."
    },
    {
     "kind": "Anecdote",
     "text": "A woman sits with her grandmother, who is in her last months. The grandmother is peaceful in a way the woman has never seen in another person. She talks about her own ending the way she talks about the weather — as a fact of the day, ordinary, real, not a drama. The woman realises, sitting there, that she has been told her whole life that this peace is not possible. It is possible. She is looking at it."
    },
    {
     "kind": "Teaching",
     "text": "The person who is not afraid of death is often not exceptional in any other way. They may have run every other frequency in this course. They may be anxious about money, restless about work, self-conscious about the body. The absence of the death frequency does not mean the absence of every other frequency. It means this one, in this person, is not running hard."
    },
    {
     "kind": "Teaching",
     "text": "These people are the greatest available teachers of this sector, because they demonstrate that the frequency is not required. The person has not overcome anything. They simply never installed the fear — or they installed it, and then set it down, often quietly, often without ceremony, often in the middle of an ordinary afternoon."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise these people by the quality of their attention to ordinary things. They are often more interested in a cup of tea, or a friend's small news, or a plant in the garden, than in the metaphysics of the ending. The interest is not a distraction from the ending. It is the direct expression of not being run by it."
    },
    {
     "kind": "Teaching",
     "text": "You will also recognise them by the way others are around them. In the presence of someone who is not running this frequency, other people often feel a strange quietness in themselves — a temporary pause in a running they did not know they were doing. That pause is a small window onto a way of being the person could, over time, adopt."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to remember one person you have met who was not afraid, and to notice that the fear has been, all along, optional."
    }
   ]
  },
  {
   "id": "m09",
   "label": "9 · The Last Days You Will Not Have",
   "items": [
    {
     "kind": "Teaching",
     "text": "Most people imagine their own ending as a moment. A dramatic final scene, in old age, surrounded by family, with the important things already said and the accounts already settled. This imagined ending is almost always false. Most endings are quieter, messier, more ordinary, and less complete than the frequency allows the person to imagine."
    },
    {
     "kind": "Teaching",
     "text": "The imagined ending is not a coincidence. It is one of the ways the frequency keeps the person in the endless deferral. If the ending is imagined as a clean, settled final scene, then the person can imagine there is time to settle things. The imagined ending is a small promise that the frequency makes and never intends to keep."
    },
    {
     "kind": "Anecdote",
     "text": "A man's father dies suddenly at sixty-four, without saying goodbye, in the middle of a Tuesday. There had been no final scene. There had been no settled accounts. There had been a phone call three days earlier about something trivial, and then nothing. The man spends a decade learning that this is how it almost always happens. He had been waiting for a final scene that his father did not get to have."
    },
    {
     "kind": "Teaching",
     "text": "The most useful response to this realisation is not to become frightened. It is to become accurate. If the ending will probably not arrive with a final scene, then the scenes that matter are the ones that are happening now. The conversations that matter are the ones that can happen this week. The truth that needs to be said needs to be said in the ordinary sequence, not saved for a better moment that may not come."
    },
    {
     "kind": "Teaching",
     "text": "This is not a call to panic. It is a call to stop outsourcing the important things to an ending that will almost certainly not be able to hold them. The ending cannot be relied on to organise the life. The life has to organise itself, in the ordinary days, now."
    },
    {
     "kind": "Teaching",
     "text": "People who have been present at an actual death often describe how ordinary the moment was. The person was there. The person was themselves. The room was a room. There was nothing about it that resembled the scene the frequency had been preparing for. What mattered, in the end, was not the final scene. It was the accumulation of ordinary moments that had come before."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one thing you have been saving for a later moment. Not to say it, or do it, immediately. Just to see that it has been waiting for an ending that will not organise itself."
    }
   ]
  },
  {
   "id": "m10",
   "label": "10 · The Life That Continues",
   "items": [
    {
     "kind": "Teaching",
     "text": "The death frequency is not only about what ends. It is also about what continues. Every person is part of a chain that arrived before them and will continue after them. The gestures, the words, the choices, the small affections — these are passed on in ways the person rarely sees and cannot control."
    },
    {
     "kind": "Teaching",
     "text": "Many people running the frequency do not fully feel this. They experience their life as a private project with a private ending, and the ending looks like a wipe rather than a handover. The frequency does not permit the more accurate view — that the person is a moment in a long transmission, and that the transmission is what continues, and that this is not a small consolation but a large one."
    },
    {
     "kind": "Anecdote",
     "text": "A man realises, in his seventies, that his granddaughter uses a phrase he inherited from his own grandmother. The phrase is small, colloquial, and entirely by accident. It has skipped two generations and arrived in a child he will not see grow up. He does not tell her where it came from. He simply notices, quietly, that something of him is now in her, and will be in someone else, and so on, in a way the frequency could not have imagined."
    },
    {
     "kind": "Teaching",
     "text": "The continuing is not only genetic. It is in the way the person has treated other people, which other people will in turn pass on. It is in the small things the person has made or said or shaped. It is in the household habits, the recipes, the ways of holding a conversation, the opinions, the jokes, the gestures of care."
    },
    {
     "kind": "Teaching",
     "text": "The person's continued presence in the world is not a metaphor. It is a fact. The person is already inside the lives of the people they have touched, and the touching does not stop at the moment of the ending. This is one of the few places where the modern frequency and the older traditions disagree, and the older traditions have the more accurate view."
    },
    {
     "kind": "Teaching",
     "text": "This does not erase the grief of endings. It sits alongside the grief. The person can be gone and also here. The person can have ended and also continued. Both are true. The frequency has been insisting on only one of them."
    },
    {
     "kind": "Teaching",
     "text": "You will recognise the frequency's hold by the discomfort you feel when someone says you will live on in your children, or in your work, or in the people you have taught. The discomfort is not because the statement is wrong. The discomfort is because the frequency has been insisting the person is a private project with a private ending, and the statement quietly disagrees."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to notice one thing that has already been passed from you into someone else — a phrase, a habit, a way of doing something. Not to celebrate it. Just to know it."
    }
   ]
  },
  {
   "id": "m11",
   "label": "11 · Recognising the Run",
   "items": [
    {
     "kind": "Teaching",
     "text": "The death frequency has a signature — not in the moments when death is mentioned, but in the ordinary moments of a day. It is visible in the small, quiet, unremembered choices that keep the person slightly ahead of themselves. The extra email. The extra task. The slightly rushed conversation. The refusal to sit still."
    },
    {
     "kind": "Teaching",
     "text": "Learn the signature. It is not a single moment. It is a texture. The frequency is running whenever the person is not quite able to be in the room they are actually in. Whenever the attention is on the next thing. Whenever the present moment feels slightly too thin to rest in."
    },
    {
     "kind": "Anecdote",
     "text": "A man begins to notice that he cannot be fully still for more than a few minutes at a time. He is retired. He has no deadlines. And yet the internal movement continues — a small, continuous pull to check something, adjust something, do one more thing. He has been doing this all his life. He realises, at seventy, that the movement was not about any of the things he was moving towards. The movement was about avoiding a stillness in which the ending would be visible."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is loudest in the moments of true stillness: a bath, a garden, a long walk with no purpose, a quiet evening. These are the moments the frequency most resists, because these are the moments the deeper fact of the person's life becomes perceptible."
    },
    {
     "kind": "Teaching",
     "text": "The frequency is also visible in the way the person responds to endings — endings of relationships, endings of jobs, endings of phases of life. If the person immediately begins a new project, a new relationship, a new job without a beat of transition, the frequency is running. The beat was refused."
    },
    {
     "kind": "Teaching",
     "text": "You will know the frequency is loosening when you can be in a bath, or a garden, or a quiet evening, without the small internal movement. When the stillness has become habitable. When the running has slowed enough that the deeper fact can appear without panic."
    },
    {
     "kind": "Recalibration",
     "text": "The reversal is to sit still, once this week, for ten minutes, with nothing to distract you, and see what arrives. The arrival is the beginning."
    }
   ]
  },
  {
   "id": "m12",
   "label": "12 · Recalibrating",
   "items": [
    {
     "kind": "Teaching",
     "text": "The recalibration of the death frequency is not the achievement of fearlessness. It is not the removal of the sadness about endings, or the end of the wish for more time. It is the slow, patient practice of living as though the ending is real — because it is — and discovering that the life becomes not smaller but larger."
    },
    {
     "kind": "Teaching",
     "text": "The frequency does not disappear. It has been running since before the person could speak, installed by a culture that has been installing it for centuries. It will return in hospitals, in funerals, in the middle of a Tuesday afternoon. What changes is that the person can see it running, and can meet the fact instead of running from it."
    },
    {
     "kind": "Anecdote",
     "text": "Two people reach the end of their lives at the same age, with similar lives, and with similar families around them. One is still, at the very end, running the frequency — still slightly ahead of the moment, still managing, still arranging. The other, arrived at the same ending, has stopped. Not because the ending is easier. Because the running has stopped, and what is left is a person, present, in the ordinary fact of a life that is completing itself. Both have lived similar lives. One of them has lived them."
    },
    {
     "kind": "Teaching",
     "text": "You will know the frequency is shifting when you can be in an ordinary moment — a meal, a walk, a conversation — and feel, quietly, that this is what it is. Not a preliminary. Not a step. Not a wait. The thing itself. The ending has not happened. The life is happening. They are the same thing."
    },
    {
     "kind": "Teaching",
     "text": "The death frequency is the deepest sector in this course, because it is the one underneath all the others. Money, Work, Body, Time, Belonging, Love — all of them are, in some way, running on a single, shared, quiet fact: that the person will not be here forever, and has not been able to feel it. Loosening this frequency does not fix the others. But it changes the ground they are standing on."
    },
    {
     "kind": "Teaching",
     "text": "You were not born afraid of dying. You were handed the fear, from a world that had itself been running from the fact for a long time. The fear is not a truth about existence. It is a transmission, and transmissions can be set down. What is left when the fear is set down is not the absence of meaning. It is the presence of meaning — the sharp, ordinary, unmistakable meaning of a life that has been given, once, and is currently being lived."
    },
    {
     "kind": "Recalibration",
     "text": "The same life. The same ending. Two different frequencies. You have just read the final sector of this course — the ground underneath all the others. That ground is what the whole course has been standing on. And the space between the two frequencies is where you finally stop running from the life you are actually in."
    }
   ]
  }
 ]
};
