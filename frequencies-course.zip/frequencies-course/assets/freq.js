window.FREQ_SECTORS=[{"key":"money","title":"Money","glyph":"◈"},{"key":"love","title":"Love","glyph":"✧"},{"key":"health","title":"Health","glyph":"◇"},{"key":"work","title":"Work","glyph":"✦"},{"key":"family","title":"Family","glyph":"❖"},{"key":"belief","title":"Belief","glyph":"✶"},{"key":"voice","title":"Voice","glyph":"◉"},{"key":"power","title":"Power","glyph":"◆"},{"key":"body","title":"Body","glyph":"◐"},{"key":"time","title":"Time","glyph":"◔"},{"key":"belonging","title":"Belonging","glyph":"◍"},{"key":"death","title":"Death","glyph":"✜"},{"key":"grief","title":"Grief","glyph":"◑"},{"key":"anger","title":"Anger","glyph":"◒"},{"key":"creativity","title":"Creativity","glyph":"◓"},{"key":"solitude","title":"Solitude","glyph":"◕"},{"key":"desire","title":"Desire","glyph":"☾"},{"key":"trust","title":"Trust","glyph":"☽"},{"key":"status","title":"Status","glyph":"❂"},{"key":"feeling","title":"Feeling","glyph":"❁"}];
(function(){
"use strict";
var S = window.FREQ_SECTOR;
if(!S){ return; }
var MODULES = S.modules;
var SECTORS = window.FREQ_SECTORS;
var KIND_LABEL = { Teaching:'Teaching', Anecdote:'Illustration (composite)', Recalibration:'Recalibration' };
function $(id){ return document.getElementById(id); }

var currentModuleIdx = 0, currentItemIdx = 0, openModules = {};
var isReading = false, autoMode = false, ambientOn = false, ambientCtx = null, ambientNodes = null;
var readGen = 0, keepAlive = [], nextTimer = null;
var STORAGE_KEY = 'freq-narration-prefs-v1';
var prefs = { voice:'', pace:'normal', ambient:false, auto:false };

function loadPrefs(){
  try{
    var raw = localStorage.getItem(STORAGE_KEY);
    if(raw){
      var p = JSON.parse(raw);
      if(p && typeof p === 'object'){
        if(typeof p.voice === 'string') prefs.voice = p.voice;
        if(typeof p.pace === 'string') prefs.pace = p.pace;
        prefs.ambient = p.ambient === true;
        prefs.auto = p.auto === true;
      }
    }
  }catch(e){}
}
function savePrefs(){ try{ localStorage.setItem(STORAGE_KEY, JSON.stringify(prefs)); }catch(e){} }

/* ---------- sector links ---------- */
function renderSectorLinks(){
  var wrap = $('sectorLinks'); if(!wrap) return;
  wrap.innerHTML = '';
  SECTORS.forEach(function(s){
    var el;
    if(s.key === S.key){ el = document.createElement('span'); el.className = 'sector-link current'; }
    else { el = document.createElement('a'); el.className = 'sector-link'; el.href = 'freq-' + s.key + '.html'; }
    el.innerHTML = '<span class="g">' + s.glyph + '</span>' + s.title;
    wrap.appendChild(el);
  });
}

/* ---------- voices ---------- */
var CURATED_US = ['samantha','alex','ava','allison','susan','tom','nicky','aaron','fred','kathy','vicki','victoria','google us english','microsoft aria','microsoft guy','microsoft jenny','zira','david','mark','aria','guy','jenny'];
var CURATED_UK = ['daniel','serena','kate','oliver','stephanie','moira','tessa','fiona','rishi','google uk english female','google uk english male','microsoft libby','microsoft ryan','microsoft sonia','hazel','george'];
function voiceMatches(v, list){ var n = (v.name||'').toLowerCase(); for(var i=0;i<list.length;i++){ if(n.indexOf(list[i]) !== -1) return true; } return false; }
function isEnglish(v){ var l = (v.lang||'').toLowerCase(); return l === 'en' || l.indexOf('en-') === 0 || l.indexOf('en_') === 0; }
function isUK(v){ var l = (v.lang||'').toLowerCase(); return l.indexOf('gb') !== -1 || l.indexOf('uk') !== -1; }
function paceToRate(){ return prefs.pace === 'slow' ? 0.72 : (prefs.pace === 'brisk' ? 1.05 : 0.88); }

function populateVoices(){
  var sel = $('voiceSelect'); if(!sel) return;
  if(!('speechSynthesis' in window)){ sel.disabled = true; return; }
  var voices = window.speechSynthesis.getVoices() || [];
  if(!voices.length) return;
  var current = prefs.voice || sel.value || '';
  var matches = voices.filter(function(v){ return isEnglish(v) && (voiceMatches(v, CURATED_US) || voiceMatches(v, CURATED_UK)); });
  if(!matches.length) matches = voices.filter(isEnglish);
  matches.sort(function(a,b){ if(isUK(a) !== isUK(b)) return isUK(a) ? 1 : -1; return (a.name||'').localeCompare(b.name||''); });
  sel.innerHTML = '<option value="">Default</option>';
  var groups = {};
  matches.forEach(function(v){
    var g = isUK(v) ? 'UK' : 'US';
    if(!groups[g]){ groups[g] = document.createElement('optgroup'); groups[g].label = g; sel.appendChild(groups[g]); }
    var o = document.createElement('option'); o.value = v.name; o.textContent = v.name; groups[g].appendChild(o);
  });
  if(current){
    var found = Array.prototype.some.call(sel.options, function(o){ return o.value === current; });
    if(found) sel.value = current; else { prefs.voice = ''; sel.value = ''; savePrefs(); }
  }
}
function findSelectedVoice(){
  if(!prefs.voice) return null;
  var voices = window.speechSynthesis.getVoices() || [];
  return voices.find(function(v){ return v.name === prefs.voice; }) || null;
}
function pickVoice(){
  var sel = findSelectedVoice(); if(sel) return sel;
  var voices = window.speechSynthesis.getVoices() || [];
  return voices.find(function(v){
    var n = (v.name||'').toLowerCase();
    return n.indexOf('samantha') !== -1 || n.indexOf('serena') !== -1 || n.indexOf('daniel') !== -1 || n.indexOf('karen') !== -1 || (v.lang && v.lang.toLowerCase().indexOf('en-gb') === 0);
  }) || voices.find(function(v){ return v.lang && v.lang.toLowerCase().indexOf('en') === 0; }) || null;
}
function isSafari(){
  var ua = navigator.userAgent || '';
  return ua.indexOf('Safari') !== -1 && !/Chrome|Chromium|CriOS|Edg|OPR|Opera|Firefox|FxiOS/.test(ua);
}

/* ---------- rendering ---------- */
function totalItems(){ var n = 0; MODULES.forEach(function(m){ n += m.items.length; }); return n; }

function renderModules(){
  var container = $('modulesContainer'); container.innerHTML = '';
  MODULES.forEach(function(mod, mIdx){
    var section = document.createElement('div');
    section.className = 'module-section' + (openModules[mod.id] ? ' open' : '');
    var header = document.createElement('button');
    header.className = 'module-header'; header.type = 'button';
    header.innerHTML = '<span></span><span class="arrow">▶</span>';
    header.firstChild.textContent = mod.label;
    header.addEventListener('click', function(e){ e.stopPropagation(); openModules[mod.id] = !openModules[mod.id]; section.classList.toggle('open', openModules[mod.id]); });
    var body = document.createElement('div'); body.className = 'module-body';
    var list = document.createElement('div'); list.className = 'item-list';
    mod.items.forEach(function(item, iIdx){
      var btn = document.createElement('button');
      btn.className = 'item-btn'; btn.type = 'button';
      btn.setAttribute('aria-pressed', (mIdx === currentModuleIdx && iIdx === currentItemIdx) ? 'true' : 'false');
      var span = document.createElement('span');
      span.textContent = item.text.length > 68 ? item.text.slice(0, 65) + '…' : item.text;
      btn.appendChild(span);
      var kind = document.createElement('span'); kind.className = 'item-kind'; kind.textContent = KIND_LABEL[item.kind] || item.kind;
      btn.appendChild(kind);
      btn.addEventListener('click', function(e){
        e.stopPropagation();
        currentModuleIdx = mIdx; currentItemIdx = iIdx; openModules[mod.id] = true;
        afterNavigate();
      });
      list.appendChild(btn);
    });
    body.appendChild(list); section.appendChild(header); section.appendChild(body); container.appendChild(section);
  });
  $('sideSub').textContent = MODULES.length + ' Modules · ' + totalItems() + ' Items';
}

function fitText(){
  var wrap = $('itemWrap'), el = $('itemText'); if(!wrap || !el) return;
  var plain = el.classList.contains('plain');
  if(window.matchMedia('(max-width:1100px)').matches){ el.style.fontSize = ''; return; }
  var size = plain ? 17.5 : 20, min = plain ? 13.5 : 14.5;
  el.style.fontSize = size + 'px';
  while(size > min && wrap.scrollHeight > wrap.clientHeight + 1){ size -= 0.5; el.style.fontSize = size + 'px'; }
}

function renderCurrentItem(){
  var mod = MODULES[currentModuleIdx], item = mod.items[currentItemIdx];
  $('moduleTag').textContent = 'Module ' + (currentModuleIdx+1) + ' · ' + mod.label.replace(/^\d+\s·\s/, '');
  $('itemCounter').textContent = 'Item ' + (currentItemIdx+1) + ' of ' + mod.items.length;
  $('kindTag').textContent = KIND_LABEL[item.kind] || item.kind;
  $('textBody').textContent = item.text;
  var el = $('itemText'); el.classList.toggle('plain', item.kind === 'Anecdote');
  $('prevBtn').disabled = (currentModuleIdx === 0 && currentItemIdx === 0);
  $('nextBtn').disabled = (currentModuleIdx === MODULES.length - 1 && currentItemIdx === mod.items.length - 1);
  var btns = document.querySelectorAll('.item-btn'), c = 0;
  MODULES.forEach(function(m, mi){ m.items.forEach(function(it, ii){ var b = btns[c++]; if(b) b.setAttribute('aria-pressed', (mi === currentModuleIdx && ii === currentItemIdx) ? 'true' : 'false'); }); });
  fitText();
}

function isLast(){ return currentModuleIdx === MODULES.length - 1 && currentItemIdx === MODULES[currentModuleIdx].items.length - 1; }
function step(dir){
  var mod = MODULES[currentModuleIdx];
  if(dir > 0){
    if(currentItemIdx < mod.items.length - 1) currentItemIdx++;
    else if(currentModuleIdx < MODULES.length - 1){ currentModuleIdx++; currentItemIdx = 0; }
    else return false;
  } else {
    if(currentItemIdx > 0) currentItemIdx--;
    else if(currentModuleIdx > 0){ currentModuleIdx--; currentItemIdx = MODULES[currentModuleIdx].items.length - 1; }
    else return false;
  }
  openModules[MODULES[currentModuleIdx].id] = true;
  return true;
}
function afterNavigate(){
  stopReading(true);
  renderModules(); renderCurrentItem();
  if(autoMode) readAloud();
}
function goNext(){ if(step(1)) afterNavigate(); }
function goPrev(){ if(step(-1)) afterNavigate(); }

/* ---------- state label ---------- */
var state = 'idle';
function setState(s){ state = s; $('stateTxt').textContent = s; }
function refreshState(){ setState(isReading ? 'reading' : (ambientOn ? 'ambient' : 'idle')); }

/* ---------- Read aloud (sentence-chunked) ---------- */
function chunkText(text){
  var parts = text.replace(/\s+/g, ' ').trim().split(/(?<=[.!?…])\s+(?=[A-Z"'‘“(])/);
  var out = [];
  parts.forEach(function(p){
    while(p.length > 190){
      var cut = -1, re = /[,;:—–]\s/g, m;
      while((m = re.exec(p)) && m.index < 190){ cut = m.index + 1; }
      if(cut < 40){ cut = p.lastIndexOf(' ', 170); if(cut < 40) cut = 170; }
      out.push(p.slice(0, cut).trim()); p = p.slice(cut).trim();
    }
    if(p) out.push(p);
  });
  var merged = [];
  out.forEach(function(p){
    if(merged.length && (merged[merged.length-1].length < 28)) merged[merged.length-1] += ' ' + p; else merged.push(p);
  });
  return merged;
}
function setReadBtn(reading){ $('readBtn').innerHTML = reading ? '<span class="icon">■</span>Stop' : '<span class="icon">🔊</span>Read Aloud'; }

function stopReading(keepAuto){
  readGen++; isReading = false; keepAlive = [];
  if(nextTimer){ clearTimeout(nextTimer); nextTimer = null; }
  if('speechSynthesis' in window) window.speechSynthesis.cancel();
  if(!keepAuto && autoMode){ autoMode = false; prefs.auto = false; savePrefs(); $('autoBtn').classList.remove('active'); $('autoBtn').innerHTML = '<span class="icon">▶</span>Auto-play'; }
  setReadBtn(false); refreshState();
}

function readAloud(){
  if(!('speechSynthesis' in window)) return;
  var gen = ++readGen;
  if(nextTimer){ clearTimeout(nextTimer); nextTimer = null; }
  window.speechSynthesis.cancel();
  var chunks = chunkText(MODULES[currentModuleIdx].items[currentItemIdx].text);
  var voice = pickVoice();
  isReading = true; setReadBtn(true); refreshState();
  keepAlive = [];
  function speakAt(i){
    if(gen !== readGen) return;
    if(i >= chunks.length){ finished(gen); return; }
    var u = new SpeechSynthesisUtterance(chunks[i]);
    u.rate = paceToRate(); u.pitch = 0.98; u.volume = 1;
    if(voice){ u.voice = voice; u.lang = voice.lang || 'en-GB'; } else { u.lang = 'en-GB'; }
    u.onend = function(){ speakAt(i + 1); };
    u.onerror = function(ev){ if(gen !== readGen) return; if(ev && (ev.error === 'interrupted' || ev.error === 'canceled')) return; finished(gen); };
    keepAlive.push(u);
    window.speechSynthesis.speak(u);
  }
  setTimeout(function(){ speakAt(0); }, 60);
}

function finished(gen){
  if(gen !== readGen) return;
  isReading = false; keepAlive = []; setReadBtn(false); refreshState();
  if(autoMode){
    if(isLast()){ autoMode = false; prefs.auto = false; savePrefs(); $('autoBtn').classList.remove('active'); $('autoBtn').innerHTML = '<span class="icon">▶</span>Auto-play'; return; }
    nextTimer = setTimeout(function(){ nextTimer = null; if(!autoMode) return; if(step(1)){ renderModules(); renderCurrentItem(); readAloud(); } }, 1400);
  }
}

function setAuto(on){
  autoMode = on; prefs.auto = on; savePrefs();
  var b = $('autoBtn'); b.classList.toggle('active', on);
  b.innerHTML = on ? '<span class="icon">■</span>Auto-play on' : '<span class="icon">▶</span>Auto-play';
  if(on){ $('resumeBtn').hidden = true; if(!isReading) readAloud(); }
  else { stopReading(true); }
}

/* ---------- Ambient ---------- */
function startAmbient(){
  if(ambientOn) return;
  try{
    var AC = window.AudioContext || window.webkitAudioContext; if(!AC) return;
    ambientCtx = new AC();
    if(ambientCtx.state === 'suspended' && ambientCtx.resume) ambientCtx.resume().catch(function(){});
    var master = ambientCtx.createGain(); master.gain.value = 0; master.connect(ambientCtx.destination);
    function osc(type, f, g){ var o = ambientCtx.createOscillator(); o.type = type; o.frequency.value = f; var gn = ambientCtx.createGain(); gn.gain.value = g; o.connect(gn); gn.connect(master); return o; }
    var o1 = osc('sine', 110, .35), o2 = osc('sine', 164.81, .18), o3 = osc('triangle', 220, .08);
    var size = 2 * ambientCtx.sampleRate, buf = ambientCtx.createBuffer(1, size, ambientCtx.sampleRate), data = buf.getChannelData(0);
    for(var i=0;i<size;i++) data[i] = (Math.random()*2 - 1) * 0.4;
    var noise = ambientCtx.createBufferSource(); noise.buffer = buf; noise.loop = true;
    var lp = ambientCtx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 380; lp.Q.value = 0.7;
    var ng = ambientCtx.createGain(); ng.gain.value = 0.05;
    noise.connect(lp); lp.connect(ng); ng.connect(master);
    var lfo = ambientCtx.createOscillator(); lfo.type = 'sine'; lfo.frequency.value = 0.06;
    var lg = ambientCtx.createGain(); lg.gain.value = 0.04; lfo.connect(lg); lg.connect(master.gain);
    o1.start(); o2.start(); o3.start(); noise.start(); lfo.start();
    master.gain.linearRampToValueAtTime(0.16, ambientCtx.currentTime + 2);
    ambientNodes = { master:master, nodes:[o1,o2,o3,noise,lfo] };
    ambientOn = true;
  }catch(e){ console.warn('Ambient failed', e); }
}
function stopAmbient(){
  if(!ambientOn || !ambientNodes) return;
  var ctx = ambientCtx, nodes = ambientNodes;
  try{ nodes.master.gain.cancelScheduledValues(ctx.currentTime); nodes.master.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.6); }catch(e){}
  setTimeout(function(){ try{ nodes.nodes.forEach(function(n){ n.stop(); }); ctx.close(); }catch(e){} }, 800);
  ambientCtx = null; ambientNodes = null; ambientOn = false;
}
function setAmbientUI(){
  var b = $('ambientBtn'); b.classList.toggle('active', ambientOn);
  b.innerHTML = ambientOn ? '<span class="icon">■</span>Ambient On' : '<span class="icon">🎵</span>Ambient';
  refreshState();
}

/* ---------- Signal canvas ---------- */
var sigCanvas = $('signalCanvas'), sigCtx = sigCanvas.getContext('2d');
var sigDPR = Math.min(window.devicePixelRatio || 1, 1.5), sigPhase = 0, COUNT = 7, COLORS = ['#4c1d95','#7c3aed','#a78bfa','#6d28d9'];
function readColors(){
  var cs = getComputedStyle(document.body);
  var a = cs.getPropertyValue('--brand-violet').trim(), b = cs.getPropertyValue('--brand-violet-accent').trim(), c = cs.getPropertyValue('--brand-violet-soft').trim();
  if(a && b && c) COLORS = [a, b, c, b];
}
function resizeSig(){ var r = sigCanvas.getBoundingClientRect(); sigCanvas.width = Math.round(r.width * sigDPR); sigCanvas.height = Math.round(r.height * sigDPR); }
function drawSignal(){
  var W = sigCanvas.width, H = sigCanvas.height; sigCtx.clearRect(0, 0, W, H);
  var cy = H/2, margin = 40*sigDPR, usable = W - margin*2, st = usable/(COUNT-1);
  for(var i=0;i<COUNT;i++){
    var pulse = 0.5 + 0.5*Math.sin(sigPhase + i*0.5), size = (12 + 3.5*pulse)*sigDPR;
    sigCtx.save(); sigCtx.translate(margin + st*i, cy); sigCtx.rotate(Math.PI/4);
    sigCtx.fillStyle = COLORS[i % COLORS.length]; sigCtx.globalAlpha = 0.55 + 0.25*pulse;
    sigCtx.fillRect(-size/2, -size/2, size, size); sigCtx.restore();
  }
  sigPhase += 0.018; requestAnimationFrame(drawSignal);
}

/* ---------- wiring ---------- */
$('readBtn').addEventListener('click', function(){ if(isReading || autoMode){ stopReading(false); } else { readAloud(); } });
$('autoBtn').addEventListener('click', function(){ setAuto(!autoMode); });
$('ambientBtn').addEventListener('click', function(){
  if(ambientOn){ stopAmbient(); prefs.ambient = false; } else { startAmbient(); prefs.ambient = ambientOn; }
  savePrefs(); setAmbientUI();
});
$('nextBtn').addEventListener('click', goNext);
$('prevBtn').addEventListener('click', goPrev);
document.addEventListener('keydown', function(e){
  var t = e.target.tagName; if(t === 'INPUT' || t === 'TEXTAREA' || t === 'SELECT') return;
  if(e.key === 'ArrowRight') goNext(); else if(e.key === 'ArrowLeft') goPrev();
  else if(e.key === ' ' && t !== 'BUTTON'){ e.preventDefault(); $('readBtn').click(); }
});
window.addEventListener('resize', function(){ resizeSig(); fitText(); });
window.addEventListener('load', function(){ resizeSig(); fitText(); });

var aboutBtn = $('aboutBtn');
if(aboutBtn) aboutBtn.addEventListener('click', function(){ var a = $('about'); var o = a.classList.toggle('open'); aboutBtn.setAttribute('aria-expanded', o ? 'true' : 'false'); fitText(); });

(function wireVoice(){
  loadPrefs();
  var vs = $('voiceSelect'), ps = $('paceSelect');
  populateVoices();
  if('speechSynthesis' in window) window.speechSynthesis.onvoiceschanged = populateVoices;
  vs.addEventListener('change', function(){ prefs.voice = vs.value; savePrefs(); if(isReading){ var a = autoMode; stopReading(true); readAloud(); } });
  ps.value = prefs.pace || 'normal';
  ps.addEventListener('change', function(){ prefs.pace = ps.value; savePrefs(); if(isReading){ stopReading(true); readAloud(); } });
  if(isSafari()) $('voiceNote').classList.add('show');
})();

/* Browsers will not play sound until the visitor interacts with the page, so
   settings saved from the previous page are resumed on the first tap. */
(function resumeOnGesture(){
  if(!(prefs.ambient || prefs.auto)) return;
  var pill = $('resumeBtn');
  pill.textContent = prefs.auto ? 'Tap to resume reading' : 'Tap to resume ambient sound';
  pill.hidden = false;
  function go(e){
    document.removeEventListener('pointerdown', go, true); document.removeEventListener('keydown', go, true);
    if(prefs.ambient && !ambientOn && !(e.target.closest && e.target.closest('#ambientBtn'))){ startAmbient(); setAmbientUI(); }
    if(prefs.auto && (e.target === pill)){ setAuto(true); }
    pill.hidden = !(prefs.auto && !autoMode);
  }
  document.addEventListener('pointerdown', go, true); document.addEventListener('keydown', go, true);
  pill.addEventListener('click', function(){ if(prefs.auto && !autoMode) setAuto(true); pill.hidden = true; });
})();

readColors(); renderSectorLinks(); renderModules(); renderCurrentItem(); resizeSig(); requestAnimationFrame(drawSignal); setState('idle');
if(document.fonts && document.fonts.ready) document.fonts.ready.then(fitText);
})();
